import { globalGameData } from '@/games/my-whot/my-whot';
import React, { useEffect, useState } from 'react';
import {
    Dimensions,
    Image,
    Modal,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from 'react-native';

interface GameResultModalProps {
  onClose: () => void;
  onPlayAgain?: () => void;
}

const GameResultModal: React.FC<GameResultModalProps> = ({ onClose, onPlayAgain }) => {
  const [visible, setVisible] = useState(false);
  const [resultData, setResultData] = useState(globalGameData);
  
  useEffect(() => {
    // Check if modal should be shown based on global state
    if (globalGameData.showModal && globalGameData.result) {
      setVisible(true);
      setResultData({...globalGameData});
    }
  }, [globalGameData.showModal, globalGameData.result]); // Add these dependencies
  
  // Alternatively, you can also make this component more controlled by the parent:
  useEffect(() => {
    // Update local state whenever visible prop changes
    setVisible(true);
    if (globalGameData.result) {
      setResultData({...globalGameData});
    }
  }, []);

  const handleClose = () => {
    // Reset global state when modal is closed
    globalGameData.showModal = false;
    setVisible(false);
    onClose();
  };

  const handlePlayAgain = () => {
    // Reset modal but keep player data for a new game
    globalGameData.showModal = false;
    globalGameData.result = null;
    setVisible(false);
    if (onPlayAgain) {
      onPlayAgain();
    }
  };

  // Check if the current player won
  const isWinner = resultData.result?.winner === resultData.playerId;

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      onRequestClose={handleClose}
    >
      <View style={styles.centeredView}>
        <View style={[styles.modalView, {backgroundColor: isWinner ? '#ffffff' : "#EA4335"}]}>
          <View style={styles.headerContainer}>
            <Text style={styles.modalTitle}>
              {isWinner ? 'You Won!' : 'Game Over'}
            </Text>
          </View>

          <View style={styles.resultContainer}>
            <Image 
              source={isWinner 
                ? require('@/assets/images/win.png') 
                : require('@/assets/images/lose.png')} 
              style={styles.resultImage} 
              resizeMode="contain"
            />
            
            <Text style={styles.gameNameText}>{resultData.gameName}</Text>
            
            {isWinner && (
              <View style={styles.rewardContainer}>
                <Text style={styles.rewardText}>
                  You've won {resultData.stakeAmount} coins!
                </Text>
              </View>
            )}
            
            <Text style={styles.resultMessage}>
              {isWinner 
                ? 'Congratulations on your victory!' 
                : 'Better luck next time!'}
            </Text>
          </View>

          <View style={styles.buttonsContainer}>
            <TouchableOpacity
              style={[styles.button, styles.playAgainButton]}
              onPress={handlePlayAgain}
            >
              <Text style={styles.playAgainButtonText}>Play Again</Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[styles.button, styles.closeButton]}
              onPress={handleClose}
            >
              <Text style={styles.closeButtonText}>Quit Game</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
  },
  modalView: {
    width: width * 0.85,
    borderRadius: 15,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
    borderColor: '#FFCC00',
    borderWidth: 2,
  },
  headerContainer: {
    width: '100%',
    alignItems: 'center',
    marginBottom: 15,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FFCC00',
    textAlign: 'center',
  },
  resultContainer: {
    alignItems: 'center',
    marginVertical: 15,
    width: '100%',
  },
  resultImage: {
    width: 100,
    height: 100,
    marginBottom: 15,
  },
  gameNameText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 10,
  },
  rewardContainer: {
    backgroundColor: 'rgba(255, 204, 0, 0.2)',
    borderRadius: 10,
    padding: 10,
    marginVertical: 10,
    alignItems: 'center',
    width: '100%',
  },
  rewardText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFCC00',
  },
  resultMessage: {
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
    marginTop: 10,
  },
  buttonsContainer: {
    flexDirection: 'column',
    width: '100%',
    marginTop: 20,
  },
  button: {
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
    marginVertical: 5,
    width: '100%',
  },
  playAgainButton: {
    backgroundColor: '#FFCC00',
  },
  playAgainButtonText: {
    color: '#000000',
    fontWeight: 'bold',
    fontSize: 16,
  },
  closeButton: {
    backgroundColor: 'transparent',
    borderColor: '#FFCC00',
    borderWidth: 1,
  },
  closeButtonText: {
    color: '#FFCC00',
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default GameResultModal;