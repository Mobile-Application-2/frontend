import FontAwesome from "@expo/vector-icons/FontAwesome";
import { useFonts } from "expo-font";
import { Stack, usePathname } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { BackHandler, Platform } from "react-native";
import "react-native-reanimated";

export {
  // Catch any errors thrown by the Layout component.
  ErrorBoundary
} from "expo-router";

export const unstable_settings = {
  // Ensure that reloading on `/modal` keeps a back button present.
  initialRouteName: "(tabs)",
};

// Prevent the splash screen from auto-hiding before asset loading is complete.
SplashScreen.preventAutoHideAsync();

export default function RootLayout() {
  const [loaded, error] = useFonts({
    SpaceMono: require("../assets/fonts/SpaceMono-Regular.ttf"),
    ...FontAwesome.font,
  });

  // Expo Router uses Error Boundaries to catch errors in the navigation tree.
  useEffect(() => {
    if (error) throw error;
  }, [error]);

  useEffect(() => {
    if (loaded) {
      SplashScreen.hideAsync();
    }
  }, [loaded]);

  if (!loaded) {
    return null;
  }

  return <RootLayoutNav />;
}

function RootLayoutNav() {
  const pathname = usePathname();
  
  // Global Android back button handler
  useEffect(() => {
    if (Platform.OS === 'android') {
      const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
        // Special case for onboarding - exit app
        if (pathname && pathname.includes('(onboarding)')) {
          BackHandler.exitApp();
          return true;
        }
        
        // For ALL other screens, prevent the back button from doing anything
        return true; // This prevents the default back button behavior across the app
      });
      
      return () => backHandler.remove();
    }
  }, [pathname]);

  return (
    <Stack 
      screenOptions={{ 
        gestureEnabled: false,
        headerShown: false,
      }}
    >
      {/* for regular */}
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
      {/* for celebrity */}
      <Stack.Screen name="(tab)" options={{ headerShown: false }} />

      {/* general */}
      <Stack.Screen name="(onboarding)" options={{ headerShown: false }} />
      <Stack.Screen name="(modal)" options={{ headerShown: false }} />
      <Stack.Screen name="(page)" options={{ headerShown: false }} />
      <Stack.Screen name="(pages)" options={{ headerShown: false }} />
      <Stack.Screen name="(games)" options={{ headerShown: false }} />
    </Stack>
  );
}