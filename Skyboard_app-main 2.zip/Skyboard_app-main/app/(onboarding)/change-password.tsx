import ChangePassword from "@/components/OnboardingComponents/ChangePassword";
import React from "react";

export default function Password() {
  return <ChangePassword />;
}
