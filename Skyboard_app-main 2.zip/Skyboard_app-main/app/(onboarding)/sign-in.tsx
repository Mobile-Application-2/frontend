import SignInScreen from "@/components/OnboardingComponents/SignIn";
import React from "react";

export default function FullSignIn() {
  return <SignInScreen />;
}
