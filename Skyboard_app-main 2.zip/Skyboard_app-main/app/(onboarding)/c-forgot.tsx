import CelebrityForgotPassword from "@/components/CelebrityOnboardingComponent/C-forgotpassword";
import React from "react";

export default function FullSignIn() {
  return <CelebrityForgotPassword />;
}
