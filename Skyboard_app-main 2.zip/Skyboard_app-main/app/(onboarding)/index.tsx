import OnboardingScreen from "@/components/OnboardingComponents/Paginattion";
import React from "react";

export default function index() {
  return <OnboardingScreen />
}
