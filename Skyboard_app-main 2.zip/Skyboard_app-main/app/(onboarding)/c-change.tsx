import CelebrityChangePassword from "@/components/CelebrityOnboardingComponent/C-changePassword";
import React from "react";

export default function FullSignIn() {
  return <CelebrityChangePassword />
}
