import VerificationCode from "@/components/OnboardingComponents/VerificationCode";
import React from "react";

export default function Verify() {
  return <VerificationCode />;
}
