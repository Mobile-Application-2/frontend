import CelebrityVerificationCode from "@/components/CelebrityOnboardingComponent/C-verificationCode";
import React from "react";

export default function FullSignIn() {
  return <CelebrityVerificationCode />;
}
