import UserSelection from '@/components/OnboardingComponents/UserSelection';
import React from 'react';

export default function WrappedUserSelection() {
  return (
      <UserSelection />
  );
}