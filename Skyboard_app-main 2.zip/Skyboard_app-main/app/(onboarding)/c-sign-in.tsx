import CelebritySignInScreen from "@/components/CelebrityOnboardingComponent/C-signin";
import React from "react";

export default function FullSignIn() {
  return <CelebritySignInScreen />;
}
