import MyWhotGame from "@/games/my-whot/my-whot";
import { useSearchParams } from "expo-router/build/hooks";
import React from "react";

export default function MyWhot() {
  const params = useSearchParams();
  const gameId = params.get("gameId");
  const opponentId = params.get("opponentId");
  const userId = params.get("userId");
  const stakeAmount = params.get("amount");
  const name = params.get("gameName") || "Game Title";
  const lobbyId = params.get("lobbyId") || "No ID"; // Retrieve lobbyId from params
  const lobbyCode = params.get("lobbyCode") || "No Code"; // Retrieve lobbyCode from params
  return (
    <MyWhotGame
      gameId={`${gameId}`}
      gameName={`${name}`}
      opponentId={`${opponentId}`}
      playerId={`${userId}`}
      stakeAmount={Number(stakeAmount)}
      lobbyCode={lobbyCode}
      lobbyId={lobbyId}
    />
  );
}
