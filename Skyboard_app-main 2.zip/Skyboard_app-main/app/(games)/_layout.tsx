import { Stack } from "expo-router";
import React from "react";



const Layout = () => {
  return (
    <Stack
      screenOptions={{
        headerShown: false, // Ensures no header is shown globally
        headerTransparent: true,
      }}
    >
      <Stack.Screen name="Ludo" />
      <Stack.Screen name="Whot" />
      <Stack.Screen name="my-Whot" />
    </Stack>
  );
};

export default Layout;
