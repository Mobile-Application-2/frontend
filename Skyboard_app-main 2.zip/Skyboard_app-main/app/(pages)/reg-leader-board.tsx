import LeaderboardScreen from "@/components/ProfileComponents/LeaderBoard";
import React from "react";

export default function TabTwoScreen() {
  return <LeaderboardScreen />;
}
