import Security from "@/components/ProfileComponents/SecurityScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Security />;
}
