import FundHistory from "@/components/FundHistoryScreen";
import React from "react";
export default function TabTwoScreen() {
  return <FundHistory />;
}
