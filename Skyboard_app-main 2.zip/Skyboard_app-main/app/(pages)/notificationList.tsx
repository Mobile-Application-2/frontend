import { useNotificationStore } from "@/zustand/notificationStore";
import { Ionicons } from "@expo/vector-icons";
import { formatDistanceToNow } from 'date-fns';
import React, { useEffect } from "react";
import { ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";

interface NotificationItemProps {
  type: "transaction" | "promo" | "system" | "security";
  title: string;
  message: string;
  date: string;
  read: boolean;
  onPress?: () => void;
}

// Helper function to determine notification type based on title/content
const determineNotificationType = (notification: Notification): "transaction" | "promo" | "system" | "security" => {
  const title = notification.title.toLowerCase();
  const body = notification.body.toLowerCase();
  
  if (title.includes("referral") || body.includes("referral")) {
    return "promo";
  } else if (title.includes("transaction") || body.includes("payment") || body.includes("transfer")) {
    return "transaction";
  } else if (title.includes("security") || body.includes("login") || body.includes("password")) {
    return "security";
  } else {
    return "system";
  }
};

// Helper function to format dates
const formatDate = (dateString: string): string => {
  try {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  } catch (error) {
    return "Unknown date";
  }
};

const NotificationItem: React.FC<NotificationItemProps> = ({
  type,
  title,
  message,
  date,
  read,
  onPress,
}) => {
  // Determine the notification icon and color based on type
  const getIconConfig = () => {
    switch (type) {
      case "transaction":
        return { name: "card-outline", color: "#c44eff" };
      case "promo":
        return { name: "gift-outline", color: "#4ecb71" };
      case "system":
        return { name: "cog-outline", color: "#4e9acb" };
      case "security":
        return { name: "shield-checkmark-outline", color: "#cb4e4e" };
      default:
        return { name: "notifications-outline", color: "#c44eff" };
    }
  };

  const { name, color } = getIconConfig();

  return (
    <TouchableOpacity style={[styles.itemContainer, !read && styles.unreadItem]} onPress={onPress}>
      <View style={styles.leftSection}>
        {/* Icon Container with rounded background */}
        <View
          style={[
            styles.iconContainer,
            { backgroundColor: `${color}30` }, // 30% opacity using hex color
          ]}
        >
          <Ionicons
            name={name}
            size={24}
            color={color}
            style={styles.icon}
          />
        </View>
        {/* Notification Content */}
        <View style={styles.textSection}>
          <Text style={styles.notificationTitle}>{title}</Text>
          <Text style={styles.message} numberOfLines={2}>{message}</Text>
        </View>
      </View>

      {/* Right Section: Date and unread indicator */}
      <View style={styles.rightSection}>
        <Text style={styles.date}>{date}</Text>
        {!read && <View style={styles.unreadDot} />}
      </View>
    </TouchableOpacity>
  );
};

const NotificationsScreen: React.FC = () => {
  // Connect to the notification store
  const { notifications, isLoading, error, unreadCount, getNotifications } = useNotificationStore();

  useEffect(() => {
    // Fetch notifications when the component mounts
    getNotifications();
  }, []);

  const handleMarkAsRead = async (notificationId: string) => {
    // This would be implemented in your store
    // For now just log it
    console.log("Mark notification as read:", notificationId);
    // Implementation would require adding a markAsRead function to your store
  };

  const handleMarkAllAsRead = async () => {
    // This would be implemented in your store
    // For now just log it
    console.log("Mark all notifications as read");
    // Implementation would require adding a markAllAsRead function to your store
  };

  const handleRefresh = () => {
    getNotifications();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Notifications {unreadCount > 0 && `(${unreadCount})`}</Text>
        {notifications.length > 0 && (
          <TouchableOpacity onPress={handleMarkAllAsRead}>
            <Text style={styles.markAllRead}>Mark all as read</Text>
          </TouchableOpacity>
        )}
      </View>
      
      {isLoading && notifications.length === 0 ? (
        <View style={styles.loaderContainer}>
          <ActivityIndicator size="large" color="#c44eff" />
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Failed to load notifications</Text>
          <TouchableOpacity style={styles.retryButton} onPress={getNotifications}>
            <Text style={styles.retryText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : notifications.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="notifications-off-outline" size={64} color="#c44eff" />
          <Text style={styles.emptyText}>No notifications yet</Text>
        </View>
      ) : (
        <ScrollView 
          style={styles.notificationsList}
          refreshControl={
            <RefreshControl 
              refreshing={isLoading} 
              onRefresh={handleRefresh}
              colors={["#c44eff"]}
              tintColor="#c44eff"
            />
          }
        >
          {notifications.map((notification) => (
            <NotificationItem
              key={notification._id}
              type={determineNotificationType(notification)}
              title={notification.title}
              message={notification.body}
              date={formatDate(notification.createdAt)}
              read={notification.read}
              onPress={() => handleMarkAsRead(notification._id)}
            />
          ))}
        </ScrollView>
      )}
    </View>
  );
};

export default NotificationsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#130828",
    paddingTop: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 15,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  markAllRead: {
    fontSize: 12,
    color: "#c44eff",
  },
  notificationsList: {
    flex: 1,
  },
  itemContainer: {
    flexDirection: "row",
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.05)",
    justifyContent: "space-between",
  },
  unreadItem: {
    backgroundColor: "rgba(196, 78, 255, 0.05)",
  },
  leftSection: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
  },
  iconContainer: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 20,
    marginRight: 10,
  },
  icon: {
    alignSelf: "center",
  },
  textSection: {
    flexDirection: "column",
    flex: 1,
  },
  notificationTitle: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  message: {
    fontSize: 12,
    color: "rgba(255, 255, 255, 0.7)",
    marginTop: 3,
  },
  rightSection: {
    alignItems: "flex-end",
    justifyContent: "space-between",
    paddingLeft: 10,
  },
  date: {
    fontSize: 11,
    color: "rgba(255, 255, 255, 0.5)",
  },
  unreadDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#c44eff",
    marginTop: 5,
  },
  loaderContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  errorText: {
    color: "#FFFFFF",
    fontSize: 16,
    marginBottom: 15,
  },
  retryButton: {
    padding: 10,
    backgroundColor: "#c44eff",
    borderRadius: 5,
  },
  retryText: {
    color: "#FFFFFF",
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  emptyText: {
    color: "#FFFFFF",
    fontSize: 16,
    marginTop: 15,
    textAlign: "center",
  },
});