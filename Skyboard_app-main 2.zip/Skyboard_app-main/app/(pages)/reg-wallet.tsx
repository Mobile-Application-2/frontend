import WithdrawalScreen from "@/components/WalletComponent/WithdrawComponent";
import React from "react";

export default function TabTwoScreen() {
  return <WithdrawalScreen/>;
}
