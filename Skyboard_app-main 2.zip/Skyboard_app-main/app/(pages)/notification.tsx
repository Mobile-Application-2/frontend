import Notification from "@/components/ProfileComponents/NotificationScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Notification />;
}
