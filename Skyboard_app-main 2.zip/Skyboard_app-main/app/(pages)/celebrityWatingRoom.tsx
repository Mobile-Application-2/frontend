import { useProfileStore } from "@/zustand/profileStore";
import { useSocketStore } from "@/zustand/socketStore";
import { useTournamentStore } from "@/zustand/tournamentsStore";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useEffect, useState } from "react";
import { Alert, Dimensions, Image, StyleSheet, Text, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  withDelay,
  withRepeat,
  withSequence,
  withTiming,
} from "react-native-reanimated";

const AVATARS = [
  "https://api.dicebear.com/7.x/avataaars/png?seed=Felix",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Aneka",
  "https://api.dicebear.com/7.x/avataaars/png?seed=John",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Lisa",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Mike",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Sarah",
  "https://api.dicebear.com/7.x/avataaars/png?seed=David",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Emma",
  "https://api.dicebear.com/7.x/avataaars/png?seed=James",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Oliver",
  "https://api.dicebear.com/7.x/avataaars/png?seed=Sophie",
  "https://api.dicebear.com/7.x/avataaars/png?seed=William",
];

const { width: SCREEN_WIDTH } = Dimensions.get("window");

interface AnimatedAvatarProps {
  url: string;
  size: number;
  position: { left: number; top: number };
  delay: number;
}

const AnimatedAvatar: React.FC<AnimatedAvatarProps> = ({
  url,
  size,
  position,
  delay,
}) => {
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateY: withRepeat(
            withSequence(
              withDelay(delay, withTiming(-10, { duration: 1000 })),
              withTiming(0, { duration: 1000 })
            ),
            -1,
            true
          ),
        },
      ],
    };
  });

  return (
    <Animated.View
      style={[
        styles.avatarContainer,
        {
          width: size,
          height: size,
          ...position,
        },
        animatedStyle,
      ]}
    >
      <Image source={{ uri: url }} style={styles.avatar} />
    </Animated.View>
  );
};

const LoadingIndicator = ({ totalPlayers }: any) => {
  const dots = Array(8).fill(0);
  return (
    <View style={styles.loadingContainer}>
      {dots.map((_, index) => (
        <Animated.View
          key={index}
          style={[
            styles.dot,
          ]}
        />
      ))}
      <Text style={styles.loadingText}>{totalPlayers}</Text>
    </View>
  );
};

export default function WaitingRoomScreen() {
  const router = useRouter();
  const params = useSearchParams();
  const { user } = useProfileStore();
  const { tournaments } = useTournamentStore();
  const { initSocket, socket, disconnectSocket, emitEvent } = useSocketStore();

  const tournamentId = params.get("tournamentId") || "";
  const gameId = params.get("gameId") || "";
  const image = params.get("image") || "No Game Image";
  const tournamentName = params.get("tournamentName");
  const isOwner = params.get("isOwner") === "true";
  const selectedId = gameId
  const selectedGame = tournaments.find((game) => game.gameId === selectedId);
  const gameName =  selectedGame?.gameName
  
  const [totalPlayers, setTotalPlayers] = useState(0);
  const [lobbyCode, setLobbyCode] = useState("");
  const [isRedirectedFromFixture, setIsRedirectedFromFixture] = useState(false);
  const [isLeavingTournament, setIsLeavingTournament] = useState(false);

  useEffect(() => {
    // Check if the page was redirected from a completed fixture
    const fromFixture = params.get("fromFixture") === "true";
    setIsRedirectedFromFixture(fromFixture);

    // Initialize socket if it doesn't exist or reconnect if needed
    const socketInstance = initSocket("/tournament", {
      userId: user?._id,
      tournamentId: tournamentId,
      isOwner: isOwner
    });

    // Socket event listeners
    socketInstance.on("total-players", (count) => {
      setTotalPlayers(count);
    });

    socketInstance.on("matched", (data) => {
      setLobbyCode(data.lobbyCode);

      // Navigate to the matched screen with the lobby code
      router.push({
        pathname: "/(page)/matched",
        params: {
          userId: user?._id,
          tournamentId: tournamentId,
          gameName: gameName,
          tournamentName: tournamentName,
          lobbyCode: data.lobbyCode,
        },
      });
    });

    socketInstance.on("error", (error) => {
      Alert.alert("Error", error.message);
    });

    // Clean up event listeners on unmount, but don't disconnect unless leaving tournament
    return () => {
      socketInstance.off("total-players");
      socketInstance.off("matched");
      socketInstance.off("error");
      
      // Only disconnect if we're actually leaving the tournament completely
      if (isLeavingTournament) {
        disconnectSocket();
      }
    };
  }, [tournamentId, user, isOwner]);

  // Emit tournament-fixture-completed event if redirected from fixture
  useEffect(() => {
    if (isRedirectedFromFixture && socket && user?._id) {
      emitEvent("tournament-fixture-completed", user._id);
    }
  }, [isRedirectedFromFixture, socket, user]);

  // Handle back button / leaving tournament
  const handleBackPress = () => {
    setIsLeavingTournament(true);
    router.push(`${user?.isCelebrity ? '/(tab)' : '/(tabs)'}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.backButton} onTouchEnd={handleBackPress}>
          <Ionicons name="chevron-back" color="#fff" size={24} />
        </View>
        <Text style={styles.title}>{gameName || tournamentName}</Text>
      </View>

      <Image source={{ uri: image }} style={styles.chessImage} />

      <View style={styles.avatarsContainer}>
        {AVATARS.map((url, index) => (
          <AnimatedAvatar
            key={index}
            url={url}
            size={40 + Math.random() * 20}
            position={{
              left: Math.random() * (SCREEN_WIDTH - 60),
              top: Math.random() * 200,
            }}
            delay={index * 200}
          />
        ))}
      </View>

      <LoadingIndicator totalPlayers={totalPlayers} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0A0A1A",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    padding: 20,
    paddingTop: 60,
  },
  backButton: {
    padding: 8,
  },
  title: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "600",
    marginLeft: 20,
  },
  chessImage: {
    width: SCREEN_WIDTH - 40,
    height: 200,
    marginHorizontal: 20,
    borderRadius: 12,
    marginTop: 20,
  },
  avatarsContainer: {
    flex: 1,
    position: "relative",
  },
  avatarContainer: {
    position: "absolute",
    borderRadius: 100,
    padding: 2,
    backgroundColor: "#0A0A1A",
  },
  avatar: {
    width: "100%",
    height: "100%",
    borderRadius: 100,
    borderWidth: 2,
    borderColor: "#00FF9D",
  },
  loadingContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    padding: 40,
    position: "relative",
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#00FF9D",
    margin: 4,
  },
  loadingText: {
    color: "#00FF9D",
    fontSize: 16,
    fontWeight: "600",
    position: "absolute",
  },
});