import Contact from "@/components/ProfileComponents/ContactScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Contact />;
}
