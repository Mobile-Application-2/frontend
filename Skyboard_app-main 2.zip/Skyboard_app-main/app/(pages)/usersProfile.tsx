import Profile from "@/components/UserProfileScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Profile />;
}
