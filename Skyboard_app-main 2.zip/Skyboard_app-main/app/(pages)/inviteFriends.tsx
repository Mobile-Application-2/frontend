import InviteFriend from "@/components/ProfileComponents/InviteFriendsScreen";
import React from "react";
export default function TabTwoScreen() {
  return <InviteFriend />;
}
