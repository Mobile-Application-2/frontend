import EditProfileScreen from "@/components/ProfileComponents/EditProfileScreen";
import React from "react";
export default function TabTwoScreen() {
  return <EditProfileScreen />;
}
