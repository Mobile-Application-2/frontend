import Chat from "@/components/ChatScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Chat />;
}
