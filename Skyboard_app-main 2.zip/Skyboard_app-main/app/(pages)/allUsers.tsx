import AllUsers from "@/components/AllUsersScreen";
import React from "react";
export default function TabTwoScreen() {
  return <AllUsers />;
}
