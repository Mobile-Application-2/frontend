import TermsConditionScreen from "@/components/ProfileComponents/TermsConditionScreen";
import React from "react";
export default function TabTwoScreen() {
  return <TermsConditionScreen />;
}
