import BankScreen from "@/components/ProfileComponents/BankScreen";
import React from "react";
export default function TabTwoScreen() {
  return <BankScreen />;
}
