import DepositScreen from "@/components/WalletComponent/DepositComponent";
import React from "react";

export default function TabTwoScreen() {
  return <DepositScreen/>;
}
