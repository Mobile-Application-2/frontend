import FundHistoryScreen from "@/components/FundHistoryScreen";
import React from "react";

export default function TabTwoScreen() {
  return <FundHistoryScreen/>;
}
