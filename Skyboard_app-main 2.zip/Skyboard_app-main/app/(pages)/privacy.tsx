import PrivacyScreen from "@/components/ProfileComponents/PrivacyScreen";
import React from 'react';
export default function TabTwoScreen() {
  return <PrivacyScreen />;
}
