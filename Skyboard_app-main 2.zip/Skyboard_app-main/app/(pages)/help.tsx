import Help from "@/components/ProfileComponents/HelpScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Help />;
}
