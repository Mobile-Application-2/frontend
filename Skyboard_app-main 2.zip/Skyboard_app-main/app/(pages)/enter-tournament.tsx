import { useProfileStore } from "@/zustand/profileStore";
import { useTournamentStore } from "@/zustand/tournamentsStore";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation, useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
    ActivityIndicator,
    Alert,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from "react-native";

const JoinOtp: React.FC = () => {
  const router = useRouter();
  const navigation = useNavigation();
  const params = useSearchParams();
  const gameId = params.get("gameId");
  const opponentId = params.get("opponentId");
  const amount = params.get("stake");
  const gameName = params.get("name") || "Game Title";
  const lobbyId = params.get("lobbyId");

  const { getUserProfile, user } = useProfileStore();
  const { joinTournament, isJoining, error: tournamentError, clearError: clearTournamentError } = useTournamentStore();

  const [pin, setPin] = useState<string[]>(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState<boolean>(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const inputs = useRef<(TextInput | null)[]>([]).current;

  // Handle errors locally instead of from the store
  useEffect(() => {
    if (localError) {
      Alert.alert("Error", localError);
      setLocalError(null);
    }
    getUserProfile();
  }, [localError]);
  
  useEffect(() => {
    getUserProfile();
  }, []);

  // Monitor tournament error
  useEffect(() => {
    if (tournamentError) {
      Alert.alert("Error", tournamentError);
      clearTournamentError();
    }
  }, [tournamentError]);

  const handlePinChange = (text: string, index: number) => {
    const newPin = [...pin];
    newPin[index] = text.slice(-1); // Only allow one character per box
    setPin(newPin);

    // Automatically focus on the next input if it's not the last one
    if (text && index < pin.length - 1) {
      inputs[index + 1]?.focus();
    }
  };

  // Handle backspace navigation between inputs
  const handleKeyPress = (e: any, index: number) => {
    // Check if backspace was pressed and the current input is empty
    if (e.nativeEvent.key === "Backspace" && !pin[index] && index > 0) {
      // Focus on the previous input
      inputs[index - 1]?.focus();
    }
  };
  const fullPin = pin.join("");

  const handleJoinTournament = async () => {
    if (pin.join("").length !== 6) {
      Alert.alert("Invalid Code", "Please enter a complete 6-character code");
      return;
    }

    try {
      setLoading(true);
      // Clear tournament store error
      clearTournamentError();

      // Call the joinTournament function from the tournament store
      const response = await joinTournament(fullPin);

      // Check if response exists and has the success flag
      if (response && response.success) {
        router.push({
          pathname: "/(page)/matched",
          params: {
            userId: user?._id,
            gameId: gameId,
            gameName: gameName,
            lobbyCode: fullPin,
          },
        });
      } else if (response) {
        // Response exists but success is false
        setLocalError(response.message || "Failed to join the tournament");
      } else {
        // No response returned
        setLocalError("No response received from server");
      }
    } catch (err: any) {
      setLocalError(err?.message || "An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: () => (
        <View style={styles.titleContainer}>
          <Text style={styles.header}>
            Enter <Text style={styles.highlight}>Tournament Lobby</Text> Code To Play Game
          </Text>
        </View>
      ),
      headerLeft: () => (
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.headerLeft}
        >
          <Ionicons name="chevron-back" size={20} color={"white"} />
        </TouchableOpacity>
      ),
    });
  }, [navigation, router]);

  // Check if all pin boxes are filled
  const isPinComplete = pin.every(digit => digit.trim() !== "");

  return (
    <View style={styles.container}>
      <Text style={styles.enterPin}>ENTER PIN</Text>
      <View style={styles.pinContainer}>
        {pin.map((digit, index) => (
          <TextInput
            key={index}
            ref={(ref) => (inputs[index] = ref)}
            style={styles.pinBox}
            value={digit}
            keyboardType="default" // Allow alphanumeric input
            maxLength={1}
            onChangeText={(text) => handlePinChange(text, index)}
            onKeyPress={(e) => handleKeyPress(e, index)}
            autoCapitalize="characters"
          />
        ))}
      </View>
      <TouchableOpacity
        onPress={handleJoinTournament}
        style={[
          styles.enterButton, 
          (!isPinComplete || loading || isJoining) && styles.disabledButton
        ]}
        disabled={!isPinComplete || loading || isJoining}
      >
        {!loading && !isJoining ? (
          <Text style={styles.enterButtonText}>ENTER</Text>
        ) : (
          <ActivityIndicator size={"small"} color={"white"} />
        )}
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A001A", // Dark purple background
    paddingHorizontal: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  titleContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  header: {
    fontSize: 20,
    fontWeight: "bold",
    color: "white",
  },
  highlight: {
    color: "#C21E78",
  },
  headerLeft: {
    paddingLeft: 10, // Adjust space between back icon and title
  },
  enterPin: {
    fontSize: 18,
    color: "#FFFFFF",
    fontWeight: "bold",
    marginBottom: 20,
  },
  pinContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 30,
  },
  pinBox: {
    width: 50,
    height: 50,
    borderWidth: 2,
    borderColor: "#C21E78", // Green border
    color: "#FFFFFF",
    fontSize: 24,
    textAlign: "center",
    borderRadius: 5,
    marginHorizontal: 5,
  },
  enterButton: {
    backgroundColor: "#E91E63", // Pink button
    paddingVertical: 15,
    paddingHorizontal: 40,
    borderRadius: 5,
  },
  enterButtonText: {
    color: "#FFFFFF",
    fontWeight: "bold",
    fontSize: 16,
  },
  disabledButton: {
    backgroundColor: "#9E9E9E", // Gray when disabled
    opacity: 0.4,
  },
});

export default JoinOtp;