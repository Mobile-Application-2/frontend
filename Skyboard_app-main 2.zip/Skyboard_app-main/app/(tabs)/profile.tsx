import ProfileSettings from '@/components/ProfileComponents/ProfileScreen';
import React from 'react';
export default function TabTwoScreen() {
  return (
    <ProfileSettings />
  );
}
