import Home from '@/components/HomeComonents/Home';
import React from 'react';

export default function Index() {
  return (
    <Home/>
  );
}
