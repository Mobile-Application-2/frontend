import AllGamesScreen from "@/components/CelebrityHomeComponents/CelebrityTopGames";
import React from "react";
export default function TabTwoScreen() {
  return <AllGamesScreen />;
}