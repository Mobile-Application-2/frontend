import Tournaments from "@/components/TournamentsScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Tournaments />;
}
