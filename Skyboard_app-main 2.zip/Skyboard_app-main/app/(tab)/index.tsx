import CelebrityHome from "@/components/CelebrityHomeComponents/CelebrityHome";
import React from "react";
export default function Index() {
  return <CelebrityHome />;
}
