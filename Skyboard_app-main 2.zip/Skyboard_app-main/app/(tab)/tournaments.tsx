import TournamentsScreen from "@/components/CelebrityHomeComponents/CelebrityTournaments";
import React from "react";
export default function Tournaments() {
  return <TournamentsScreen />;
}