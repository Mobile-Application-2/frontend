import CelebrityProfileSettings from "@/components/CelebrityProfileComponents/CelebrityProfileScreen";
import React from "react";
export default function TabTwoScreen() {
  return <CelebrityProfileSettings />;
}
