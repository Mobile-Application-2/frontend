import { useGameStore } from "@/zustand/gameStore";
import { Feather } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

export default function StakeScreen() {
  const router = useRouter();
  const params = useSearchParams();
  const gameId = params.get("gameId");
  const name = params.get("name") || "Game Title";
  const [stakeAmount, setStakeAmount] = useState(100);
  const { createLobby, lobby, isLoading, clearError, error } = useGameStore();

  console.log(name)

  const handleNext = async () => {
    if (!gameId) {
      Alert.alert("Error", "Game ID is missing.");
      return;
    }
  
    const stake = Number(stakeAmount) * 100;
    const amount = Math.floor(Number(stake));
    if (amount < 1000) {
      Alert.alert("Error", "Stake amount must be at least 1000 naira");
      return;
    }
  
    try {
      clearError();
      const response = await createLobby({ gameId, wagerAmount: stake });
      console.log('Response:', response); // Let's log the full response
      
      router.push({
        pathname: "/(page)/qr-code",
        params: {
          lobbyId: response._id,        
          lobbyCode: response.code,  
          stake: stake,
          gameId: gameId,
          name: name,
        },
      });
    } catch (e) {
      console.error('Navigation error:', e); // Added error logging
      Alert.alert(
        "Error",
        error || "Failed to create lobby. Please try again."
      );
    }
  };

  const handleIncrement = () => setStakeAmount((prev) => prev + 100);
  const handleDecrement = () =>
    setStakeAmount((prev) => Math.max(prev - 100, 100)); // Minimum stake 100

  const handleStakeChange = (text: any) => {
    const value = Math.floor(Number(text));
    if (!isNaN(value)) {
      setStakeAmount(Math.max(value, 100));
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Feather name="chevron-left" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Create A {name} Lobby</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
        >
          <Feather name="share-2" size={24} color="#0A001A" />
        </TouchableOpacity>
      </View>
      <View style={styles.content}>
        <Text style={styles.subheading}>SET STAKE AMOUNT</Text>
        <View style={styles.stakeContainer}>
          <TouchableOpacity onPress={handleDecrement} style={styles.iconButton}>
            <Text style={styles.iconText}>-</Text>
          </TouchableOpacity>
          <View>
            <TextInput
              value={stakeAmount.toString()}
              style={styles.stakeInput}
              keyboardType="numeric"
              onChangeText={handleStakeChange}
            />
          </View>
          <TouchableOpacity onPress={handleIncrement} style={styles.iconButton}>
            <Text style={styles.iconText}>+</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.presetContainer}>
          <TouchableOpacity
            style={styles.presetButton}
            onPress={() => setStakeAmount(1000)} // Set stake amount to 1000
          >
            <Text style={styles.presetText}>N1,000</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.presetButton}
            onPress={() => setStakeAmount(5000)} // Set stake amount to 5000
          >
            <Text style={styles.presetText}>N5,000</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.presetButton}
            onPress={() => setStakeAmount(15000)} // Set stake amount to 15000
          >
            <Text style={styles.presetText}>N15,000</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.infoText}>
          Stake ₦100 upwards for a 2 player game
        </Text>
        <TouchableOpacity onPress={handleNext} style={styles.nextButton}>
          {isLoading ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <Text style={styles.nextButtonText}>NEXT</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A0826",
    paddingHorizontal: 16,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 80,
    marginTop: 30,
  },
  backButton: {
    fontSize: 18,
    color: "#FFF",
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFF",
  },
  headerText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#DDA7FF",
  },
  content: {
    marginTop: 30,
    alignItems: "center",
  },
  subheading: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 20,
  },
  stakeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 50,
    alignItems: "center",
    marginBottom: 40,
  },
  iconButton: {
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2D1035",
    borderRadius: 15,
  },
  iconText: {
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "bold",
  },
  stakeInput: {
    width: 100,
    height: 50,
    textAlign: "center",
    fontSize: 20,
    color: "#FFFFFF",
    borderBottomWidth: 2,
    borderBottomColor: "#FFFFFF",
    marginHorizontal: 10,
  },
  presetContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 20,
  },
  presetButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: "#FECF56",
    borderRadius: 10,
  },
  presetText: {
    color: "#1A0826",
    fontSize: 14,
    fontWeight: "bold",
  },
  infoText: {
    fontSize: 12,
    color: "#FFFFFF",
    marginBottom: 30,
  },
  nextButton: {
    backgroundColor: "#FECF56",
    width: "100%",
    paddingVertical: 15,
    alignItems: "center",
    borderRadius: 10,
  },
  nextButtonText: {
    color: "#1A0826",
    fontSize: 16,
    fontWeight: "bold",
  },
});
