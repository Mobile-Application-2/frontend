import Help from "@/components/CelebrityProfileComponents/CelebrityHelpScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Help />;
}
