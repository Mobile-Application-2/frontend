import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from 'expo-file-system';
import { useRouter } from 'expo-router';
import { useSearchParams } from 'expo-router/build/hooks';
import * as Sharing from 'expo-sharing';
import React, { useEffect, useState } from 'react';
import {
  Alert,
  Clipboard,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

const GeneratePinQRScreen: React.FC = () => {
  const router = useRouter();
  const params = useSearchParams();
  const [qrUri, setQrUri] = useState<string>('');
  const [hasOpponent, setHasOpponent] = useState<boolean>(false);
  
  // Retrieve all parameters from the route
  const lobbyId = params.get("lobbyId") || "";
  const lobbyCode = params.get("lobbyCode") || "";
  const stake = params.get("stake") || "0";
  const gameId = params.get("gameId") || "";
  const name = params.get("name") || "Game";
  const opponentId = params.get("opponentId") || "";
  
  // Format the code for display (add a space in the middle)
  const formattedPin = lobbyCode ? `${lobbyCode.slice(0, 3)} ${lobbyCode.slice(3)}` : '';
  const qrValue = lobbyCode || '';

  useEffect(() => {
    if (qrValue) {
      generateQRCode();
    }

    // Check if there's an opponentId from params or from storage
    const checkForOpponent = async () => {
      if (opponentId) {
        setHasOpponent(true);
        return;
      }

      try {
        const savedOpponentData = await AsyncStorage.getItem('selectedOpponentData');
        if (savedOpponentData) {
          setHasOpponent(true);
        }
      } catch (error) {
        console.error("Error checking for opponent data:", error);
      }
    };

    checkForOpponent();
  }, [qrValue, opponentId]);

  // Auto-navigate to SelectedUser if an opponent is available
  useEffect(() => {
    if (hasOpponent) {
      // Short delay to ensure the screen is fully loaded before navigating
      const timer = setTimeout(() => {
        navigateToSelectedUser();
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [hasOpponent]);

  const generateQRCode = async () => {
    try {
      // Generate QR code using Expo's API
      const qrData = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(qrValue)}&size=200x200&bgcolor=1a1424&color=FFFFFF`;
      setQrUri(qrData);
    } catch (error) {
      console.error('Error generating QR code:', error);
    }
  };

  const handleShare = async () => {
    try {
      // For sharing QR code image
      const shareOptions = {
        mimeType: 'image/png',
        dialogTitle: `Share ${name} Competition QR Code ${lobbyCode}`,
      };
      
      // First download the QR code image
      const fileUri = FileSystem.cacheDirectory + 'qrcode.png';
      await FileSystem.downloadAsync(qrUri, fileUri);
      
      // Then share the message with QR code
      if (await Sharing.isAvailableAsync()) {
        await Sharing.shareAsync(fileUri, {
          mimeType: 'image/png',
          dialogTitle: `Join my ${name} competition with PIN: ${formattedPin}`,
        });
      } else {
        Alert.alert('Sharing not available on this device');
      }
    } catch (error) {
      console.error('Error sharing:', error);
      // Fallback to simple text sharing if image sharing fails
      try {
        await Sharing.shareAsync(FileSystem.documentDirectory, {
          dialogTitle: `Join my ${name} competition with PIN: ${formattedPin}`,
        });
      } catch (innerError) {
        console.error('Error with fallback sharing:', innerError);
      }
    }
  };

  const copyToClipboard = () => {
    Clipboard.setString(lobbyCode);
    Alert.alert('Copied to clipboard');
  };

  const handleFindRandom = () => {
    // Navigate to the select-user page with all necessary parameters
    router.push({
      pathname: '/(page)/users',
      params: {
        lobbyId,
        lobbyCode,
        stake,
        gameId,
        name
      }
    });
  };

  const navigateToSelectedUser = () => {
    // Navigate directly to the selected-user screen with all parameters
    router.push({
      pathname: '/(page)/selected-user',
      params: {
        lobbyId,
        lobbyCode,
        stake,
        gameId,
        name,
        opponentId: opponentId || undefined
      }
    });
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={styles.backButton}
          >
            <Feather name="chevron-left" size={24} color="white" />
          </TouchableOpacity>
          <Text style={styles.headerText}>
            Create A <Text style={styles.greenText}>{name}</Text> Lobby
          </Text>
          <View style={{ width: 24 }} /> {/* Spacer for balanced header */}
        </View>

        {/* QR Code */}
        <View style={styles.qrContainer}>
          {qrUri ? (
            <Image
              source={{ uri: qrUri }}
              style={{ width: 200, height: 200 }}
              resizeMode="contain"
            />
          ) : (
            <View style={{ width: 200, height: 200, backgroundColor: '#1a1424' }} />
          )}
        </View>

        {/* PIN */}
        <TouchableOpacity onPress={copyToClipboard}>
          <Text style={styles.pinCode}>{formattedPin}</Text>
          <Text style={styles.tapToCopy}>Tap code to copy</Text>
        </TouchableOpacity>

        {/* Info Text */}
        <Text style={styles.infoText}>
          PIN & QR Code are unique and different{'\n'}
          for each competition, you can invite your{'\n'}
          friends to join the competition
        </Text>

        {/* Buttons */}
        <View style={styles.buttonContainer}>
          {/* Share Button */}
          <TouchableOpacity 
            style={styles.shareButton}
            onPress={handleShare}
          >
            <Feather name="share-2" size={20} color="#4CAF50" />
            <Text style={styles.shareText}>SHARE</Text>
          </TouchableOpacity>

          {/* Conditional Button: Either "Continue with Selected Player" or "Find Random Player" */}
          {hasOpponent ? (
            <TouchableOpacity 
              style={[styles.randomButton, { backgroundColor: '#4CAF50' }]}
              onPress={navigateToSelectedUser}
            >
              <Text style={styles.randomText}>CONTINUE WITH SELECTED PLAYER</Text>
            </TouchableOpacity>
          ) : (
            <TouchableOpacity 
              style={styles.randomButton}
              onPress={handleFindRandom}
            >
              <Text style={styles.randomText}>FIND RANDOM PLAYER</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#1a1424',
  },
  container: {
    flex: 1,
    padding: 20,
    alignItems: 'center',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    alignSelf: 'stretch',
    marginBottom: 40,
    marginTop: 20,
  },
  backButton: {
    padding: 10,
  },
  headerText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  greenText: {
    color: '#4CAF50',
  },
  qrContainer: {
    marginBottom: 30,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pinCode: {
    color: '#fff',
    fontSize: 32,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 8,
  },
  tapToCopy: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  infoText: {
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 40,
  },
  buttonContainer: {
    width: '100%',
    gap: 20,
  },
  shareButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#4CAF50',
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
    gap: 8,
  },
  shareText: {
    color: '#4CAF50',
    fontSize: 16,
    fontWeight: '600',
  },
  randomButton: {
    backgroundColor: '#C21E78',
    borderRadius: 8,
    paddingVertical: 15,
    alignItems: 'center',
    width: '100%',
  },
  randomText: {
    color: '#1A0826',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default GeneratePinQRScreen;