import Bank from "@/components/CelebrityProfileComponents/CelebrityBankScreen";
import React from "react";

export default function TabTwoScreen() {
  return <Bank />;
}
