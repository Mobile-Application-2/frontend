import { useGameStore } from "@/zustand/gameStore";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useEffect } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const ActiveUsers = () => {
  const router = useRouter();
  const params = useSearchParams(); // Access route params
  const { activePlayers, isLoading, error, getActivePlayers, selectGamer } = useGameStore();
  const gameId = params.get("gameId");
  const stake = params.get("stake");
  const name = params.get("name") || "Game Title";

  const lobbyId = params.get("lobbyId"); // Retrieve lobbyId from params
  const lobbyCode = params.get("lobbyCode"); // Retrieve lobbyCode from params

  useEffect(() => {
    getActivePlayers();
    
    // Optional: Set up polling to refresh active users list
    const interval = setInterval(() => {
      getActivePlayers();
    }, 10000); // Refresh every 10 seconds
    
    return () => clearInterval(interval);
  }, []);

  const handleSelectGamer = async (playerId: string) => {
    if (!lobbyId) {
      Alert.alert("Error", "Lobby ID is missing.");
      return;
    }
    if (!lobbyCode) {
      Alert.alert("Error", "Lobby code is missing.");
      return;
    }

    try {
      await selectGamer({ playerId, lobbyId });
      Alert.alert("Success", "Gamer selected successfully!");
      router.push({
        pathname: "/(page)/selected-user",
        params: {
          opponentId: playerId, 
          gameId: gameId, 
          stake: stake, 
          name: name, 
          lobbyCode: lobbyCode, 
          lobbyId: lobbyId
        }
      }); // Navigate to the selected user page
    } catch (err) {
      console.error("Error selecting gamer:", err);
      Alert.alert("Error", "Failed to select gamer. Please try again.");
    }
  };

  const renderItem = ({ item }: any) => (
    <View style={styles.userContainer}>
      <View style={styles.userInfo}>
        <View style={styles.avatar}>
          {item.avatar ? (
            <Image source={{ uri: item.avatar }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarFallback}>
              <Text style={styles.avatarFallbackText}>{item.username?.[0] || '?'}</Text>
            </View>
          )}
        </View>
        <View>
          <Text style={styles.username}>{item.username}</Text>
          <Text style={styles.status}>Online</Text>
        </View>
      </View>
      <TouchableOpacity
        onPress={() => handleSelectGamer(item.userID)}
        style={styles.selectButton}
      >
        <Text style={styles.selectButtonText}>Select</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Loading Indicator */}
      {isLoading ? (
        <View style={{flex: 1, justifyContent: "center", alignItems: "center"}}>
        <ActivityIndicator size="large" color="#FFCC00" />
        </View>
      ) : error ? (
        <Text style={styles.errorText}>{error}</Text>
      ) : activePlayers.length === 0 ? (
        <View style={styles.emptyStateContainer}>
          <Text style={styles.emptyStateText}>No active users found</Text>
        </View>
      ) : (
        <FlatList
          data={activePlayers}
          keyExtractor={(item) => item.userID}
          renderItem={renderItem}
          contentContainerStyle={styles.listContainer}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1E0136",
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
    marginTop: 20,
  },
  backButton: {
    fontSize: 18,
    color: "#FFF",
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFF",
  },
  listContainer: {
    paddingVertical: 10,
  },
  avatarFallback: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "#4B3062",
    justifyContent: "center",
    alignItems: "center",
  },
  avatarFallbackText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  separator: {
    height: 1,
    backgroundColor: "#DDDDDD",
    marginVertical: 16,
    marginHorizontal: 12,
  },
  userContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderRadius: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  userInfo: {
    flexDirection: "row",
    alignItems: "center",
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 70,
    backgroundColor: "#4B3062",
    marginRight: 12,
  },
  username: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FFFFFF",
  },
  status: {
    fontSize: 14,
    color: "#4EFF4E", // Green color for online status
  },
  selectButton: {
    borderWidth: 1,
    borderColor: "#FFCC00",
    paddingVertical: 6,
    paddingHorizontal: 28,
    borderRadius: 8,
  },
  selectButtonText: {
    color: "#ffffff",
    fontWeight: "bold",
    fontSize: 14,
  },
  errorText: {
    color: "#FF5C5C",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
    marginTop: 40,
  },
  emptyStateContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyStateText: {
    color: "#FFFFFF",
    fontSize: 16,
    textAlign: "center",
  }
});

export default ActiveUsers;