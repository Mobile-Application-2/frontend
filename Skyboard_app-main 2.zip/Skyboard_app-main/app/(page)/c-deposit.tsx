import DepositScreen from "@/components/CelebrityWalletComponent/CelebrityDeposit";
import React from "react";

export default function TabTwoScreen() {
  return <DepositScreen/>;
}
