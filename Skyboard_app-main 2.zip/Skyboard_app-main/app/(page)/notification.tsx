import Notification from "@/components/CelebrityProfileComponents/CelebrityNotificationScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Notification />;
}
