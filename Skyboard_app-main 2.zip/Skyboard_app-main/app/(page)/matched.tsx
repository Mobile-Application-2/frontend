import { useProfileStore } from '@/zustand/profileStore';
import { useSocketStore } from '@/zustand/socketStore';
import { useTournamentStore } from '@/zustand/tournamentsStore';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation, useRouter } from 'expo-router';
import { useSearchParams } from 'expo-router/build/hooks';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Alert, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

export default function MatchedScreen() {
  const router = useRouter();
  const navigation = useNavigation();
  const params = useSearchParams();
  const { user } = useProfileStore();
  const { socket, initSocket, emitEvent } = useSocketStore();
  const { getTournamentFixtures, tournaments, isLoadingFixtures, fixturesError } = useTournamentStore();

  const userId = params.get("userId");
  const gameId = params.get("gameId");
  const tournamentId = params.get("tournamentId");
  const gameName = params.get("gameName") || "Tournament Match";
  const lobbyCode = params.get("lobbyCode");
  const [opponent, setOpponent] = useState({
    id: "",
    name: "Waiting...",
    avatar: "👓",
  });
  const [currentUser, setCurrentUser] = useState({
    id: userId || "",
    name: "You",
    avatar: "👓",
  });
  const [isLoading, setIsLoading] = useState(true);
  const [opponentStatus, setOpponentStatus] = useState("waiting");
  const [isLeavingTournament, setIsLeavingTournament] = useState(false);
  
  // Timer state
  const [timeRemaining, setTimeRemaining] = useState(180); // 3 minutes in seconds
  const [timerActive, setTimerActive] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch tournament fixtures when the component mounts
  useEffect(() => {
    if (gameId && lobbyCode) {
      fetchTournamentFixtures();
    }
  }, [gameId, lobbyCode]);

  // Function to fetch tournament fixtures
  const fetchTournamentFixtures = async () => {
    try {
      const fixtureData = await getTournamentFixtures(gameId as string, lobbyCode as string);
      
      if (fixtureData && fixtureData.data.length > 0) {
        // Process the fixture data
        const currentFixture = fixtureData.data[0]; // Using the first fixture from the array
        
        // Get important fixture data
        const joiningCode = currentFixture.joiningCode;
        const gameStarted = currentFixture.gameStarted;
        
        // Find players in the fixture
        const players = currentFixture.players || [];
        
        // Find current user and opponent
        const currentPlayer = players.find(player => player._id === userId);
        const opponentPlayer = players.find(player => player._id !== userId);
        
        // Update current user data if found in fixture
        if (currentPlayer) {
          setCurrentUser({
            id: currentPlayer._id,
            name: currentPlayer.username || "You",
            avatar: currentPlayer.avatar && typeof currentPlayer.avatar === 'string' ? "🧑" : "👓",
          });
        }
        
        // Update opponent data if found in fixture
        if (opponentPlayer) {
          setOpponent({
            id: opponentPlayer._id,
            name: opponentPlayer.username || "Opponent",
            avatar: opponentPlayer.avatar && typeof opponentPlayer.avatar === 'string' ? "🧑" : "👓",
          });
          
          // Set opponent status based on game status
          setOpponentStatus(gameStarted ? "ready" : "waiting");
        }
        
        setIsLoading(false);
      }
    } catch (error: any) {
      Alert.alert("Error", error.message || "Failed to fetch match data");
    }
  };

  // Function to format time as MM:SS
  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
  };

  // Function to handle timer expiration
  const handleTimerExpired = () => {
    if (socket) {
      // Emit event to inform server that we're cancelling due to timeout
      emitEvent('cancel-match-timeout', {
        userId: userId,
        lobbyCode: lobbyCode
      });
    }
    
    Alert.alert(
      "Match Cancelled",
      "Your opponent didn't connect in time. Returning to waiting room for a new match.",
      [
        { 
          text: "OK", 
          onPress: () => router.back() 
        }
      ]
    );
  };

  // Start or stop timer based on opponent status
  useEffect(() => {
    // Clear any existing timer
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }

    // Start timer if opponent is not active
    if (opponentStatus === "not-active") {
      setTimerActive(true);
      setTimeRemaining(180); // Reset to 3 minutes
      
      timerRef.current = setInterval(() => {
        setTimeRemaining(prevTime => {
          if (prevTime <= 1) {
            // Timer has expired
            clearInterval(timerRef.current as NodeJS.Timeout);
            handleTimerExpired();
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    } else {
      setTimerActive(false);
    }

    // Clean up interval on unmount or when opponent status changes
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [opponentStatus]);

  useEffect(() => {
    // Set current user data
    if (user) {
      setCurrentUser({
        id: userId || "",
        name: user.username || "You",
        avatar: user.avatar || "👓",
      });
    }

    // Ensure we have a socket connection
    if (!socket) {
      // If there's no socket (direct navigation), initialize one
      initSocket("/tournament", {
        userId: userId,
        tournamentId: tournamentId,
        lobbyCode: lobbyCode
      });
    }

    // Emit join-tournament-waiting-room event to inform server we're in the matched room
    emitEvent('join-tournament-waiting-room', {
      userId: userId,
      lobbyCode: lobbyCode
    });

    // Socket event listeners
    if (socket) {
      // Add event listeners
      socket.on("opponent-info", (data) => {
        setOpponent({
          id: data.id || data.userId || "",
          name: data.name || data.username || "Opponent",
          avatar: data.avatar || "👓",
        });
        setIsLoading(false);
      });

      socket.on("opponent-not-active", () => {
        setOpponentStatus("not-active");
        setIsLoading(false);
      });

      socket.on("opponent-not-available", () => {
        setOpponentStatus("forfeited");
        setIsLoading(false);
        Alert.alert(
          "Opponent Forfeited",
          "Your opponent didn't show up in time. You win by default!",
          [
            { 
              text: "OK", 
              onPress: () => router.back() 
            }
          ]
        );
      });

      socket.on("start-tournament-fixture", () => {
        setOpponentStatus("ready");
        setIsLoading(false);
      });

      socket.on("error", (error) => {
        Alert.alert("Error", error.message);
      });
    }

    // Clean up on component unmount
    return () => {
      if (socket) {
        // Remove event listeners
        socket.off("opponent-info");
        socket.off("opponent-not-active");
        socket.off("opponent-not-available");
        socket.off("start-tournament-fixture");
        socket.off("error");
        
        // Emit leave event before navigating away
        if (isLeavingTournament) {
          emitEvent('leave-tournament-waiting-room', {
            userId: userId,
            lobbyCode: lobbyCode
          });
        }
      }
      
      // Clear any active timer
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [userId, gameId, lobbyCode, user, socket]);

  // Handle play button press
  const handlePlayGame = () => {
    // Navigate to the game screen
    router.push({
      pathname: `/(games)/${gameName}`,
      params: {
        lobbyCode: lobbyCode,
        gameId: gameId,
        tournamentId: tournamentId,
        gameName: gameName,
        opponent: opponent.name,
        opponentId: opponent.id,
        mode: "tournament"
      }
    });
  };

  // Handle back button press
  const handleBackPress = () => {
    setIsLeavingTournament(true);
    router.back();
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: () => (
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Matched Users</Text>
        </View>
      ),
      headerLeft: () => (
        <TouchableOpacity onPress={handleBackPress} style={styles.backButton}>
          <Ionicons name="chevron-back" color="#fff" size={24} />
        </TouchableOpacity>
      ),
    });
  }, [navigation, router]);

  // Get status message based on opponent status
  const getStatusMessage = () => {
    switch (opponentStatus) {
      case "not-active":
        return "WAITING FOR OPPONENT TO CONNECT...";
      case "forfeited":
        return "OPPONENT FORFEITED";
      case "ready":
        return "PLAY GAME";
      default:
        return "WAITING FOR OPPONENT...";
    }
  };

  // Show a loading indicator or error message if fixtures are loading or there's an error
  if (isLoadingFixtures) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={styles.playerName}>Loading match data...</Text>
      </View>
    );
  }

  if (fixturesError) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={styles.playerName}>Error: {fixturesError}</Text>
        <TouchableOpacity style={styles.playButton} onPress={fetchTournamentFixtures}>
          <Text style={styles.playButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Versus Content */}
      <View style={styles.versusContainer}>
        {/* Left Player (Current User) */}
        <View style={styles.playerContainer}>
          <View style={[styles.avatar, styles.avatarLeft]}>
            <Text style={styles.avatarText}>{currentUser.avatar}</Text>
          </View>
          <Text style={styles.playerName}>{currentUser.name}</Text>
        </View>

        {/* VS Text */}
        <View style={styles.vsContainer}>
          <Text style={styles.vsText}>VS</Text>
        </View>

        {/* Right Player (Opponent) */}
        <View style={styles.playerContainer}>
          <View style={[styles.avatar, styles.avatarRight]}>
            <Text style={styles.avatarText}>{opponent.avatar}</Text>
          </View>
          <Text style={styles.playerName}>{opponent.name}</Text>
          {opponentStatus === "not-active" && (
            <View style={styles.statusBadge}>
              <Text style={styles.statusText}>Not Connected</Text>
            </View>
          )}
          {opponentStatus === "forfeited" && (
            <View style={[styles.statusBadge, styles.forfeitedBadge]}>
              <Text style={styles.statusText}>Forfeited</Text>
            </View>
          )}
        </View>
      </View>

      {/* Play Button */}
      <TouchableOpacity 
        style={[
          styles.playButton, 
          isLoading && styles.disabledButton,
          opponentStatus === "forfeited" && styles.forfeitedButton
        ]} 
        onPress={handlePlayGame}
        disabled={isLoading || opponentStatus === "forfeited"}
      >
        <Text style={styles.playButtonText}>
          {getStatusMessage()}
        </Text>
      </TouchableOpacity>

      {/* Timer */}
      {timerActive && (
        <View style={styles.timerContainer}>
          <Text style={styles.timerLabel}>Opponent must connect in:</Text>
          <Text style={styles.timerText}>{formatTime(timeRemaining)}</Text>
          <Text style={styles.timerSubtext}>
            Match will be cancelled if time runs out
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0F0B1E',
    paddingTop: 48,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 40,
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    color: '#fff',
    fontSize: 18,
    marginLeft: 8,
  },
  versusContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
  },
  playerContainer: {
    alignItems: 'center',
    position: 'relative',
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  avatarLeft: {
    backgroundColor: '#FF9A9E',
  },
  avatarRight: {
    backgroundColor: '#96FBC4',
  },
  avatarText: {
    fontSize: 32,
  },
  playerName: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  playerSubtext: {
    color: '#fff',
    fontSize: 16,
    opacity: 0.8,
  },
  vsContainer: {
    backgroundColor: '#96FBC4',
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    transform: [{ rotate: '45deg' }],
  },
  vsText: {
    color: '#0F0B1E',
    fontSize: 16,
    fontWeight: 'bold',
    transform: [{ rotate: '-45deg' }],
  },
  playButton: {
    backgroundColor: '#96FBC4',
    marginHorizontal: 20,
    marginBottom: 16,
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  playButtonText: {
    color: '#0F0B1E',
    fontSize: 16,
    fontWeight: 'bold',
  },
  disabledButton: {
    backgroundColor: '#9E9E9E',
    opacity: 0.6,
  },
  forfeitedButton: {
    backgroundColor: '#FF9A9E',
    opacity: 0.8,
  },
  statusBadge: {
    position: 'absolute',
    top: 0,
    right: -10,
    backgroundColor: '#FFA500',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  forfeitedBadge: {
    backgroundColor: '#FF0000',
  },
  statusText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  timerContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    marginHorizontal: 20,
    marginBottom: 32,
    padding: 16,
    alignItems: 'center',
  },
  timerLabel: {
    color: '#fff',
    fontSize: 14,
    marginBottom: 4,
  },
  timerText: {
    color: '#FF9A9E',
    fontSize: 32,
    fontWeight: 'bold',
    marginVertical: 8,
  },
  timerSubtext: {
    color: '#fff',
    fontSize: 12,
    opacity: 0.7,
  }
});