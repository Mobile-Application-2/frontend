import AllUsers from "@/components/CelebrityAllUsersScreen";
import React from "react";

export default function TabTwoScreen() {
  return <AllUsers />;
}
