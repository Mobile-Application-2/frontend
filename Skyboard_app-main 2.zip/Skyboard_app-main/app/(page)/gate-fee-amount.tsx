import { useCelebrityTournamentStore } from "@/zustandCelebrity/tournamentsStore";
import { useLocalSearchParams, useRouter } from "expo-router";
import * as SecureStore from 'expo-secure-store';
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

export default function GateFeeAmount() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const [gateFee, setGateFee] = useState(100);
  const [isLoading, setIsLoading] = useState(false);
  
  // Get the tournament functions from the store
  const { enterPrizes } = useCelebrityTournamentStore();

  // Get parameters from the route
  const tournamentId = params.tournamentId as string;

  const handleIncrement = () => setGateFee((prev) => prev + 100);
  const handleDecrement = () =>
    setGateFee((prev) => Math.max(prev - 100, 100)); // Minimum stake 1000

  // Set preset amounts
  const handlePresetAmount = (amount: number) => {
    setGateFee(amount);
  };

  const handleAddGateFee = async () => {
    try {
      setIsLoading(true);
      
      // Get stored prize data
      const prizesString = await SecureStore.getItemAsync('tournamentPrizes');
      const storedTournamentId = await SecureStore.getItemAsync('tournamentId');
      
      if (!prizesString || !storedTournamentId) {
        throw new Error('Prize data not found in storage');
      }
      
      const prizes = JSON.parse(prizesString);
      
      // Call API to enter prizes with gate fee
      await enterPrizes(storedTournamentId, {
        prizes: prizes,
        hasGateFee: true,
        gateFee: gateFee
      });
      
      // Navigate to waiting room
      router.push({pathname:"/(page)/create-code", params: {tournamentId: storedTournamentId}});
    } catch (error) {
      console.error('Error setting gate fee:', error);
      Alert.alert('Error', `${error || 'Failed to set gate fee. Please try again.'}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <View style={styles.content}>
        <Text style={styles.subheading}>Joining Fee</Text>
        <View style={styles.stakeContainer}>
          <TouchableOpacity onPress={handleDecrement} style={styles.iconButton}>
            <Text style={styles.iconText}>-</Text>
          </TouchableOpacity>
          <View>
            <TextInput
              value={gateFee.toString()}
              style={styles.stakeInput}
              keyboardType="numeric"
              onChangeText={(text) => setGateFee(Number(text) || 0)}
            />
          </View>
          <TouchableOpacity onPress={handleIncrement} style={styles.iconButton}>
            <Text style={styles.iconText}>+</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.presetContainer}>
          <TouchableOpacity 
            style={styles.presetButton}
            onPress={() => handlePresetAmount(1000)}
          >
            <Text style={styles.presetText}>₦1,000</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.presetButton}
            onPress={() => handlePresetAmount(5000)}
          >
            <Text style={styles.presetText}>₦5,000</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.presetButton}
            onPress={() => handlePresetAmount(15000)}
          >
            <Text style={styles.presetText}>₦15,000</Text>
          </TouchableOpacity>
        </View>
        <Text style={styles.infoText}>
          Joining Fee is from ₦100 upwards.
        </Text>
        <TouchableOpacity
          onPress={handleAddGateFee}
          style={[styles.nextButton, isLoading && styles.disabledButton]}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator size="small" color="#1A0826" />
          ) : (
            <Text style={styles.nextButtonText}>Continue</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A0826",
    paddingHorizontal: 24,
    paddingTop: 100,
  },
  backButton: {
    fontSize: 18,
    color: "#FFF",
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFF",
  },
  headerText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#DDA7FF",
  },
  content: {
    marginTop: 30,
    alignItems: "center",
  },
  subheading: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 20,
  },
  stakeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 50,
    alignItems: "center",
    marginBottom: 40,
  },
  iconButton: {
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2D1035",
    borderRadius: 15,
  },
  iconText: {
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "bold",
  },
  stakeInput: {
    width: 100,
    height: 50,
    textAlign: "center",
    fontSize: 20,
    color: "#FFFFFF",
    borderBottomWidth: 2,
    borderBottomColor: "#FFFFFF",
    marginHorizontal: 10,
  },
  presetContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 20,
  },
  presetButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: "#4CAF50",
    borderRadius: 10,
  },
  presetText: {
    color: "#1A0826",
    fontSize: 14,
    fontWeight: "bold",
  },
  infoText: {
    fontSize: 12,
    color: "#FFFFFF",
    marginBottom: 30,
  },
  nextButton: {
    backgroundColor: "#4CAF50",
    width: "100%",
    paddingVertical: 15,
    alignItems: "center",
    borderRadius: 10,
  },
  disabledButton: {
    backgroundColor: "#4CAF50",
    width: "100%",
    opacity: 0.6,
    paddingVertical: 15,
    alignItems: "center",
    borderRadius: 10,
  },
  nextButtonText: {
    color: "#1A0826",
    fontSize: 16,
    fontWeight: "bold",
  },
});