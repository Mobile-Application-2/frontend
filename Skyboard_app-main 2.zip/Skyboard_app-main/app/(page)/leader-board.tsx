import CelebrityLeaderboardScreen from "@/components/CelebrityProfileComponents/CelebrityLeaderBoard";
import React from "react";

export default function LeaderBoard() {
  return <CelebrityLeaderboardScreen />;
}