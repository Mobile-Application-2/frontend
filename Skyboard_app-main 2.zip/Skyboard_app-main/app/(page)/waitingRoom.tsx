import { useProfileStore } from "@/zustand/profileStore";
import { Feather } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { DefaultEventsMap } from "@socket.io/component-emitter";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import { io, Socket } from "socket.io-client";

interface ActivePlayer {
  socketId: string;
  userId: string;
  username: string;
  userAvatar: string;
}

interface LobbyUser {
  socketId: string;
  userId: string;
  username: string;
  userAvatar: string;
  lobbyCode: string;
}

const SelectedUser = () => {
    const router = useRouter();
    const params = useSearchParams();
    const gameId = params.get("gameId");
    const opponentId = params.get("opponentId");
    const amount = params.get("stake");
    const gameName = params.get("name") || "Game Title";
    const lobbyId = params.get("lobbyId");
    const lobbyCode = params.get("lobbyCode");
    
    const [activePlayers, setActivePlayers] = useState<ActivePlayer[]>([]);
    const [socket, setSocket] = useState<Socket<DefaultEventsMap, DefaultEventsMap> | null>(null);
    const [lobbyUsers, setLobbyUsers] = useState<LobbyUser[]>([]);
    const [opponentJoined, setOpponentJoined] = useState(false);
    const [joinedLobby, setJoinedLobby] = useState(false);
    const [isWaiting, setIsWaiting] = useState(true);
    
    const [userData, setUserData] = useState<{
        username: string;
        userAvatar: string;
        opponentUsername: string;
        opponentAvatar: string;
    } | null>(null);

    const { getUserProfile, user, isLoading } = useProfileStore();

    useEffect(() => {
        // Initialize socket connection
        const newSocket: Socket<DefaultEventsMap, DefaultEventsMap> = io(`${process.env.EXPO_PUBLIC_GAME_URL}`);
        setSocket(newSocket);
    
        // Listen for active players updates
        newSocket.on('get_active', (data) => {
            const players = Array.isArray(data) ? data : [data];
            setActivePlayers(players);
        });
        
        // Listen for lobby users updates
        newSocket.on('lobby_users', (data) => {
            const users = Array.isArray(data) ? data : [data];
            setLobbyUsers(users);
            
            // Check if there are two users with the same lobbyCode
            const usersInSameLobby = users.filter(user => user.lobbyCode === lobbyCode);
            setOpponentJoined(usersInSameLobby.length >= 2);
            
            if (usersInSameLobby.length >= 2) {
                setIsWaiting(false);
            }
        });
        
        return () => {
            if (newSocket) {
                // Leave the lobby before disconnecting
                if (joinedLobby && lobbyCode) {
                    newSocket.emit('leave_lobby', { lobbyCode });
                }
                newSocket.disconnect();
            }
        };
    }, [lobbyCode, joinedLobby]);

    useEffect(() => {
        const fetchSelectedUserData = async () => {
            try {
                const lastResponse = await AsyncStorage.getItem('lastSelectedUserResponse');
                if (lastResponse) {
                    const parsedResponse = JSON.parse(lastResponse);
                    setUserData({
                        username: parsedResponse.data.username,
                        userAvatar: parsedResponse.data.userAvatar,
                        opponentUsername: parsedResponse.data.opponentUsername,
                        opponentAvatar: parsedResponse.data.opponentAvatar
                    });
                }
            } catch (error) {
                console.error("Error fetching user data:", error);
            }
        };

        fetchSelectedUserData();
        getUserProfile();
    }, []);
    
    // Join the lobby when component mounts and user data is available
    useEffect(() => {
        if (socket && user && lobbyCode && !joinedLobby) {
            socket.emit('join_lobby', {
                userId: user._id,
                username: userData?.username || user.username || "User",
                userAvatar: userData?.userAvatar || "https://placekitten.com/100/100",
                lobbyCode: lobbyCode
            });
            setJoinedLobby(true);
        }
    }, [socket, user, userData, lobbyCode, joinedLobby]);

    const handleDisplayGame = () => {
        if (!userData || !gameId || !opponentId || !gameName || !user?._id) {
            return (
                <View style={styles.container}>
                    <Text style={[styles.userName, {color: 'red'}]}>
                        Unable to display game, Some parameters are missing
                    </Text>
                </View>
            );
        }
        
        // If opponent has not joined yet, don't proceed
        if (!opponentJoined) {
            alert("Waiting for opponent to join the game");
            return;
        }
        
        router.push({
            pathname: `/(games)/${gameName}`,
            params: {
                userId: user?._id,
                opponentId: opponentId,
                gameId: gameId,
                gameName: gameName,
                amount: amount,
                lobbyCode: lobbyCode,
                lobbyId: lobbyId
            }
        });
    };

    const renderActivePlayer = ({ item }: { item: ActivePlayer }) => (
        <View style={styles.activePlayerItem}>
            <Image
                source={{ uri: item.userAvatar }}
                style={styles.activePlayerAvatar}
            />
            <Text style={styles.activePlayerName}>{item.username}</Text>
            <View style={styles.activeStatus} />
        </View>
    );

    if (!userData) {
        return (
            <View style={styles.container}>
                <Text style={styles.userName}>Loading user data...</Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <TouchableOpacity
                    onPress={() => router.back()}
                    style={styles.backButton}
                >
                    <Feather name="chevron-left" size={24} color="white" />
                </TouchableOpacity>
                <Text style={styles.headerTitle}>Selected Users</Text>
                <TouchableOpacity
                    onPress={() => router.back()}
                    style={styles.backButton}
                >
                    <Feather name="share-2" size={24} color="#0A001A" />
                </TouchableOpacity>
            </View>

            {/* Lobby Code Section */}
            <View style={styles.lobbyCodeContainer}>
                <Text style={styles.lobbyCodeLabel}>Lobby Code:</Text>
                <Text style={styles.lobbyCodeValue}>{lobbyCode}</Text>
                <Text style={styles.lobbyCodeInstruction}>
                    Share this code with your opponent to join the game
                </Text>
            </View>

            {/* Waiting Status */}
            {isWaiting && (
                <View style={styles.waitingContainer}>
                    <ActivityIndicator size="large" color="#FFD200" />
                    <Text style={styles.waitingText}>
                        Waiting for opponent to join with code: {lobbyCode}
                    </Text>
                </View>
            )}

            {/* Active Players Section */}
            <View style={styles.activePlayers}>
                <Text style={styles.activePlayersTitle}>Active Players</Text>
                <FlatList
                    data={activePlayers}
                    renderItem={renderActivePlayer}
                    keyExtractor={(item) => item.socketId}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    contentContainerStyle={styles.activePlayersContent}
                />
            </View>
            
            {/* Users Section */}
            <View style={styles.usersContainer}>
                {/* User 1 */}
                <View style={styles.userWrapper}>
                    <View
                        style={[styles.avatarContainer, { backgroundColor: "#FFC4F0" }]}
                    >
                        <Image
                            source={{ uri: userData.userAvatar }}
                            style={styles.avatar}
                        />
                    </View>
                    <Text style={styles.userName}>{userData.username}</Text>
                    <Text style={styles.badge}>YOU</Text>
                </View>

                {/* VS */}
                <Text style={styles.vsText}>VS</Text>

                {/* User 2 */}
                <View style={styles.userWrapper}>
                    <View
                        style={[
                            styles.avatarContainer, 
                            { backgroundColor: "#C8F8E8" },
                            !opponentJoined && styles.opponentNotJoined
                        ]}
                    >
                        <Image
                            source={{ uri: userData.opponentAvatar }}
                            style={styles.avatar}
                        />
                        {!opponentJoined && (
                            <View style={styles.waitingOverlay}>
                                <Text style={styles.waitingOverlayText}>Waiting...</Text>
                            </View>
                        )}
                    </View>
                    <Text style={styles.userName}>{userData.opponentUsername}</Text>
                    <Text style={styles.opponentBadge}>
                        {opponentJoined ? "OPPONENT" : "WAITING"}
                    </Text>
                </View>
            </View>

            {/* Play Button */}
            <TouchableOpacity 
                style={[
                    styles.playButton,
                    !opponentJoined && styles.playButtonDisabled
                ]} 
                onPress={handleDisplayGame}
                disabled={!opponentJoined}
            >
                <Text style={styles.playButtonText}>
                    {opponentJoined ? "PLAY GAME" : "WAITING FOR OPPONENT"}
                </Text>
            </TouchableOpacity>

            {/* Footer Note */}
            <Text style={styles.footerText}>
                Once you start the game, if you exit from the game, you will lose your stake
            </Text>
        </View>
    );
};

const styles = StyleSheet.create({
    // ... existing styles ...
    activePlayers: {
        marginBottom: 20,
    },
    activePlayersTitle: {
        color: '#FFFFFF',
        fontSize: 16,
        fontWeight: 'bold',
        marginBottom: 10,
    },
    activePlayersContent: {
        paddingHorizontal: 10,
    },
    activePlayerItem: {
        alignItems: 'center',
        marginRight: 15,
        position: 'relative',
    },
    activePlayerAvatar: {
        width: 50,
        height: 50,
        borderRadius: 25,
        borderWidth: 2,
        borderColor: '#FFD200',
    },
    activePlayerName: {
        color: '#FFFFFF',
        fontSize: 12,
        marginTop: 5,
    },
    activeStatus: {
        position: 'absolute',
        right: 0,
        top: 0,
        width: 12,
        height: 12,
        borderRadius: 6,
        backgroundColor: '#4CAF50',
        borderWidth: 2,
        borderColor: '#FFFFFF',
    },
    container: {
        flex: 1,
        backgroundColor: "#0A001A",
        paddingHorizontal: 20,
        paddingVertical: 30,
    },
    header: {
        flexDirection: "row",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: 40,
    },
    backButton: {
        fontSize: 18,
        color: "#FFF",
        marginRight: 10,
    },
    headerTitle: {
        fontSize: 20,
        fontWeight: "bold",
        color: "#FFF",
    },
    usersContainer: {
        flexDirection: "column",
        justifyContent: "space-between",
        gap: 70,
        alignItems: "center",
        marginBottom: 40,
        marginTop: 40,
    },
    userWrapper: {
        alignItems: "center",
    },
    avatarContainer: {
        width: 100,
        height: 100,
        borderRadius: 50,
        justifyContent: "center",
        alignItems: "center",
        marginBottom: 10,
        borderWidth: 5,
        borderColor: "#FFD200",
        position: "relative",
    },
    opponentNotJoined: {
        borderColor: "#808080",
        opacity: 0.7,
    },
    waitingOverlay: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: "rgba(0,0,0,0.6)",
        borderRadius: 45,
        justifyContent: "center",
        alignItems: "center",
    },
    waitingOverlayText: {
        color: "#FFFFFF",
        fontWeight: "bold",
    },
    avatar: {
        width: 80,
        height: 80,
        borderRadius: 40,
    },
    userName: {
        color: "#FFFFFF",
        fontSize: 16,
        fontWeight: "bold",
        textAlign: "center",
    },
    badge: {
        position: "absolute",
        top: 50,
        right: 90,
        backgroundColor: "#5CBEFF",
        color: "#FFFFFF",
        fontSize: 12,
        fontWeight: "bold",
        paddingVertical: 2,
        paddingHorizontal: 30,
        borderRadius: 10,
        marginTop: 5,
    },
    opponentBadge: {
        backgroundColor: "#007AFF",
        position: "absolute",
        top: 50,
        left: 70,
        color: "#FFFFFF",
        fontSize: 12,
        fontWeight: "bold",
        paddingVertical: 2,
        paddingHorizontal: 8,
        borderRadius: 10,
        marginTop: 5,
    },
    vsText: {
        color: "#D6FF00",
        fontSize: 24,
        fontWeight: "bold",
    },
    playButton: {
        backgroundColor: "#FFD200",
        borderRadius: 8,
        paddingVertical: 15,
        alignItems: "center",
        marginHorizontal: 20,
        marginBottom: 20,
    },
    playButtonDisabled: {
        backgroundColor: "#808080",
    },
    playButtonText: {
        fontSize: 18,
        fontWeight: "bold",
        color: "#000",
    },
    footerText: {
        color: "#FFFFFF",
        fontSize: 14,
        textAlign: "center",
    },
    lobbyCodeContainer: {
        backgroundColor: "rgba(255, 255, 255, 0.1)",
        borderRadius: 8,
        padding: 15,
        marginBottom: 20,
        alignItems: "center",
    },
    lobbyCodeLabel: {
        color: "#FFFFFF",
        fontSize: 14,
    },
    lobbyCodeValue: {
        color: "#FFD200",
        fontSize: 24,
        fontWeight: "bold",
        marginVertical: 5,
    },
    lobbyCodeInstruction: {
        color: "#FFFFFF",
        fontSize: 12,
        textAlign: "center",
    },
    waitingContainer: {
        alignItems: "center",
        marginBottom: 20,
        padding: 15,
        backgroundColor: "rgba(0, 0, 0, 0.3)",
        borderRadius: 8,
    },
    waitingText: {
        color: "#FFFFFF",
        marginTop: 10,
        textAlign: "center",
    },
});

export default SelectedUser;