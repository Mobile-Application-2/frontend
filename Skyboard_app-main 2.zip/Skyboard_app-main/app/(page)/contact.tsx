import Contact from "@/components/CelebrityProfileComponents/CelebrityContactScreen";
import React from "react";

export default function TabTwoScreen() {
  return <Contact />;
}
