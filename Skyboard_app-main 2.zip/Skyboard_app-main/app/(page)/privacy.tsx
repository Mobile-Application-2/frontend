import PrivacyScreen from "@/components/CelebrityProfileComponents/CelebrityPrivacyScreen";
import React from "react";
export default function TabTwoScreen() {
  return <PrivacyScreen />;
}
