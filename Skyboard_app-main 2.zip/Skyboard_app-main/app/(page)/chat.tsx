import Chat from "@/components/CelebrityChatScreen";
import React from "react";

export default function TabTwoScreen() {
  return <Chat />;
}
