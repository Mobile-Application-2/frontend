import WithdrawalScreen from "@/components/CelebrityWalletComponent/CelebrityWithdraw";
import React from "react";

export default function TabTwoScreen() {
  return <WithdrawalScreen/>;
}
