import Profile from "@/components/CelebrityUserProfileScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Profile />;
}
