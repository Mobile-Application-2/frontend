import { useGameStore } from "@/zustand/gameStore";
import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  Image,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

// Get device dimensions
const { width, height } = Dimensions.get("window");

const GameEntry = () => {
  const router = useRouter();
  const params = useSearchParams();
  const { game, getGame, createLobby, lobby, isLoading, error, clearError } =
    useGameStore();

  const [wagerAmount, setWagerAmount] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);

  // Access parameters
  const id = params.get("id");
  const title = params.get("title") || "Game Title";
  const description = params.get("description") || "No description available.";
  const image = params.get("image");
  const rating = params.get("rating");
  const maxPlayers = params.get("maxPlayers");
  const totalPlayers = params.get("totalPlayers");
  console.log(title);

  useEffect(() => {
    if (id) {
      getGame(id);
    }
  }, [id]);

  const handleCreateLobby = async () => {
    if (!id) {
      Alert.alert("Error", "Game ID is missing.");
      return;
    }

    try {
      clearError();
      await createLobby({ gameId: id, wagerAmount });
      if (lobby) {
        router.push(`/(page)/qr-code`);
      }
    } catch (e) {
      Alert.alert(
        "Error",
        error || "Failed to create lobby. Please try again."
      );
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#1E0136" />
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => router.back()}
            style={styles.backButton}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          >
            <MaterialIcons name="chevron-left" size={24} color="#FFFFFF" />
          </TouchableOpacity>
          <Text
            style={styles.headerTitle}
            numberOfLines={1}
            ellipsizeMode="tail"
          >
            {title}
          </Text>
        </View>

        {/* Game Image */}
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: image } as any}
            style={styles.image}
            resizeMode="contain"
          />
        </View>

        {/* Game Details */}
        <View style={styles.detailsContainer}>
          <Text style={styles.rating}>Rating: {rating} ⭐</Text>
          <Text style={styles.players}>Max Players: {maxPlayers}</Text>
          <Text style={styles.players}>Total Players: {totalPlayers}</Text>
        </View>

        {/* Description */}
        <Text style={styles.description}>{description}</Text>

        {/* Buttons */}
        <View style={styles.buttonContainer}>
          <TouchableOpacity
            onPress={() => {
              setLoading(true);
              router.push({
                pathname: "/(page)/stake",
                params: {
                  gameId: id,
                  name: title,
                },
              });
              setLoading(false);
            }}
            style={styles.createLobbyButton}
          >
            {loading ? (
              <ActivityIndicator size={"small"} color={"white"} />
            ) : (
              <Text style={styles.createLobbyText}>CREATE LOBBY</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() =>
              router.push({
                pathname: "/(page)/join-game",
                params: {
                  gameId: id,
                  name: title,
                  image: image,
                },
              })
            }
            style={styles.joinLobbyButton}
          >
            <Text style={styles.joinLobbyText}>JOIN LOBBY</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#1E0136", // Dark purple background
  },
  container: {
    flex: 1,
    backgroundColor: "#1E0136",
  },
  contentContainer: {
    paddingHorizontal: width * 0.05, // 5% of screen width as padding
    paddingBottom: height * 0.05, // 5% of screen height as bottom padding
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: height * 0.02,
    marginTop: StatusBar.currentHeight || height * 0.05,
    width: "100%",
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: Math.min(width * 0.05, 20), // Responsive font size with max cap
    fontWeight: "bold",
    color: "#FFF",
    flex: 1,
    marginLeft: 10,
  },
  imageContainer: {
    width: "100%",
    height: height * 0.3, // 30% of screen height
    marginBottom: height * 0.02,
    borderRadius: 10,
    overflow: "hidden",
  },
  image: {
    width: "100%",
    height: "100%",
    borderRadius: 10,
  },
  detailsContainer: {
    marginVertical: height * 0.015,
    padding: width * 0.03,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 8,
    width: "100%",
  },
  rating: {
    color: "#FFCC00",
    fontSize: Math.min(width * 0.04, 16),
    marginBottom: 5,
  },
  players: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.035, 14),
    marginBottom: 5,
  },
  description: {
    fontSize: Math.min(width * 0.035, 14),
    color: "#FFF",
    textAlign: "center",
    marginBottom: height * 0.03,
    lineHeight: Math.min(width * 0.05, 20),
  },
  buttonContainer: {
    width: "100%",
  },
  createLobbyButton: {
    backgroundColor: "#FFCC00", // Yellow
    paddingVertical: height * 0.02,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: height * 0.015,
    width: "100%",
  },
  createLobbyText: {
    color: "#000",
    fontWeight: "bold",
    fontSize: Math.min(width * 0.04, 16),
  },
  joinLobbyButton: {
    borderWidth: 2,
    borderColor: "#FFCC00",
    paddingVertical: height * 0.02,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: height * 0.015,
    width: "100%",
  },
  joinLobbyText: {
    color: "#FFCC00",
    fontWeight: "bold",
    fontSize: Math.min(width * 0.04, 16),
  },
  tournamentButton: {
    backgroundColor: "#FFCC00", // Yellow
    paddingVertical: height * 0.02,
    borderRadius: 8,
    alignItems: "center",
    width: "100%",
  },
});

export default GameEntry;
