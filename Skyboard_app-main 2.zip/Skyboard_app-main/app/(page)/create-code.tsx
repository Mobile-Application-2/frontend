import { useCelebrityTournamentStore } from "@/zustandCelebrity/tournamentsStore";
import { Ionicons } from "@expo/vector-icons";
import * as Clipboard from "expo-clipboard";
import { useLocalSearchParams, useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

export default function EnterCodeScreen() {
  const router = useRouter()
  const [lobbyCode, setLobbyCode] = useState<string[]>(Array(6).fill(""));
  const [copied, setCopied] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const inputs = useRef<(TextInput | null)[]>([]);
  const params = useLocalSearchParams();

  // Get the tournament ID from route params (assuming it's passed when navigating to this screen)
  const tournamentName = (params.tournamentName as string) || "";
  const tournamentId = (params.tournamentId as string) || "";

  // Access the enterCode function from the Zustand store
  const { enterCode, isLoading, error, successMessage } =
    useCelebrityTournamentStore();

  const handleCodeChange = (text: string, index: number) => {
    const newCode = [...lobbyCode];
    newCode[index] = text.slice(-1).toUpperCase(); // Only allow one character per box
    setLobbyCode(newCode);

    // Automatically focus on the next input if it's not the last one
    if (text && index < lobbyCode.length - 1) {
      inputs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    // Check if backspace was pressed and the current input is empty
    if (e.nativeEvent.key === "Backspace" && !lobbyCode[index] && index > 0) {
      // Focus on the previous input
      inputs.current[index - 1]?.focus();
    }
  };

  const handleCopyCode = async () => {
    const code = lobbyCode.join("");
    await Clipboard.setStringAsync(code);
    setCopied(true);
    Alert.alert("Success", "Code copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmitCode = async () => {
    const code = lobbyCode.join("");
    if (code.length !== 6) {
      Alert.alert("Invalid Code", "Please enter a complete 6-character code");
      return;
    }

    setIsSubmitting(true);

    try {
      await enterCode(tournamentId, { joiningCode: code });
      Alert.alert("Success", "Successfully joined the tournament!");
      router.push({pathname:'/(tab)/tournaments', params: {tournamentName: tournamentName}})
    } catch (err: any) {
      Alert.alert(
        "Error",
        err.message || "Failed to join the tournament. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Generate random code on mount
  useEffect(() => {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const randomCode = Array(6)
      .fill("")
      .map(() =>
        characters.charAt(Math.floor(Math.random() * characters.length))
      );
    setLobbyCode(randomCode);
  }, []);

  // Show error message if the store has an error
  useEffect(() => {
    if (error) {
      Alert.alert("Error", error);
    }
  }, [error]);

  // Show success message if the store has one
  useEffect(() => {
    if (successMessage) {
      Alert.alert("Success", successMessage);
    }
  }, [successMessage]);

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>
            Enter <Text style={styles.highlight}>Code</Text>
          </Text>
          <Text style={styles.subtitle}>
            Enter the code to create a {tournamentName} tournament
          </Text>
        </View>

        {/* Lobby Code Display */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>ENTER {tournamentName} TOURNAMENT CODE</Text>

          <View style={styles.codeContainer}>
            {lobbyCode.map((digit, index) => (
              <TextInput
                key={index}
                ref={(ref) => (inputs.current[index] = ref)}
                style={styles.codeInput}
                value={digit}
                onChangeText={(text) => handleCodeChange(text, index)}
                onKeyPress={(e) => handleKeyPress(e, index)}
                maxLength={1}
                autoCapitalize="characters"
              />
            ))}
          </View>

          {/* Copy Button - Moved above Submit Button */}
          <TouchableOpacity onPress={handleCopyCode} style={styles.copyButton}>
            <Ionicons name="copy-outline" size={20} color="white" />
            <Text style={styles.copyButtonText}>
              {copied ? "Copied!" : "Copy Code"}
            </Text>
          </TouchableOpacity>
          
          {/* Submit Button - Now disabled until copied */}
          <TouchableOpacity
            onPress={handleSubmitCode}
            style={[
              styles.submitButton,
              !copied && styles.disabledButton
            ]}
            disabled={isLoading || isSubmitting || !copied}
          >
            {isLoading || isSubmitting ? (
              <ActivityIndicator color="white" size="small" />
            ) : (
              <>
                <Ionicons
                  name="arrow-forward-outline"
                  size={20}
                  color="white"
                />
                <Text style={styles.submitButtonText}>Submit Code</Text>
              </>
            )}
          </TouchableOpacity>

          {!copied && (
            <Text style={styles.copyInstructionText}>
              Please copy the code first before submitting
            </Text>
          )}
        </View>

        {/* Instructions */}
        <View style={styles.instructions}>
          <Text style={styles.instructionText}>
            This is code provided by you, the tournament organizer
          </Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A001A",
    padding: 16,
  },
  content: {
    flex: 1,
    justifyContent: "center",
    maxWidth: 400,
    alignSelf: "center",
    width: "100%",
  },
  header: {
    alignItems: "center",
    marginBottom: 48,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "white",
  },
  highlight: {
    color: "#C21E78",
  },
  subtitle: {
    color: "#9ca3af",
    marginTop: 8,
  },
  card: {
    backgroundColor: "#2A002A",
    padding: 32,
    borderRadius: 12,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
  cardTitle: {
    fontSize: 18,
    color: "white",
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 24,
  },
  codeContainer: {
    flexDirection: "row",
    justifyContent: "center",
    gap: 8,
    marginBottom: 24,
  },
  codeInput: {
    width: 48,
    height: 48,
    borderWidth: 2,
    borderColor: "#C21E78",
    color: "white",
    fontSize: 24,
    textAlign: "center",
    borderRadius: 8,
    backgroundColor: "transparent",
  },
  submitButton: {
    backgroundColor: "#C21E78",
    padding: 12,
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    marginTop: 12,
  },
  disabledButton: {
    backgroundColor: "#666",
    opacity: 0.7,
  },
  submitButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
  copyButton: {
    backgroundColor: "#E91E63",
    padding: 12,
    borderRadius: 8,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
  },
  copyButtonText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
  copyInstructionText: {
    color: "#9ca3af",
    fontSize: 12,
    textAlign: "center",
    marginTop: 8,
  },
  instructions: {
    marginTop: 32,
    alignItems: "center",
  },
  instructionText: {
    color: "#9ca3af",
    textAlign: "center",
  },
  expiryText: {
    color: "#9ca3af",
    fontSize: 12,
    marginTop: 8,
    textAlign: "center",
  },
});