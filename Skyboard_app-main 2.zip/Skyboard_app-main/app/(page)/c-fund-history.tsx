import FundHistoryScreen from "@/components/CelebrityWalletComponent/CelebrityFundHistory";
import React from "react";

export default function TabTwoScreen() {
  return <FundHistoryScreen/>;
}
