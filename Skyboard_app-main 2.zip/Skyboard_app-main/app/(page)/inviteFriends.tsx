import InviteFriend from "@/components/CelebrityProfileComponents/CelebrityInviteFriendsScreen";
import React from "react";

export default function TabTwoScreen() {
  return <InviteFriend />;
}
