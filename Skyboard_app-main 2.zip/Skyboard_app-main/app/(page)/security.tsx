import Security from "@/components/CelebrityProfileComponents/CelebritySecurityScreen";
import React from "react";
export default function TabTwoScreen() {
  return <Security />;
}
