import { BarcodeScanningResult, CameraType, CameraView, useCameraPermissions } from 'expo-camera';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from "react";
import { Alert, StyleSheet, Text, TouchableOpacity, View } from "react-native";

const ScanCodeScreen = () => {
  const router = useRouter();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState<boolean>(false);
  const [scannerActive, setScannerActive] = useState<boolean>(false);
  const [scannedData, setScannedData] = useState<string | null>(null);
  const [facing] = useState<CameraType>('back');

  useEffect(() => {
    // Request permission when component mounts if not already requested
    if (permission && !permission.granted) {
      requestPermission();
    }
  }, [permission, requestPermission]);

  const startScanner = () => {
    setScanned(false);
    setScannerActive(true);
  };

  const handleBarCodeScanned = (result: BarcodeScanningResult) => {
    if (scanned || !scannerActive) return;
    
    setScanned(true);
    setScannerActive(false);
    
    const data = result.data;
    setScannedData(data);
    
    Alert.alert(
      "QR Code Scanned",
      `QR code with data: ${data} has been scanned successfully.`,
      [{ text: "OK" }]
    );
  };

  const handleEnter = () => {
    if (scannedData) {
      // You can pass the scanned data to the next screen if needed
      router.push({
        pathname: '/(page)/waitingRoom',
        params: { qrData: scannedData }
      });
    } else {
      Alert.alert("No QR Code Scanned", "Please scan a QR code first.");
    }
  };

  if (!permission) {
    return (
      <View style={styles.container}>
        <Text style={styles.permissionText}>Requesting camera permission...</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.container}>
        <Text style={styles.permissionText}>No access to camera</Text>
        <TouchableOpacity 
          style={styles.enterPinButton}
          onPress={() => router.push('/(page)/join-otp')}
        >
          <Text style={styles.buttonText}>ENTER PIN INSTEAD</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.enterButton}
          onPress={requestPermission}
        >
          <Text style={styles.buttonText}>GRANT PERMISSION</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Buttons Row */}
      <View style={styles.buttonRow}>
        <TouchableOpacity 
          onPress={() => router.push('/(page)/join-otp')} 
          style={styles.enterPinButton}
        >
          <Text style={styles.buttonText}>ENTER PIN</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.scanQrButton, scannerActive && styles.activeButton]}
          onPress={startScanner}
        >
          <Text style={styles.buttonText}>SCAN QR CODE</Text>
        </TouchableOpacity>
      </View>

      {/* QR Code Scanner */}
      <View style={styles.qrScanner}>
        {scannerActive ? (
          <CameraView
            style={StyleSheet.absoluteFillObject}
            facing={facing}
            barcodeScannerSettings={{
              barcodeTypes: ['qr'],
            }}
            onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
          />
        ) : (
          <View style={styles.qrPlaceholder}>
            <Text style={styles.scannerInstructions}>
              {scannedData ? "QR Code Scanned!" : "Tap 'SCAN QR CODE' to start scanning"}
            </Text>
          </View>
        )}
        {scannerActive && (
          <View style={styles.scannerOverlay}>
            <View style={styles.scannerTargetBox} />
          </View>
        )}
      </View>

      {/* Enter Button */}
      <TouchableOpacity 
        onPress={handleEnter} 
        style={[styles.enterButton, !scannedData && styles.disabledButton]}
        disabled={!scannedData}
      >
        <Text style={styles.buttonText}>ENTER</Text>
      </TouchableOpacity>
      
      {scannedData && (
        <Text style={styles.scannedDataText}>
          QR Code data: {scannedData.substring(0, 20)}
          {scannedData.length > 20 ? '...' : ''}
        </Text>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A012D", // Dark purple background
    alignItems: "center",
    paddingHorizontal: 20,
    paddingTop: 150,
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 30,
  },
  enterPinButton: {
    borderColor: "#C21E78", // Pink border
    borderWidth: 2,
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 40,
  },
  scanQrButton: {
    backgroundColor: "#C21E78", // Pink button color
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 40,
  },
  activeButton: {
    backgroundColor: "#8B1057", // Darker pink when active
  },
  buttonText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
  },
  qrScanner: {
    position: "relative",
    backgroundColor: "#FFFFFF",
    width: 280,
    height: 280,
    borderRadius: 20,
    marginBottom: 50,
    marginTop: 30,
    overflow: "hidden",
  },
  qrPlaceholder: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2B1945",
  },
  scannerInstructions: {
    color: "#FFFFFF",
    textAlign: "center",
    padding: 20,
  },
  scannerOverlay: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: "center",
    alignItems: "center",
  },
  scannerTargetBox: {
    width: 200,
    height: 200,
    borderWidth: 2,
    borderColor: "#00FF00",
    borderRadius: 10,
    backgroundColor: "transparent",
  },
  enterButton: {
    backgroundColor: "#C21E78", // Pink button
    borderRadius: 10,
    paddingVertical: 15,
    paddingHorizontal: 60,
  },
  disabledButton: {
    backgroundColor: "#6D1243", // Darker pink when disabled
    opacity: 0.7,
  },
  permissionText: {
    color: "#FFFFFF",
    fontSize: 18,
    marginBottom: 20,
    textAlign: "center",
  },
  scannedDataText: {
    color: "#FFFFFF",
    fontSize: 14,
    marginTop: 20,
    textAlign: "center",
  },
});

export default ScanCodeScreen;