import EditProfile from "@/components/CelebrityProfileComponents/CelebrityEditProfileScreen";
import React from "react";
export default function TabTwoScreen() {
  return <EditProfile />;
}
