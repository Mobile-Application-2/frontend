import { useCelebrityTournamentStore } from "@/zustandCelebrity/tournamentsStore";
import DateTimePicker from "@react-native-community/datetimepicker";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useState } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

interface HostGameScreenProps {
  onNext?: () => void;
}

const HostGameScreen: React.FC<HostGameScreenProps> = () => {
  const router = useRouter();
    const params = useSearchParams();
    const gameId = params.get("id") || "No Game ID";
    const image = params.get("image") || "No Game Image";

  const [tournamentName, setTournamentName] = useState<string>("");
  const [noOfWinners, setNoOfWinners] = useState<string>("");
  
  // Registration deadline date/time
  const [registrationDate, setRegistrationDate] = useState<Date>(new Date());
  const [showRegistrationDatePicker, setShowRegistrationDatePicker] = useState<boolean>(false);
  const [showRegistrationTimePicker, setShowRegistrationTimePicker] = useState<boolean>(false);
  const [formattedRegistrationDate, setFormattedRegistrationDate] = useState<string>("");
  const [formattedRegistrationTime, setFormattedRegistrationTime] = useState<string>("");
  
  // Tournament start date/time
  const [startDate, setStartDate] = useState<Date>(new Date());
  const [showStartDatePicker, setShowStartDatePicker] = useState<boolean>(false);
  const [showStartTimePicker, setShowStartTimePicker] = useState<boolean>(false);
  const [formattedStartDate, setFormattedStartDate] = useState<string>("");
  const [formattedStartTime, setFormattedStartTime] = useState<string>("");
  
  // Tournament end date/time
  const [endDate, setEndDate] = useState<Date>(new Date());
  const [showEndDatePicker, setShowEndDatePicker] = useState<boolean>(false);
  const [showEndTimePicker, setShowEndTimePicker] = useState<boolean>(false);
  const [formattedEndDate, setFormattedEndDate] = useState<string>("");
  const [formattedEndTime, setFormattedEndTime] = useState<string>("");

  // Get the tournament store functions
  const { startTournament, isLoading, error } = useCelebrityTournamentStore();

  // Handle registration date change
  const onRegistrationDateChange = (event: any, selectedDate?: Date) => {
    if (Platform.OS === 'android') {
      setShowRegistrationDatePicker(false);
    }
    
    if (selectedDate) {
      // Preserve the time when changing date
      const newDate = new Date(selectedDate);
      newDate.setHours(registrationDate.getHours(), registrationDate.getMinutes());
      setRegistrationDate(newDate);
      setFormattedRegistrationDate(newDate.toLocaleDateString());
      
      if (Platform.OS === 'ios') {
        setShowRegistrationDatePicker(false);
      }
    }
  };

  // Handle registration time change
  const onRegistrationTimeChange = (event: any, selectedTime?: Date) => {
    if (Platform.OS === 'android') {
      setShowRegistrationTimePicker(false);
    }
    
    if (selectedTime) {
      const newDate = new Date(registrationDate);
      newDate.setHours(selectedTime.getHours(), selectedTime.getMinutes());
      setRegistrationDate(newDate);
      setFormattedRegistrationTime(selectedTime.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
      }));
      
      if (Platform.OS === 'ios') {
        setShowRegistrationTimePicker(false);
      }
    }
  };

  // Handle start date change
  const onStartDateChange = (event: any, selectedDate?: Date) => {
    if (Platform.OS === 'android') {
      setShowStartDatePicker(false);
    }
    
    if (selectedDate) {
      // Preserve the time when changing date
      const newDate = new Date(selectedDate);
      newDate.setHours(startDate.getHours(), startDate.getMinutes());
      setStartDate(newDate);
      setFormattedStartDate(newDate.toLocaleDateString());
      
      if (Platform.OS === 'ios') {
        setShowStartDatePicker(false);
      }
    }
  };

  // Handle start time change
  const onStartTimeChange = (event: any, selectedTime?: Date) => {
    if (Platform.OS === 'android') {
      setShowStartTimePicker(false);
    }
    
    if (selectedTime) {
      const newDate = new Date(startDate);
      newDate.setHours(selectedTime.getHours(), selectedTime.getMinutes());
      setStartDate(newDate);
      setFormattedStartTime(selectedTime.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
      }));
      
      if (Platform.OS === 'ios') {
        setShowStartTimePicker(false);
      }
    }
  };

  // Handle end date change
  const onEndDateChange = (event: any, selectedDate?: Date) => {
    if (Platform.OS === 'android') {
      setShowEndDatePicker(false);
    }
    
    if (selectedDate) {
      // Preserve the time when changing date
      const newDate = new Date(selectedDate);
      newDate.setHours(endDate.getHours(), endDate.getMinutes());
      setEndDate(newDate);
      setFormattedEndDate(newDate.toLocaleDateString());
      
      if (Platform.OS === 'ios') {
        setShowEndDatePicker(false);
      }
    }
  };

  // Handle end time change
  const onEndTimeChange = (event: any, selectedTime?: Date) => {
    if (Platform.OS === 'android') {
      setShowEndTimePicker(false);
    }
    
    if (selectedTime) {
      const newDate = new Date(endDate);
      newDate.setHours(selectedTime.getHours(), selectedTime.getMinutes());
      setEndDate(newDate);
      setFormattedEndTime(selectedTime.toLocaleTimeString([], { 
        hour: '2-digit', 
        minute: '2-digit' 
      }));
      
      if (Platform.OS === 'ios') {
        setShowEndTimePicker(false);
      }
    }
  };

  // Validate form before proceeding
  const validateForm = () => {
    if (!tournamentName) {
      Alert.alert("Error", "Please enter a tournament name");
      return false;
    }

    if (!formattedRegistrationDate || !formattedRegistrationTime) {
      Alert.alert("Error", "Please select a registration deadline date and time");
      return false;
    }

    if (!formattedStartDate || !formattedStartTime) {
      Alert.alert("Error", "Please select a tournament start date and time");
      return false;
    }

    if (!formattedEndDate || !formattedEndTime) {
      Alert.alert("Error", "Please select a tournament end date and time");
      return false;
    }

    if (!noOfWinners || parseInt(noOfWinners) < 2) {
      Alert.alert("Error", "Number of winners must be at least 2");
      return false;
    }

    // Check if dates are in the correct order
    if (startDate <= registrationDate) {
      Alert.alert("Error", "Tournament start date must be after registration deadline");
      return false;
    }

    if (endDate <= startDate) {
      Alert.alert("Error", "Tournament end date must be after start date");
      return false;
    }

    return true;
  };

  // Create tournament without gate fee
  const createTournament = async () => {
    try {
      const winnersCount = parseInt(noOfWinners);
      
      const tournamentData = {
        name: tournamentName,
        gameId: gameId, // Using the default game ID
        registrationDeadline: registrationDate.toISOString(),
        startDate: startDate.toISOString(),
        endDate: endDate.toISOString(),
        noOfWinners: winnersCount,
        hasGateFee: false
      };
      
      const response = await startTournament(tournamentData);
      
      // Pass the correct parameters to the prize-amount screen
      router.push({
        pathname: "/(page)/prize-amount",
        params: {
          image: image,
          tournamentId: response._id,
          creatorId: response.creatorId,
          gameId: response.gameId,
          tournamentName: response.name,
          tournamentWinners: response.noOfWinners.toString()
        }
      });
    } catch (err) {
      console.error("Failed to create tournament:", err);
      Alert.alert("Error", error || "Failed to create tournament. Please try again.");
    }
  };

  // Handle form submission
  const handleNext = () => {
    if (validateForm()) {
      createTournament();
    }
  };

  // Render date/time pickers
  const renderDateTimePicker = (show: boolean, date: Date, onChange: (event: any, date?: Date) => void, mode: 'date' | 'time') => {
    if (show) {
      return (
        <DateTimePicker
          value={date}
          mode={mode}
          display={Platform.OS === 'ios' ? 'spinner' : 'default'}
          onChange={onChange}
          minimumDate={new Date()}
          style={Platform.OS === 'ios' ? styles.datePicker : undefined}
        />
      );
    }
    return null;
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.keyboardAvoidingView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollView}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.container}>
            {/* Form Fields */}
            <View style={styles.formContainer}>
              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Tournament Name"
                  placeholderTextColor="#666"
                  value={tournamentName}
                  onChangeText={setTournamentName}
                />
              </View>

              {/* Registration Deadline Section */}
              <Text style={styles.sectionTitle}>Registration Deadline</Text>
              <TouchableOpacity 
                style={styles.inputContainer}
                onPress={() => setShowRegistrationDatePicker(true)}
              >
                <View style={styles.input}>
                  <Text style={formattedRegistrationDate ? styles.inputText : styles.inputPlaceholder}>
                    {formattedRegistrationDate || "Select Registration Deadline Date"}
                  </Text>
                </View>
              </TouchableOpacity>

              {renderDateTimePicker(
                showRegistrationDatePicker, 
                registrationDate, 
                onRegistrationDateChange, 
                'date'
              )}

              <TouchableOpacity 
                style={styles.inputContainer}
                onPress={() => setShowRegistrationTimePicker(true)}
              >
                <View style={styles.input}>
                  <Text style={formattedRegistrationTime ? styles.inputText : styles.inputPlaceholder}>
                    {formattedRegistrationTime || "Select Registration Deadline Time"}
                  </Text>
                </View>
              </TouchableOpacity>

              {renderDateTimePicker(
                showRegistrationTimePicker, 
                registrationDate, 
                onRegistrationTimeChange, 
                'time'
              )}

              {/* Tournament Start Section */}
              <Text style={styles.sectionTitle}>Tournament Start</Text>
              <TouchableOpacity 
                style={styles.inputContainer}
                onPress={() => setShowStartDatePicker(true)}
              >
                <View style={styles.input}>
                  <Text style={formattedStartDate ? styles.inputText : styles.inputPlaceholder}>
                    {formattedStartDate || "Select Tournament Start Date"}
                  </Text>
                </View>
              </TouchableOpacity>

              {renderDateTimePicker(
                showStartDatePicker, 
                startDate, 
                onStartDateChange, 
                'date'
              )}

              <TouchableOpacity 
                style={styles.inputContainer}
                onPress={() => setShowStartTimePicker(true)}
              >
                <View style={styles.input}>
                  <Text style={formattedStartTime ? styles.inputText : styles.inputPlaceholder}>
                    {formattedStartTime || "Select Tournament Start Time"}
                  </Text>
                </View>
              </TouchableOpacity>

              {renderDateTimePicker(
                showStartTimePicker, 
                startDate, 
                onStartTimeChange, 
                'time'
              )}

              {/* Tournament End Section */}
              <Text style={styles.sectionTitle}>Tournament End</Text>
              <TouchableOpacity 
                style={styles.inputContainer}
                onPress={() => setShowEndDatePicker(true)}
              >
                <View style={styles.input}>
                  <Text style={formattedEndDate ? styles.inputText : styles.inputPlaceholder}>
                    {formattedEndDate || "Select Tournament End Date"}
                  </Text>
                </View>
              </TouchableOpacity>

              {renderDateTimePicker(
                showEndDatePicker, 
                endDate, 
                onEndDateChange, 
                'date'
              )}

              <TouchableOpacity 
                style={styles.inputContainer}
                onPress={() => setShowEndTimePicker(true)}
              >
                <View style={styles.input}>
                  <Text style={formattedEndTime ? styles.inputText : styles.inputPlaceholder}>
                    {formattedEndTime || "Select Tournament End Time"}
                  </Text>
                </View>
              </TouchableOpacity>

              {renderDateTimePicker(
                showEndTimePicker, 
                endDate, 
                onEndTimeChange, 
                'time'
              )}

              <View style={styles.inputContainer}>
                <TextInput
                  style={styles.input}
                  placeholder="Number of winners (2 minimum)"
                  placeholderTextColor="#666"
                  keyboardType="numeric"
                  value={noOfWinners}
                  onChangeText={setNoOfWinners}
                />
              </View>

              <TouchableOpacity
                style={[styles.nextButton, isLoading && styles.disabledButton]}
                activeOpacity={0.8}
                onPress={handleNext}
                disabled={isLoading}
              >
                <Text style={styles.nextButtonText}>
                  {isLoading ? "Creating..." : "NEXT"}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#1a1424", // Dark purple background
  },
  keyboardAvoidingView: {
    flex: 1,
  },
  scrollView: {
    flexGrow: 1,
  },
  container: {
    flex: 1,
    padding: 20,
  },
  formContainer: {
    width: "100%",
    marginTop: 20,
  },
  sectionTitle: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 8,
    marginTop: 16,
  },
  inputContainer: {
    marginBottom: 16,
    width: "100%",
    // Shadow for Android
    ...Platform.select({
      android: {
        elevation: 2,
      },
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.2,
        shadowRadius: 1,
      },
    }),
  },
  input: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: Platform.OS === "ios" ? 15 : 12,
    fontSize: 16,
    color: "#000",
    width: "100%",
    height: Platform.OS === "ios" ? 50 : 48,
    justifyContent: "center",
  },
  inputText: {
    color: "#000",
    fontSize: 16,
  },
  inputPlaceholder: {
    color: "#666",
    fontSize: 16,
  },
  nextButton: {
    backgroundColor: "#4CAF50", // Green color
    borderRadius: 8,
    padding: 15,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 24,
    marginBottom: 40, // Added more bottom margin for better scrolling
    width: "100%",
    height: 50,
    // Shadow for Android
    ...Platform.select({
      android: {
        elevation: 3,
      },
      ios: {
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 2,
      },
    }),
  },
  disabledButton: {
    backgroundColor: "#7DAA7F", // Lighter green
    opacity: 0.7,
  },
  nextButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
    textAlign: "center",
  },
  datePicker: {
    width: '100%',
    marginBottom: 16,
  },
});

export default HostGameScreen;