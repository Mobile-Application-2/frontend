import { useCelebrityTournamentStore } from "@/zustandCelebrity/tournamentsStore";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import * as SecureStore from "expo-secure-store";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Keyboard,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import GateFeeModal from "../(modal)/gate-fee";

interface PrizeAmountScreenProps {
  onNext?: () => void;
  navigation?: any;
}

const PrizeAmountScreen: React.FC<PrizeAmountScreenProps> = () => {
  const router = useRouter();
  const params = useLocalSearchParams();
  const otherparams = useSearchParams();
  const { enterPrizes } = useCelebrityTournamentStore();

  const image = otherparams.get("image") || "No Game Image";

  const [totalAmount, setTotalAmount] = useState(1000000); // Default total amount
  const [totalAmountText, setTotalAmountText] = useState("1000000");
  const [amounts, setAmounts] = useState<Record<string, number>>({});
  const [amountsText, setAmountsText] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [currentInputKey, setCurrentInputKey] = useState<string | null>(null);

  // Get the tournament parameters from route params
  const tournamentName = (params.tournamentName as string) || "";
  const tournamentId = (params.tournamentId as string) || "";
  const creatorId = (params.creatorId as string) || "";
  const gameId = (params.gameId as string) || "";
  
  // Ensure we always have at least 1 winner and convert to number
  const rawWinners = (params.tournamentWinners as string) || "2";
  const noOfWinners = Math.max(1, parseInt(rawWinners) || 2);

  // Function to distribute prizes based on number of winners
  const calculatePrizeDistribution = (total: number, winners: number) => {
    const distribution: Record<string, number> = {};
    
    // Handle edge cases
    if (winners <= 0 || total <= 0) {
      return distribution;
    }
    
    // Case 1: Single winner gets everything
    if (winners === 1) {
      distribution["winner1"] = total;
      return distribution;
    }
    
    // Case 2: Two winners (60-40 split)
    if (winners === 2) {
      distribution["winner1"] = Math.floor(total * 0.6); // 60% first place
      distribution["winner2"] = Math.floor(total * 0.4); // 40% second place
      
      // Fix rounding error if any
      const allocated = distribution["winner1"] + distribution["winner2"];
      if (allocated !== total) {
        distribution["winner1"] += (total - allocated);
      }
      
      return distribution;
    }
    
    // Case 3: Three or more winners (25-15-10-50 split)
    distribution["winner1"] = Math.floor(total * 0.25); // 25% first place
    distribution["winner2"] = Math.floor(total * 0.15); // 15% second place
    distribution["winner3"] = Math.floor(total * 0.10); // 10% third place
    
    // Calculate remaining amount
    let allocated = distribution["winner1"] + distribution["winner2"] + distribution["winner3"];
    const remaining = total - allocated;
    
    // Distribute remaining 50% among 4th place onwards
    if (winners > 3 && remaining > 0) {
      const remainingWinners = winners - 3;
      let remainingPerWinner = Math.floor(remaining / remainingWinners);
      
      // Ensure minimum prize amount (at least 1 unit) for everyone
      if (remainingPerWinner < 1) {
        remainingPerWinner = 1;
      }
      
      // Distribute to 4th place onwards
      for (let i = 4; i <= winners; i++) {
        const amount = i < winners ? remainingPerWinner : remaining - (remainingPerWinner * (remainingWinners - 1));
        distribution[`winner${i}`] = Math.max(1, amount); // Ensure minimum value of 1
        allocated += distribution[`winner${i}`];
      }
    }
    
    // Final check to ensure we're allocating exactly the total amount
    if (allocated !== total) {
      distribution["winner1"] += (total - allocated);
    }
    
    return distribution;
  };

  // Initialize amounts state based on number of winners
  useEffect(() => {
    // Handle edge case: prevent resetting values if total is 0
    if (totalAmount <= 0) {
      setTotalAmount(1);
      setTotalAmountText("1");
      return;
    }
    
    const initialAmounts = calculatePrizeDistribution(totalAmount, noOfWinners);
    const initialAmountsText: Record<string, string> = {};
    
    // Convert numbers to strings for text fields
    Object.keys(initialAmounts).forEach(key => {
      initialAmountsText[key] = initialAmounts[key].toString();
    });
    
    setAmounts(initialAmounts);
    setAmountsText(initialAmountsText);
  }, [noOfWinners, totalAmount]);

  // Function to recalculate distribution when one amount is manually changed
  const recalculateDistribution = (changedKey: string, newValue: number) => {
    // Create a copy of current amounts
    const newAmounts = { ...amounts };
    newAmounts[changedKey] = newValue;
    
    // Calculate the total of all amounts
    const currentTotal = Object.values(newAmounts).reduce((sum, val) => sum + val, 0);
    
    // If the total doesn't match, adjust other values proportionally
    if (currentTotal !== totalAmount && Object.keys(newAmounts).length > 1) {
      const difference = totalAmount - currentTotal;
      
      // Don't adjust the changed key
      const keysToAdjust = Object.keys(newAmounts).filter(k => k !== changedKey);
      
      // Calculate current sum of values to adjust
      const sumToAdjust = keysToAdjust.reduce((sum, key) => sum + newAmounts[key], 0);
      
      if (sumToAdjust > 0) {
        // Distribute the difference proportionally
        let remainingDifference = difference;
        
        keysToAdjust.forEach((key, index) => {
          if (index === keysToAdjust.length - 1) {
            // Last key gets any remaining difference
            newAmounts[key] = Math.max(1, newAmounts[key] + remainingDifference);
          } else {
            // Calculate proportional adjustment
            const proportion = newAmounts[key] / sumToAdjust;
            const adjustment = Math.floor(difference * proportion);
            newAmounts[key] = Math.max(1, newAmounts[key] + adjustment);
            remainingDifference -= adjustment;
          }
        });
      } else {
        // If all other values are zero, add the difference to the first key that's not the changed key
        if (keysToAdjust.length > 0) {
          newAmounts[keysToAdjust[0]] = Math.max(1, newAmounts[keysToAdjust[0]] + difference);
        } else {
          // If there's only one key, it must equal the total
          newAmounts[changedKey] = totalAmount;
        }
      }
    }
    
    return newAmounts;
  };

  const updateAmount = (winner: string, increment: boolean) => {
    const step = 100;
    
    setAmounts((prev) => {
      const currentAmount = prev[winner] || 0;
      const newAmount = increment ? currentAmount + step : Math.max(0, currentAmount - step);
      
      // Prevent going negative
      if (newAmount < 0) return prev;
      
      // Recalculate all amounts to maintain total
      return recalculateDistribution(winner, newAmount);
    });
    
    setAmountsText((prev) => {
      const currentAmount = amounts[winner] || 0;
      const newAmount = increment ? currentAmount + step : Math.max(0, currentAmount - step);
      
      if (newAmount < 0) return prev;
      
      const updatedAmounts = recalculateDistribution(winner, newAmount);
      
      // Update all text values
      const newTextValues: Record<string, string> = {};
      Object.keys(updatedAmounts).forEach(key => {
        newTextValues[key] = updatedAmounts[key].toString();
      });
      
      return newTextValues;
    });
  };

  const handleAmountTextChange = (winner: string, text: string) => {
    // Remove any non-numeric characters
    const numericValue = text.replace(/[^0-9]/g, '');
    
    // Update the text value
    setAmountsText((prev) => ({
      ...prev,
      [winner]: numericValue
    }));
    
    // Update the numeric value
    const numValue = numericValue === '' ? 0 : parseInt(numericValue);
    setAmounts((prev) => {
      // Recalculate to maintain total
      return recalculateDistribution(winner, numValue);
    });
    
    // Update all text values to match recalculated amounts
    const updatedAmounts = recalculateDistribution(winner, numValue);
    const newTextValues: Record<string, string> = { ...amountsText };
    Object.keys(updatedAmounts).forEach(key => {
      if (key !== winner) { // Keep the current input as is
        newTextValues[key] = updatedAmounts[key].toString();
      }
    });
    setAmountsText(newTextValues);
  };

  const handleTotalAmountTextChange = (text: string) => {
    // Remove any non-numeric characters
    const numericValue = text.replace(/[^0-9]/g, '');
    
    setTotalAmountText(numericValue);
    
    // Update the numeric value with minimum of 1
    const numValue = numericValue === '' ? 0 : Math.max(1, parseInt(numericValue));
    setTotalAmount(numValue);
  };

  const handleInputFocus = (key: string) => {
    setCurrentInputKey(key);
  };

  const handleInputBlur = () => {
    setCurrentInputKey(null);
  };

  const handleContinue = async (hasGateFee: boolean) => {
    try {
      setIsLoading(true);

      // Ensure all prizes are valid numbers and convert to array
      const prizesArray = Object.values(amounts).map(amount => 
        isNaN(amount) || amount < 0 ? 0 : amount
      );
      
      // Verify we have prizes for each winner
      if (prizesArray.length !== noOfWinners) {
        throw new Error("Prize distribution does not match the number of winners");
      }
      
      // Check if total matches expected amount
      const prizeTotal = prizesArray.reduce((sum, val) => sum + val, 0);
      if (prizeTotal !== totalAmount) {
        // Auto-correct the total by adjusting first prize
        prizesArray[0] += (totalAmount - prizeTotal);
      }

      // Store prizes data temporarily
      await SecureStore.setItemAsync(
        "tournamentPrizes",
        JSON.stringify(prizesArray)
      );
      await SecureStore.setItemAsync(
        "tournamentHasGateFee",
        JSON.stringify(hasGateFee)
      );
      await SecureStore.setItemAsync("tournamentId", tournamentId);
      await SecureStore.setItemAsync("creatorId", creatorId);
      await SecureStore.setItemAsync("gameId", gameId);

      // Navigate based on whether user wants gate fee or not
      if (hasGateFee) {
        router.push({
          pathname: "/(page)/gate-fee-amount",
          params: {
            image: image,
            tournamentName,
            tournamentId,
            creatorId,
            gameId,
          },
        });
      } else {
        // If no gate fee, directly call the API to enter prizes with gateFee = 0
        await enterPrizes(tournamentId, {
          prizes: prizesArray,
          hasGateFee: false,
          gateFee: 0,
        });

        router.push({
          pathname:"/(page)/create-code", 
          params: {
            tournamentId: tournamentId,
            tournamentName: tournamentName
          } });
      }
    } catch (error) {
      console.error("Failed to store prize data or submit to API:", error);
      Alert.alert(
        "Error",
        `${error || "Failed to set gate fee. Please try again."}`
      );
    } finally {
      setIsLoading(false);
      setModalVisible(false);
    }
  };

  const AmountControl = ({
    label,
    value,
    textValue,
    onDecrease,
    onIncrease,
    onTextChange,
    inputKey,
    isTotalAmount = false,
  }: {
    label: string;
    value: number;
    textValue: string;
    onDecrease: () => void;
    onIncrease: () => void;
    onTextChange: (text: string) => void;
    inputKey: string;
    isTotalAmount?: boolean;
  }) => (
    <View style={styles.amountContainer}>
      <Text style={styles.label}>{label}</Text>
      <View style={styles.controlContainer}>
        <TouchableOpacity 
          style={styles.controlButton} 
          onPress={onDecrease}
          disabled={value <= (isTotalAmount ? 1 : 0)}
        >
          <Text style={[
            styles.controlButtonText, 
            value <= (isTotalAmount ? 1 : 0) && styles.disabledText
          ]}>−</Text>
        </TouchableOpacity>
  
        <TextInput
          style={styles.amountText}
          value={textValue}
          onChangeText={onTextChange}
          keyboardType="numeric"
          selectionColor="#4CAF50"
          placeholderTextColor="#999"
          blurOnSubmit={false}
          returnKeyType="next"
          onFocus={() => handleInputFocus(inputKey)}
          onBlur={handleInputBlur}
          onEndEditing={(e) => {
            onTextChange(e.nativeEvent.text || (isTotalAmount ? "1" : "0"));
          }}
        />
  
        <TouchableOpacity 
          style={styles.controlButton} 
          onPress={onIncrease}
        >
          <Text style={styles.controlButtonText}>+</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  // Calculate total amount allocated
  const totalAllocated = Object.values(amounts).reduce(
    (sum, amount) => sum + amount,
    0
  );
  const isAmountInvalid = totalAllocated !== totalAmount || totalAmount <= 0;

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView 
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{flex: 1}}
        keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
      >
        <ScrollView 
          style={styles.container}
          keyboardShouldPersistTaps="handled"
          contentContainerStyle={styles.scrollViewContent}
        >
          <Text style={styles.setAmountText}>SET AMOUNT</Text>

          {/* Amount Controls */}
          <View style={styles.controlsContainer}>
            <AmountControl
              label="SET TOTAL AMOUNT"
              value={totalAmount}
              textValue={totalAmountText}
              onDecrease={() => {
                const newValue = Math.max(1, totalAmount - 100);
                setTotalAmount(newValue);
                setTotalAmountText(newValue.toString());
              }}
              onIncrease={() => {
                const newValue = totalAmount + 100;
                setTotalAmount(newValue);
                setTotalAmountText(newValue.toString());
              }}
              onTextChange={handleTotalAmountTextChange}
              inputKey="totalAmount"
              isTotalAmount={true}
            />

            {/* Dynamically generate winner controls based on noOfWinners */}
            {Object.keys(amounts)
              .sort() // Ensure order: winner1, winner2, etc.
              .map((winnerKey, index) => {
                const position = index + 1;
                const positionSuffix =
                  position === 1
                    ? "ST"
                    : position === 2
                    ? "ND"
                    : position === 3
                    ? "RD"
                    : "TH";

                return (
                  <AmountControl
                    key={winnerKey}
                    label={`${position}${positionSuffix} WINNER`}
                    value={amounts[winnerKey]}
                    textValue={amountsText[winnerKey] || "0"}
                    onDecrease={() => updateAmount(winnerKey, false)}
                    onIncrease={() => updateAmount(winnerKey, true)}
                    onTextChange={(text) => handleAmountTextChange(winnerKey, text)}
                    inputKey={winnerKey}
                  />
                );
            })}
          </View>

          {isAmountInvalid && (
            <Text style={styles.errorText}>
              {totalAmount <= 0 
                ? "Total amount must be greater than zero" 
                : `Total allocated (${totalAllocated.toLocaleString()}) must equal total amount (${totalAmount.toLocaleString()})`}
            </Text>
          )}

          <View style={styles.buttonContainer}>
            <TouchableOpacity
              style={[
                styles.nextButton,
                (isLoading || isAmountInvalid) && styles.disabledButton,
              ]}
              disabled={isLoading || isAmountInvalid}
              onPress={() => {
                // Dismiss keyboard before showing modal
                Keyboard.dismiss();
                setModalVisible(true);
              }}
            >
              {isLoading ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <Text style={styles.nextButtonText}>NEXT</Text>
              )}
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <GateFeeModal
        visible={modalVisible}
        onClose={() => setModalVisible(false)}
        onContinue={handleContinue}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#1a1424",
  },
  container: {
    flex: 1,
    padding: 20,
  },
  scrollViewContent: {
    paddingBottom: 40,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 30,
  },
  backButton: {
    padding: 10,
  },
  backButtonText: {
    color: "#fff",
    fontSize: 24,
  },
  headerText: {
    color: "#fff",
    fontSize: 18,
    marginLeft: 10,
  },
  greenText: {
    color: "#4CAF50",
  },
  setAmountText: {
    color: "#fff",
    fontSize: 14,
    marginBottom: 20,
    textAlign: "center",
  },
  controlsContainer: {
    gap: 24,
    marginBottom: 20,
  },
  amountContainer: {
    gap: 8,
  },
  label: {
    color: "#fff",
    fontSize: 12,
    opacity: 0.8,
  },
  controlContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255, 255, 255, 0.1)",
    paddingBottom: 8,
  },
  controlButton: {
    width: 30,
    height: 30,
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  controlButtonText: {
    color: "#fff",
    fontSize: 20,
    fontWeight: "300",
  },
  disabledText: {
    opacity: 0.3,
  },
  amountText: {
    color: "#fff",
    fontSize: 24,
    fontWeight: "500",
    textAlign: "center",
    minWidth: 120,
    padding: 0,
  },
  buttonContainer: {
    marginTop: 20,
    marginBottom: 30,
  },
  nextButton: {
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    padding: 15,
    alignItems: "center",
  },
  nextButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  disabledButton: {
    opacity: 0.6,
  },
  errorText: {
    color: "#FF6B6B",
    fontSize: 14,
    textAlign: "center",
    marginTop: 10,
  },
});

export default PrizeAmountScreen;