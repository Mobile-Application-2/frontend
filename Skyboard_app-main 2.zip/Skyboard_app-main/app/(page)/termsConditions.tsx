import TermsConditionScreen from "@/components/CelebrityProfileComponents/CelebrityTermsConditionScreen";
import React from "react";
export default function TabTwoScreen() {
  return <TermsConditionScreen />;
}
