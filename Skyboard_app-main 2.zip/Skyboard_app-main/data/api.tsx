import {
  ForgotUserPassword,
  Login,
  Register,
  ResetUserPassword,
  VerifyCode,
} from "@/types/authTypes";
import { CreateLobby, JoinLobby, JoinTournament, SelectGamer } from "@/types/gameTypes";
import { Withdrawals } from "@/types/paymentTypes";
import { Contact, EditProfile } from "@/types/profileTypes";
import apiClient from "./apiClient";

const registerUser = async (data: Register) => {
  const response = await apiClient.post(`/api/auth/register/user`, data);
  return response.data;
};
const verifyOTP = async (data: VerifyCode) => {
  const response = await apiClient.post(`/api/auth/verify-email-otp`, data);
  return response.data;
};
const loginUser = async (data: Login) => {
  const response = await apiClient.post(`/api/auth/login`, data);
  return response.data;
};
const sendEmailOTP = async () => {
  const response = await apiClient.post(`/api/auth/send-email-otp`);
  return response.data;
};
const forgotPassword = async (data: ForgotUserPassword) => {
  const response = await apiClient.patch(
    `/api/auth/send-reset-password-mail`,
    data
  );
  return response.data;
};
const resetPassword = async (data: ResetUserPassword) => {
  const response = await apiClient.patch(`/api/auth/reset-password`, data);
  return response.data;
};

const getUser = async () => {
  const response = await apiClient.get(`/api/auth/profile`);
  return response.data;
};
const contactUs = async (data: Contact) => {
  const response = await apiClient.post(`/api/contact`, data);
  return response.data;
};
const updateProfile = async (data: Partial<EditProfile>) => {
  const response = await apiClient.patch(`/api/auth/profile`, data);
  return response.data;
};
const getGames = async () => {
  const response = await apiClient.get(`/api/games`);
  return response.data;
};
const getTopGames = async () => {
  const response = await apiClient.get(`/api/top/games`);
  return response.data;
};
const getGame = async (data: string) => {
  const response = await apiClient.get(`/api/game/${data}`);
  return response.data;
};
const getTopGamers = async () => {
  const response = await apiClient.get(`/api/top/gamers`);
  return response.data;
};
const getGamers = async () => {
  const response = await apiClient.get(`/api/gamers`);
  return response.data;
};
const searchGamer = async (query: string) => {
  const response = await apiClient.get(`/api/search?q=${query}`);
  return response.data;
};
const getGamer = async (id: string) => {
  const response = await apiClient.get(`/api/gamers/${id}`);
  return response.data;
};
const activePlayers = async () => {
  const response = await apiClient.get(`/api/active-users`);
  return response.data;
};
const selectGamer = async (data: SelectGamer) => {
  const response = await apiClient.post(`/api/gamers/select`, data);
  return response.data;
};
const getTournaments = async (page: number) => {
  const response = await apiClient.get(`/api/tournaments?pageNo=${page}`);
  return response.data;
};
const getParticipatingTournaments = async () => {
  const response = await apiClient.get(`/api/participating-tournaments`);
  return response.data;
};
const createLobby = async (data: CreateLobby) => {
  const response = await apiClient.post(`/api/create-lobby`, data);
  return response.data;
};
const joinLobby = async (data: JoinLobby) => {
  const response = await apiClient.post(`/api/join-lobby`, data);
  return response.data;
};
const joinTournament = async (data: JoinTournament) => {
  const response = await apiClient.post(`/api/join-tournament`, data);
  return response.data;
};
const enterTournament = async (tournamentId: string, lobbyCode: string) => {
  const response = await apiClient.post(`/api/tournament/${tournamentId}/fixtures/${lobbyCode}`);
  return response.data;
};
const getLeaderBoard = async (tournamentId: string) => {
  const response = await apiClient.get(`/api/tournament/${tournamentId}/leaderboard`);
  return response.data;
};
const makeDeposit = async (amount: number) => {
  const response = await apiClient.post(`/api/payment/deposit`, amount);
  return response.data;
};
const makeWithdrawal = async (data: Withdrawals) => {
  const response = await apiClient.post(`/api/payment/withdraw`, data);
  return response.data;
};

const getTransactions = async () => {
  const response = await apiClient.get(`/api/transactions`);
  return response.data;
};
const getBanks = async () => {
  const response = await apiClient.get(`/api/payment/banks`);
  return response.data;
};
const getBankDetails = async (bankCode: string, accountNumber: string) => {
  const response = await apiClient.get(`/api/payment/details/bank/${bankCode}/acc/${accountNumber}`);
  return response.data;
};
const getNotifications = async () => {
  const response = await apiClient.get(`/api/notifications`);
  return response.data;
};

export const api = {
  registerUser,
  verifyOTP,
  sendEmailOTP,
  loginUser,
  forgotPassword,
  resetPassword,
  getUser,
  contactUs,
  updateProfile,
  getGames,
  getGame,
  getGamers,
  searchGamer,
  activePlayers,
  selectGamer,
  getTopGames,
  getTournaments,
  getParticipatingTournaments,
  createLobby,
  getTopGamers,
  getGamer,
  joinLobby,
  joinTournament,
  enterTournament,
  getLeaderBoard,
  makeDeposit,
  makeWithdrawal,
  getTransactions,
  getBanks,
  getBankDetails,
  getNotifications
};
