import { CelebrityRegister, EnterCode, Prizes } from "@/types/authTypes";
import { CreateTournamentData, TournamentPrizesData } from "@/zustandCelebrity/tournamentsStore";
import apiClient from "./apiClient";

const registerCelebrity = async (data: CelebrityRegister) => {
  const response = await apiClient.post(`/api/auth/register/celebrity`, data);
  return response.data;
};
const getTournaments = async () => {
  const response = await apiClient.get(`/api/celebrity/tournaments`);
  return response.data;
};
const startTournaments = async (data: CreateTournamentData) => {
  const response = await apiClient.post(`/api/celebrity/tournaments`, data);
  return response.data;
};
const createTournaments = async (data: TournamentPrizesData) => {
  const response = await apiClient.post(`/api/celebrity/tournaments`, data);
  return response.data;
};
const getCelebrityTournaments = async () => {
  const response = await apiClient.get(`/api/celebrity/tournaments`,);
  return response.data;
};
const enterPrizes = async (tournamentId: string, data: Prizes) => {
  const response = await apiClient.patch(`/api/celebrity/tournament/${tournamentId}/prizes`, data);
  return response.data;
};
const enterCode = async (tournamentId: string, data: EnterCode) => {
  const response = await apiClient.patch(`/api/celebrity/tournament/${tournamentId}/code`, data);
  return response.data;
};

export const celebrityapi = {
    registerCelebrity,
    getTournaments,
    startTournaments,
    createTournaments,
    getCelebrityTournaments,
    enterPrizes,
    enterCode
}