export interface Withdrawals {
    description: string;
    amount: number;
    password: string;
    accountName: string;
    accountNumber: string;
    bankCode: string

}