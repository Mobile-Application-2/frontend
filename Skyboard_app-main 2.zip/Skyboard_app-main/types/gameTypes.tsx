export interface Games {
  _id: string;
  image: string;
  name: string;
  description: string;
  averageRating: number;
  maxPlayers: number;
  totalNumberOfPlayers: number;
  createdAt: string;
  updatedAt: string;
}
export interface Game {
  _id: string;
  image: string;
  name: string;
  description: string;
  averageRating: number;
  maxPlayers: number;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export interface TopGames {
  _id: string;
  image: string;
  name: string;
  description: string;
  averageRating: number;
  maxPlayers: number;
  totalPlays: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateLobby {
  gameId: string;
  wagerAmount: number;
}
export interface JoinLobby {
  lobbyCode: string;
}
export interface JoinTournament {
  joiningCode: string;
}
export interface CreateLobbyResponse {
  code: string;
  _id: string;
}

export interface Gamer {
  _id: string;
  username: string;
  avatar?: string;
  numberOfWins: number;
}
export interface FavoriteGames {
  _id: string;
  image: string;
  name:string;
  description: string;
  averageRating: number;
  createdAt: string;
  updatedAt: string;
  __v: number;
  maxPlayers: 2
}
export interface CurrentGamer {
  _id: string;
  username: string;
  bio: string;
  avatar: string;
  numberOfWins: number;
  favoriteGame: FavoriteGames;
}
export interface SelectGamer {
  playerId: string;
  lobbyId: string;
}
