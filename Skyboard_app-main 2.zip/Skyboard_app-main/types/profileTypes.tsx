export interface UserProfile {
  _id: string;
  username: string;
  email: string;
  emailIsVerified: boolean;
  dob: string;
  phoneNumber: string;
  firstName: string;
  lastName: string;
  phoneNumberIsVerified: boolean;
  govermentIDIsVerified: boolean;
  twoFactorAuthenticationEnabled: boolean;
  walletBalance: number;
  isCelebrity: boolean;
  accountIsActive: boolean;
  createdAt: string;
  avatar?: string;
}
export interface Contact {
  fullName: string;
  email: string;
  message: string;
}

export interface EditProfile {
  fullname: string;
  fistName: string;
  lastName: string;
  username: string;
  email: string;
  emailIsVerified: boolean;
  dob: string;
  phoneNumber: string;
}
