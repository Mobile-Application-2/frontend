import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  BackHandler,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { WebView } from "react-native-webview";
import { io, Socket } from "socket.io-client";

interface GameProps {
  gameName: string;
  gameId: string;
  playerId: string;
  opponentId: string;
  lobbyCode: string;
  lobbyId: string;
  stakeAmount: number;
  tournamentId?: string;
  onGameEnd?: (result: GameResult) => void;
}

interface GameResult {
  winner: string;
  loser: string;
}

const GAME_BASE_URL = process.env.EXPO_PUBLIC_GAME_URL;
const SOCKET_RECONNECTION_ATTEMPTS = 10;
const SOCKET_RECONNECTION_DELAY = 1000;
const SOCKET_CONNECTION_TIMEOUT = 40000;

// Create a global state object to persist modal state across navigation
let globalGameResult: GameResult | null = null;
let globalStakeAmount: number = 0;
let globalShowModal: boolean = false;
let globalPlayerId: string = "";

const MyLudoGame: React.FC<GameProps> = ({
  gameName,
  gameId,
  playerId,
  opponentId,
  stakeAmount,
  tournamentId,
  lobbyCode,
  lobbyId,
  onGameEnd,
}) => {
  const router = useRouter();
  const socketRef = useRef<Socket | null>(null);
  const webViewRef = useRef<WebView | null>(null);
  const [showModal, setShowModal] = useState(globalShowModal);
  const [gameResult, setGameResult] = useState<GameResult | null>(globalGameResult);
  const [isLoading, setIsLoading] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [connectionError, setConnectionError] = useState(false);
  const [isSocketConnected, setIsSocketConnected] = useState(false);
  const [gameUrl, setGameUrl] = useState("");
  const connectionTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Initialize global values on component mount
  useEffect(() => {
    globalPlayerId = playerId;
    globalStakeAmount = stakeAmount;
    
    // Handle Android back button
    const backHandler = BackHandler.addEventListener('hardwareBackPress', () => {
      if (gameStarted) {
        handleGameClosed();
        return true; // Prevent default behavior
      }
      return false; // Let default behavior happen
    });
    
    return () => {
      // Clean up socket and any pending timeouts when component unmounts
      cleanupSocket();
      if (connectionTimeoutRef.current) {
        clearTimeout(connectionTimeoutRef.current);
      }
      backHandler.remove();
    };
  }, [gameStarted]);

  const cleanupSocket = () => {
    if (socketRef.current) {
      console.log("Cleaning up socket connection");
      socketRef.current.off("gameEnd");
      socketRef.current.off("connect");
      socketRef.current.off("disconnect");
      socketRef.current.off("connect_error");
      socketRef.current.disconnect();
      socketRef.current = null;
      setIsSocketConnected(false);
    }
  };

  const initializeSocket = () => {
    return new Promise((resolve, reject) => {
      // Clean up any existing socket connection
      cleanupSocket();

      console.log("Initializing socket connection...");
      
      // Create new socket connection
      const socket = io(`${GAME_BASE_URL}`, {
        transports: ["websocket"],
        reconnection: true,
        reconnectionAttempts: SOCKET_RECONNECTION_ATTEMPTS,
        reconnectionDelay: SOCKET_RECONNECTION_DELAY,
        timeout: SOCKET_CONNECTION_TIMEOUT,
      });

      // Set connection timeout
      connectionTimeoutRef.current = setTimeout(() => {
        console.error("Socket connection timeout");
        reject(new Error("Socket connection timeout"));
        cleanupSocket();
      }, SOCKET_CONNECTION_TIMEOUT);

      // Set up event listeners
      socket.on("connect", () => {
        console.log("Socket connected:", socket.id);
        if (connectionTimeoutRef.current) {
          clearTimeout(connectionTimeoutRef.current);
          connectionTimeoutRef.current = null;
        }
        setConnectionError(false);
        setIsSocketConnected(true);
        
        // Join the game room
        socket.emit("joinGame", {
          gameId,
          playerId,
          opponentId,
          stakeAmount,
          tournamentId,
          lobbyCode,
          lobbyId
        });
        
        resolve(socket);
      });
      
      socket.on("disconnect", () => {
        console.log("Socket disconnected");
        setIsSocketConnected(false);
        
        // Don't show error if game hasn't started or has already ended
        if (gameStarted && !gameResult) {
          setConnectionError(true);
        }
      });

      socket.on("joinSuccess", () => {
        console.log("Successfully joined game");
      });
      
      socket.on("joinError", (error) => {
        console.error("Failed to join game:", error);
      });

      socket.on("connect_error", (error) => {
        console.error("Socket connection error:", error);
        setIsSocketConnected(false);
        setConnectionError(true);
        reject(error);
      });

      socket.on("gameEnd", handleGameEnd);
      
      socketRef.current = socket;
    });
  };

  const handleConnectionRetry = () => {
    setConnectionError(false);
    setIsLoading(true);
    
    initializeSocket()
      .then(() => {
        setIsLoading(false);
      })
      .catch((error) => {
        console.error("Connection retry failed:", error);
        setConnectionError(true);
        setIsLoading(false);
      });
  };

  const prepareForGame = async () => {
    setIsLoading(true);
    try {
        const socket = await initializeSocket();
        if (socket) {
            startGame();
        } else {
            throw new Error("Socket initialization failed");
        }
    } catch (error) {
        console.error("Failed to connect socket:", error);
        Alert.alert("Connection Failed", "Could not connect to the game server. Please try again.", [{ text: "OK" }]);
        setIsLoading(false);
    }
  };

  const startGame = async () => {
    if (gameStarted) return;
    try {
      if (!socketRef.current || !socketRef.current.connected) {
        throw new Error("Socket not connected");
      }
      
      const url = `${GAME_BASE_URL}/game?gameId=${gameId}&playerId=${playerId}&opponentId=${opponentId}&gameName=${gameName}&lobbyId=${lobbyId}&lobbyCode=${lobbyCode}`;
      console.log("Opening game URL:", url);
      
      // Set the game URL for WebView
      setGameUrl(url);
      
      // Notify server game is starting
      socketRef.current.emit("gameStarting", { gameId, playerId });
      
      // Set game as started
      setGameStarted(true);
    } catch (error) {
      console.error("Failed to launch game:", error);
      Alert.alert("Game Launch Failed", "There was a problem launching the game. Please try again.", [{ text: "OK" }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  // Modify handleGameEnd to ensure consistent navigation
  const handleGameEnd = async (result: GameResult) => {
    console.log("Game ended with result:", result);
    
    // Prevent duplicate processing
    if (gameResult) return;
    
    // Store the game result in global state for access after navigation
    globalGameResult = result;
    globalShowModal = true;
    
    setGameStarted(false);
    setGameResult(result);
  
    // Call the onGameEnd callback if provided
    if (onGameEnd) {
      onGameEnd(result);
    }
  
    // Clean up socket first
    cleanupSocket();
    
    // Navigate to home page first, then the modal will be shown from there
    router.replace("/(tabs)");
  };

  const handleGameClosed = () => {
    // If game didn't end with a result but was closed by user
    if (!gameResult) {
      // Notify server that player left the game
      if (isSocketConnected && socketRef.current) {
        socketRef.current.emit("playerLeft", { gameId, playerId });
      }
      
      setGameStarted(false);
      setGameUrl("");
      
      // Clean up socket when game is closed
      cleanupSocket();
      
      // Redirect to tabs screen
      router.replace("/(tabs)");
    }
  };

  // Handle WebView navigation state changes
  const handleWebViewNavigationStateChange = (navState: any) => {
    // You can detect certain URLs here and handle them differently if needed
    console.log("WebView navigated to:", navState.url);
  };

  // Render an exit button overlay on the WebView
  const renderExitButton = () => {
    return (
      <TouchableOpacity
        style={styles.exitOverlayButton}
        onPress={handleGameClosed}
      >
        <Text style={styles.exitOverlayButtonText}>Exit</Text>
      </TouchableOpacity>
    );
  };

  if (connectionError) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorText}>Lost connection to the game server</Text>
        <TouchableOpacity
          style={styles.retryButton}
          onPress={handleConnectionRetry}
        >
          <Text style={styles.retryButtonText}>Retry Connection</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.exitButton}
          onPress={handleGameClosed}
        >
          <Text style={styles.exitButtonText}>Exit Game</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {!gameStarted && !isLoading && (
        <TouchableOpacity
          style={styles.startButton}
          onPress={prepareForGame}
        >
          <Text style={styles.startButtonText}>Start Game</Text>
        </TouchableOpacity>
      )}

      {isLoading && (
        <View>
          <ActivityIndicator size="large" color="#FFCC00" />
          <Text style={styles.loadingText}>
            {isSocketConnected ? `Launching ${gameName}...` : "Connecting to game server..."}
          </Text>
        </View>
      )}

      {gameStarted && gameUrl && (
        <View style={styles.webViewContainer}>
          <WebView
            ref={webViewRef}
            source={{ uri: gameUrl }}
            style={styles.webView}
            onNavigationStateChange={handleWebViewNavigationStateChange}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            startInLoadingState={true}
            renderLoading={() => (
              <View style={styles.loadingOverlay}>
                <ActivityIndicator size="large" color="#FFCC00" />
                <Text style={styles.loadingText}>Loading game...</Text>
              </View>
            )}
          />
          {renderExitButton()}
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1E0136",
  },
  webViewContainer: {
    position: 'relative',
    width: '100%',
    height: '100%',
  },
  webView: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1E0136',
  },
  loadingText: {
    color: "#FFFFFF",
    marginTop: 10,
    fontSize: 16,
  },
  startButton: {
    backgroundColor: "#FFCC00",
    padding: 15,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
    marginBottom: 20,
  },
  startButtonText: {
    color: "#000000",
    fontSize: 18,
    fontWeight: "bold",
  },
  errorText: {
    color: "#FFFFFF",
    fontSize: 18,
    marginBottom: 20,
    textAlign: "center",
  },
  retryButton: {
    backgroundColor: "#FFCC00",
    padding: 15,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
    marginBottom: 10,
  },
  retryButtonText: {
    color: "#000000",
    fontSize: 16,
    fontWeight: "bold",
  },
  exitButton: {
    backgroundColor: "transparent",
    borderColor: "#FFCC00",
    borderWidth: 2,
    padding: 15,
    borderRadius: 8,
    width: "80%",
    alignItems: "center",
  },
  exitButtonText: {
    color: "#FFCC00",
    fontSize: 16,
    fontWeight: "bold",
  },
  exitOverlayButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor: 'rgba(0,0,0,0.7)',
    padding: 8,
    borderRadius: 5,
    zIndex: 1000,
  },
  exitOverlayButtonText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "bold",
  },
});

export default MyLudoGame;