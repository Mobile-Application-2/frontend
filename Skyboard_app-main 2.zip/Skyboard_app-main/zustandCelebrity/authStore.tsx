import { celebrityapi } from "@/data/celebrityapi";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";

export interface CelebrityRegister {
  email: string;
  password: string;
  phoneNumber: string;
  socialMediaPlatform: string;
  socialMediaHandle: string;
}

interface RegisterCelebrityResponse {
  message: string;
  data: {
    accessToken: string;
    refreshToken: string;
  };
  success: boolean;
}

interface UserState {
  user: any | null; // Adjust this to a more specific type if available
  success: boolean;
  isLoading: boolean;
  error: string | null;
  successMessage: string | null;
  registerCelebrity: (data: CelebrityRegister) => Promise<RegisterCelebrityResponse>;
}

export const useUserStore = create<UserState>((set) => ({
    user: null,
    isLoading: false,
    error: null,
    successMessage: null,
    success: false,
  
    registerCelebrity: async (data) => {
      set({ isLoading: true, error: null, successMessage: null });
    
      try {
        const response = await celebrityapi.registerCelebrity(data);
    
        if (response.success) {
          // Extract tokens from the response
          const { accessToken, refreshToken } = response.data;
          
          // Store them in AsyncStorage
          await AsyncStorage.setItem("authToken", accessToken);
          await AsyncStorage.setItem("refreshToken", refreshToken);
          
          set({
            successMessage: response.message,
            user: response.data,
            success: response.success,
            isLoading: false,
          });
    
          // Return the entire response
          return response;
        } else {
          throw new Error("Registration was unsuccessful");
        }
      } catch (error: any) {
        console.error("Error registering celebrity:", error);
        set({
          error:
            error.response?.data?.message || error.message || "An error occurred",
          isLoading: false,
        });
    
        throw error;
      }
    },
  }));
  
