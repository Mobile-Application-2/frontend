import { celebrityapi } from "@/data/celebrityapi";
import { EnterCode } from "@/types/authTypes";
import { create } from "zustand";

// Define interfaces for the tournament data and response
export interface CreateTournamentData {
  gameId: string;
  noOfWinners: number;
  name: string;
  endDate: string;
  startDate: string;
}

interface Tournament {
  _id: string;
  name: string;
  gameId: string;
  creatorId: string;
  registrationDeadline: string;
  noOfWinners: number;
  hasGateFee: boolean;
  gateFee: number;
  prize: number[];
  isActive: boolean;
  participants: any[];
  winners: any[];
  isFullyCreated: boolean;
  createdAt: string;
  updatedAt: string;
  __v: number;
}

export interface TournamentPrizesData {
  prizes: number[];
  hasGateFee: boolean;
  gateFee: number;
}

interface TournamentData {
  name: string;
  gameId: string;
  creatorId: string;
  noOfWinners: number;
  isFullyCreated: boolean;
  _id: string;
  createdAt: string;
  updatedAt: string;
  __v: number;
}

interface CreateTournamentResponse {
  message: string;
  data: TournamentData;
  success: boolean;
}

interface AttachPrizesResponse {
  message: string;
  success: boolean;
}

// Define the tournament store state
interface TournamentState {
  tournament: TournamentData | null;
  tournaments: Tournament[];
  isLoading: boolean;
  error: string | null;
  successMessage: string | null;
  success: boolean;

  startTournament: (data: CreateTournamentData) => Promise<TournamentData>;
  getCelebrityTournaments: () => Promise<Tournament[]>;
  enterPrizes: (
    tournamentId: string,
    data: TournamentPrizesData
  ) => Promise<void>;
  enterCode: (tournamentId: string, data: EnterCode) => Promise<void>;
}

// Create the tournament store
export const useCelebrityTournamentStore = create<TournamentState>((set) => ({
  tournament: null,
  tournaments: [],
  isLoading: false,
  error: null,
  successMessage: null,
  success: false,

  startTournament: async (data) => {
    set({ isLoading: true, error: null, successMessage: null });

    try {
      const response = await celebrityapi.startTournaments(data);

      console.log(response);

      if (response.success) {
        set({
          tournament: response.data,
          successMessage: response.message,
          success: response.success,
          isLoading: false,
        });

        return response.data;
      } else {
        throw new Error(response.data.message || "Failed to create tournament");
      }
    } catch (error: any) {
      console.error("Error creating tournament:", error);
      set({
        error:
          error.response?.data?.message ||
          error.message ||
          error.response?.message ||
          "An error occurred",
        isLoading: false,
        success: false,
      });

      throw error;
    }
  },

  getCelebrityTournaments: async () => {
    set({ isLoading: true, error: null });

    try {
      const response = await celebrityapi.getCelebrityTournaments();

      if (response.success) {
        set({
          tournaments: response.data,
          successMessage: response.message,
          success: true,
          isLoading: false,
        });

        return response.data;
      } else {
        throw new Error(response.message || "Failed to retrieve tournaments");
      }
    } catch (error: any) {
      console.error("Error fetching tournaments:", error);
      set({
        error:
          error.response?.data?.message || error.message || "An error occurred",
        isLoading: false,
        success: false,
      });

      throw error;
    }
  },

  enterPrizes: async (tournamentId, data) => {
    set({ isLoading: true, error: null, successMessage: null });

    try {
      console.log("data coming in", tournamentId, data);
      const response = await celebrityapi.enterPrizes(tournamentId, data);

      console.log(response);

      if (response.success) {
        set({
          successMessage: response.message,
          success: true,
          isLoading: false,
        });
      } else {
        throw new Error(response.message || "Failed to enter prizes");
      }
    } catch (error: any) {
      console.error("Error Entering Prizes:", error);
      throw error.response?.data?.message || error.message || error;
    }
  },
  enterCode: async (tournamentId, data) => {
    set({ isLoading: true, error: null, successMessage: null });

    try {
      const response = await celebrityapi.enterCode(tournamentId, data);

      if (response.success) {
        set({
          successMessage: response.message,
          success: true,
          isLoading: false,
        });
      } else {
        throw new Error(response.message || "Failed to enter code");
      }
    } catch (error: any) {
      console.error("Error Entering Code:", error);
      throw error.response?.data?.message || error.message || error;
    }
  },
}));
