import { api } from "@/data/api";
import { CreateLobbyResponse, Game, Gamer, Games, JoinLobby, TopGames } from "@/types/gameTypes";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";

export interface TopGamer {
  _id: string;
  totalWins: number;
  userInfo: {
    _id: string;
    username: string;
    avatar: string;
  };
}
export interface ActivePlayer {
  userID: string;
  socketID: string;
  avatar: string;
  username: string;
}

// Type definitions
export interface SelectGamer {
  playerId: string;
  lobbyId: string;
}

export interface CreateLobby {
  gameId: string;
  wagerAmount: number;
}

interface Lobby {
  code: string;
  _id: string;
}
export interface SearchedGamer {
  _id: string;
  favoriteGameCount?: number;
  totalWins?: number;
  username: string;
  bio?: string;
  avatar?: string;
  favoriteGame?: {
    _id: string;
    image: string;
    name: string;
    description: string;
    averageRating: number;
    createdAt: string;
    updatedAt: string;
    __v: number;
    maxPlayers: number;
  };
}

interface GameState {
  games: Games[];
  game: Game | null;
  topgames: TopGames[];
  topGamers: TopGamer[]; // New state for top gamers
  gamers: Gamer[];
  isLoading: boolean;
  error: string | null;
  lobby: Lobby | null;
  activePlayers: ActivePlayer[];
  searchResults: SearchedGamer[];
  searchLoading: boolean;
  searchError: string | null;


  getGames: () => Promise<void>;
  getTopGames: () => Promise<void>;
  getTopGamers: () => Promise<void>; // New function
  getGame: (data: string) => Promise<void>;
  getGamers: () => Promise<void>;
  selectGamer: (data: SelectGamer) => Promise<void>;
  createLobby: (data: CreateLobby) => Promise<CreateLobbyResponse>;
  joinLobby: (data: JoinLobby) => Promise<any>;
  getActivePlayers: () => Promise<void>;
  searchGamers: (query: string) => Promise<void>;



  clearError: () => void;
  clearSearchResults: () => void;
}

// Zustand store
export const useGameStore = create<GameState>((set) => ({
  games: [],
  game: null,
  gamers: [],
  topgames: [],
  topGamers: [], // Initialize top gamers array
  isLoading: false,
  error: null,
  lobby: null,
  activePlayers: [],
  searchResults: [],
  searchLoading: false,
  searchError: null,

  getGames: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.getGames();
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }
      set({ games: response.data, isLoading: false });
    } catch (error: any) {
      console.error("Error fetching games:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch games",
        isLoading: false,
      });
    }
  },

  getTopGames: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.getTopGames();
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }
      const formattedGames = response.data.map((game: any) => ({
        _id: game._id,
        image: game.gameInfo.image,
        name: game.gameInfo.name,
        description: game.gameInfo.description,
        averageRating: game.gameInfo.averageRating,
        maxPlayers: game.gameInfo.maxPlayers,
        totalPlays: game.totalPlays,
        createdAt: game.gameInfo.createdAt,
        updatedAt: game.gameInfo.updatedAt,
      }));
      set({ games: formattedGames, isLoading: false });
    } catch (error: any) {
      console.error("Error fetching games:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch games",
        isLoading: false,
      });
    }
  },

  // New function to get top gamers
  getTopGamers: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.getTopGamers();
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }
      set({ topGamers: response.data, isLoading: false });
    } catch (error: any) {
      console.error("Error fetching top gamers:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch top gamers",
        isLoading: false,
      });
    }
  },

  getGame: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.getGame(data);
      if (!response?.data || typeof response.data !== "object") {
        throw new Error("Invalid response format from server");
      }
      const gameData = response.data;
      set({
        game: {
          _id: gameData._id,
          image: gameData.image,
          name: gameData.name,
          description: gameData.description,
          averageRating: gameData.averageRating,
          maxPlayers: gameData.maxPlayers,
          createdAt: gameData.createdAt,
          updatedAt: gameData.updatedAt,
          isActive: gameData.isActive,
        },
        isLoading: false,
      });
    } catch (error: any) {
      console.error("Error fetching game:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch game",
        isLoading: false,
      });
    }
  },

  getGamers: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.getGamers();
      if (!response?.data || !response.data) {
        throw new Error("Invalid response format from server");
      }
      set({ gamers: response.data, isLoading: false });
    } catch (error: any) {
      console.error("Error fetching gamers:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch gamers",
        isLoading: false,
      });
    }
  },
  searchGamers: async (query: string) => {
    set({ searchLoading: true, searchError: null });
    try {
      const response = await api.searchGamer(query);
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }
      set({ searchResults: response.data, searchLoading: false });
    } catch (error: any) {
      console.error("Error searching gamers:", error);
      set({
        searchError: error.response?.message || error.message || "Failed to search gamers",
        searchLoading: false,
      });
    }
  },

  selectGamer: async (data: SelectGamer) => {
    set({ isLoading: true, error: null });
    try {
        const response = await api.selectGamer(data);
        if (!response || typeof response !== "object") {
            throw new Error("Invalid response format from server");
        }
        // Store the response in AsyncStorage
        await AsyncStorage.setItem('lastSelectedUserResponse', JSON.stringify(response));
        console.log("Gamer selected successfully:", response);
        set({ isLoading: false });
    } catch (error: any) {
        console.error("Error selecting gamer:", error);
        set({
            error: error.response?.message || error.message || "Failed to select gamer",
            isLoading: false,
        });
    }
  },

  createLobby: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.createLobby(data);
      if (!response?.data || typeof response.data !== "object") {
        throw new Error("Invalid response format from server");
      }
      const lobbyData = response.data;
      set({
        lobby: {
          code: lobbyData.code,
          _id: lobbyData._id,
        },
        isLoading: false,
      });
      return lobbyData as CreateLobbyResponse;  // Return the CreateLobbyResponse
    } catch (error: any) {
      console.error("Error creating lobby:", error.response?.data);
      set({
        error: error.response?.message || error.message || "Failed to create lobby",
        isLoading: false,
      });
      throw error; // Ensure errors are thrown for proper error handling
    }
  },
  joinLobby: async (data) => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.joinLobby(data);
      if (!response || typeof response !== "object") {
        throw new Error("Invalid response format from server");
      }
      
      // Assuming the response includes lobby information similar to createLobby
      if (response.data && response.data._id) {
        set({
          lobby: {
            code: data.lobbyCode,
            _id: response.data._id,
          },
          isLoading: false,
        });
      } else {
        set({ isLoading: false });
      }
      
      return response;
    } catch (error: any) {
      console.error("Error joining lobby:", error);
      set({
        error: error.response?.message || error.message || "Failed to join lobby",
        isLoading: false,
      });
      throw error; // Ensure errors are thrown for proper error handling
    }
  },
  getActivePlayers: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.activePlayers();
      if (!response || !response.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }
      set({ activePlayers: response.data, isLoading: false });
    } catch (error: any) {
      console.error("Error fetching active players:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch active players",
        isLoading: false,
      });
    }
  },
  clearError: () => set({ error: null }),
  clearSearchResults: () => set({ searchResults: [], searchError: null }),

}));