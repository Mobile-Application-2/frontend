import { api } from "@/data/api";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { create } from "zustand";

// Type definitions for notifications
export interface Notification {
  _id: string;
  userId: string;
  image: string;
  title: string;
  body: string;
  read: boolean;
  createdAt: string;
  updatedAt: string;
  __v?: number;
}

interface NotificationResponse {
  message: string;
  data: Notification[];
  success: boolean;
}

interface NotificationState {
  notifications: Notification[];
  isLoading: boolean;
  error: string | null;
  unreadCount: number;

  // Actions
  getNotifications: () => Promise<void>;
  clearError: () => void;
}

// Zustand store
export const useNotificationStore = create<NotificationState>((set) => ({
  notifications: [],
  isLoading: false,
  error: null,
  unreadCount: 0,

  getNotifications: async () => {
    set({ isLoading: true, error: null });
    try {
      const response = await api.getNotifications();
      
      // Check if response has expected structure
      if (!response || !response.success || !response.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }
      
      const notifications = response.data;
      const unreadCount = notifications.filter((notification: { read: any; }) => !notification.read).length;
      
      set({ 
        notifications, 
        unreadCount,
        isLoading: false 
      });
      
      // Cache notifications
      await AsyncStorage.setItem('cachedNotifications', JSON.stringify(notifications));
      
    } catch (error: any) {
      console.error("Error fetching notifications:", error);
      set({
        error: error.response?.message || error.message || "Failed to fetch notifications",
        isLoading: false,
      });
      
      // Try to load cached notifications if network request fails
      try {
        const cachedData = await AsyncStorage.getItem('cachedNotifications');
        if (cachedData) {
          const notifications = JSON.parse(cachedData);
          const unreadCount = notifications.filter((notification: Notification) => !notification.read).length;
          set({ notifications, unreadCount });
        }
      } catch (cacheError) {
        console.error("Error loading cached notifications:", cacheError);
      }
    }
  },

  clearError: () => set({ error: null }),
}));