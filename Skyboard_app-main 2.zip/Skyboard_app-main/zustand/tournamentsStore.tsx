import { api } from "@/data/api";
import { JoinTournament } from "@/types/gameTypes";
import { create } from "zustand";

// Type definitions

interface LeaderboardUserInfo {
  _id: string;
  username: string;
  bio?: string;
  avatar?: string;
}

interface LeaderboardEntry {
  _id: string;
  totalWins: number;
  lastWin: string;
  userInfo: LeaderboardUserInfo[];
}

interface LeaderboardResponse {
  message: string;
  data: LeaderboardEntry[];
  success: boolean;
}
interface Tournament {
  _id: string;
  name: string;
  gameId: string;
  creatorId: string;
  registrationDeadline: string;
  noOfWinners: number;
  hasGateFee: boolean;
  gateFee?: number;
  prizes: number[];
  hasStarted: boolean;
  hasEnded: boolean;
  isFullyCreated: boolean;
  participants: any[]; // Update to a more specific type if available
  winners: any[]; // Update to a more specific type if available
  createdAt: string;
  updatedAt: string;
  joiningCode: string;
  gameName: string;
}
interface ParticipatingTournamentsResponse {
  message: string;
  data: Tournament[];
  success: boolean;
}

interface JoinTournamentResponse {
  message: string;
  data: {
    joiningCode: string;
    _id: string;
  };
  success: boolean;
}

// New interface for tournament fixture player
interface FixturePlayer {
  _id: string;
  username: string;
  avatar?: string;
}

// New interface for tournament fixture
interface TournamentFixture {
  _id: string;
  players: FixturePlayer[];
  joiningCode: string;
  gameStarted: boolean;
  createdAt: string;
  updatedAt: string;
  __v: number;
  tournamentId: string;
}

// New interface for tournament fixture response
interface TournamentFixtureResponse {
  message: string;
  data: TournamentFixture[];
}

interface TournamentState {
  tournaments: Tournament[];
  isLoading: boolean;
  isJoining: boolean;
  error: string | null;
  joinResponse: JoinTournamentResponse | null;
  fixtures: TournamentFixture[];
  isLoadingFixtures: boolean;
  fixturesError: string | null;
  leaderboard: LeaderboardEntry[];
  isLoadingLeaderboard: boolean;
  leaderboardError: string | null;
  participatingTournaments: Tournament[];
  isLoadingParticipating: boolean;
  participatingError: string | null;

  getTournaments: (page: number) => Promise<void>;
  getParticipatingTournaments: () => Promise<ParticipatingTournamentsResponse | void>;

  joinTournament: (
    joiningCode: string
  ) => Promise<JoinTournamentResponse | void>;
  getTournamentFixtures: (
    tournamentId: string,
    lobbyCode: string
  ) => Promise<TournamentFixtureResponse | void>;
  getLeaderboard: (tournamentId: string) => Promise<LeaderboardResponse | void>;
  clearError: () => void;
  clearJoinResponse: () => void;
}

// Zustand store
export const useTournamentStore = create<TournamentState>((set) => ({
  tournaments: [],
  isLoading: false,
  isJoining: false,
  error: null,
  joinResponse: null,
  fixtures: [],
  isLoadingFixtures: false,
  fixturesError: null,
  leaderboard: [],
  isLoadingLeaderboard: false,
  leaderboardError: null,
  participatingTournaments: [],
  isLoadingParticipating: false,
  participatingError: null,

  getTournaments: async (page: number) => {
    set({ isLoading: true, error: null });

    try {
      const response = await api.getTournaments(page);

      // Validate response structure
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid response format from server");
      }

      set({
        tournaments: response.data,
        isLoading: false,
      });
    } catch (error: any) {
      console.error("Error fetching tournaments:", error);
      set({
        error:
          error.response?.data?.message ||
          error.message ||
          "Failed to fetch tournaments",
        isLoading: false,
      });
    }
  },
  getParticipatingTournaments: async () => {
    set({ isLoadingParticipating: true, participatingError: null });

    try {
      const response = await api.getParticipatingTournaments();

      // Validate response structure
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid participating tournaments response format from server");
      }

      set({
        participatingTournaments: response.data,
        isLoadingParticipating: false,
      });

      return response; // Return the full response
    } catch (error: any) {
      console.error("Error fetching participating tournaments:", error);
      set({
        participatingError:
          error.response?.data?.message ||
          error.message ||
          "Failed to fetch participating tournaments",
        isLoadingParticipating: false,
      });
    }
  },

  joinTournament: async (joiningCode: string) => {
    set({ isJoining: true, error: null, joinResponse: null });

    try {
      const data: JoinTournament = { joiningCode };
      const response = await api.joinTournament(data);

      set({
        joinResponse: response,
        isJoining: false,
      });

      return response;
    } catch (error: any) {
      console.error("Error joining tournament:", error);
      set({
        error:
          error.response?.data?.message ||
          error.message ||
          "Failed to join tournament",
        isJoining: false,
      });
    }
  },
  getTournamentFixtures: async (tournamentId: string, lobbyCode: string) => {
    set({ isLoadingFixtures: true, fixturesError: null });

    try {
      const response = await api.enterTournament(tournamentId, lobbyCode);

      // Validate response structure
      if (!response?.data) {
        throw new Error("Invalid fixtures response format from server");
      }

      set({
        fixtures: response.data,
        isLoadingFixtures: false,
      });

      return response.data;
    } catch (error: any) {
      console.error("Error fetching tournament fixtures:", error);
      set({
        fixturesError:
          error.response?.data?.message ||
          error.message ||
          "Failed to fetch tournament fixtures",
        isLoadingFixtures: false,
      });
    }
  },
  getLeaderboard: async (tournamentId: string) => {
    set({ isLoadingLeaderboard: true, leaderboardError: null });

    try {
      const response = await api.getLeaderBoard(tournamentId);

      // Validate response structure
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error("Invalid leaderboard response format from server");
      }

      set({
        leaderboard: response.data,
        isLoadingLeaderboard: false,
      });

      return response; // Return the full response which matches LeaderboardResponse
    } catch (error: any) {
      console.error("Error fetching tournament leaderboard:", error);
      set({
        leaderboardError:
          error.response?.data?.message ||
          error.message ||
          "Failed to fetch tournament leaderboard",
        isLoadingLeaderboard: false,
      });
    }
  },
  clearError: () => set({ error: null }),
  clearJoinResponse: () => set({ joinResponse: null }),
}));
