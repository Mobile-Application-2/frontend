import { io, Socket } from 'socket.io-client';
import { create } from 'zustand';

// Define the state shape
interface SocketStore {
  socket: Socket | null;
  isConnected: boolean;
  initSocket: (namespace?: string, params?: Record<string, any>) => Socket;
  disconnectSocket: () => void;
  emitEvent: (event: string, data: any) => boolean;
}

// Create the Zustand store
export const useSocketStore = create<SocketStore>((set, get) => ({
  socket: null,
  isConnected: false,

  // Initialize socket connection
  initSocket: (namespace = '/tournament', params = {}) => {
    const currentSocket = get().socket;
    if (currentSocket) {
      currentSocket.disconnect();
    }

    const socketURL = `${process.env.EXPO_PUBLIC_GAME_URL}${namespace}`;
    const socket: Socket = io(socketURL, {
      query: params,
    });

    socket.on('connect', () => set({ isConnected: true }));
    socket.on('disconnect', () => set({ isConnected: false }));

    set({ socket });
    return socket;
  },

  // Disconnect socket
  disconnectSocket: () => {
    const { socket } = get();
    if (socket) {
      socket.disconnect();
      set({ socket: null, isConnected: false });
    }
  },

  // Emit events
  emitEvent: (event, data) => {
    const { socket } = get();
    if (socket?.connected) {
      socket.emit(event, data);
      return true;
    }
    return false;
  },
}));
