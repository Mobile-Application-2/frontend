import { api } from "@/data/api";
import { create } from "zustand";

// Types
export interface Withdrawals {
  description: string;
  amount: number;
  password: string;
  accountName: string;
  accountNumber: string;
  bankCode: string;
}

export interface Bank {
  name: string;
  code: string;
  currency: string;
  type: string;
}

export interface BankAccountDetails {
  account_number: string;
  account_name: string;
  bank_id: number;
}

interface PaymentState {
  // Deposit states
  checkoutUrl: string | null;
  
  // Withdrawal states
  withdrawalRef: string | null;
  
  // Banks states
  banks: Bank[];
  
  // Bank details states
  bankAccountDetails: BankAccountDetails | null;
  
  // Common states
  isLoading: boolean;
  error: string | null;
  successMessage: string | null;
  
  // Functions
  makeDeposit: (amount: number) => Promise<string | null>;
  makeWithdrawal: (data: Withdrawals) => Promise<string | null>;
  getBanks: () => Promise<Bank[] | null>;
  getBankDetails: (bankCode: string, accountNumber: string) => Promise<BankAccountDetails | null>;
  resetState: () => void;
}

export const usePaymentStore = create<PaymentState>((set, get) => ({
  checkoutUrl: null,
  withdrawalRef: null,
  banks: [],
  bankAccountDetails: null,
  isLoading: false,
  error: null,
  successMessage: null,

  makeDeposit: async (amount) => {
    set({ isLoading: true, error: null, successMessage: null, checkoutUrl: null });

    try {
      const response = await api.makeDeposit({amount});

      console.log("Show data now",response)
      
      if (response.success) {
        set({
          checkoutUrl: response.data,
          successMessage: response.message,
          isLoading: false
        });
        return response.data;
      } else {
        throw new Error(response.data.message || "Failed to create deposit");
      }
    } catch (error: any) {
      console.error("Error making deposit:", error.message);
      set({
        error: error.response?.data?.message || error.message || "An error occurred",
        isLoading: false
      });
      return null;
    }
  },
  
  makeWithdrawal: async (data: Withdrawals) => {
    set({ isLoading: true, error: null, successMessage: null, withdrawalRef: null });
    
    try {
      const response = await api.makeWithdrawal(data);
      
      if (response.success) {
        set({
          withdrawalRef: response.data.ref,
          successMessage: response.message,
          isLoading: false
        });
        return response.data.ref;
      } else {
        throw new Error(response.data.message || "Failed to process withdrawal");
      }
    } catch (error: any) {
      console.error("Error making withdrawal:", error);
      set({
        error: error.response?.data?.message || error.message || "An error occurred",
        isLoading: false
      });
      return null;
    }
  },
  
  getBanks: async () => {
    // Don't fetch if we already have banks and aren't forcing a refresh
    if (get().banks.length > 0) {
      return get().banks;
    }
    
    set({ isLoading: true, error: null });
    
    try {
      const response = await api.getBanks();
      
      if (response.success) {
        set({
          banks: response.data,
          isLoading: false
        });
        return response.data;
      } else {
        throw new Error(response.message || "Failed to retrieve banks");
      }
    } catch (error: any) {
      console.error("Error fetching banks:", error);
      set({
        error: error.response?.message || error.message || "An error occurred",
        isLoading: false
      });
      return null;
    }
  },
  
  getBankDetails: async (bankCode: string, accountNumber: string) => {
    set({ isLoading: true, error: null, bankAccountDetails: null });
    
    try {
      const response = await api.getBankDetails(bankCode, accountNumber);
      
      if (response.success) {
        set({
          bankAccountDetails: response.data,
          successMessage: response.message,
          isLoading: false
        });
        return response.data;
      } else {
        throw new Error(response.message || "Failed to retrieve bank account details");
      }
    } catch (error: any) {
      console.error("Error fetching bank details:", error);
      set({
        error: error.response?.data?.message || error.message || "An error occurred",
        isLoading: false
      });
      return null;
    }
  },
  
  resetState: () => {
    set({
      checkoutUrl: null,
      withdrawalRef: null,
      bankAccountDetails: null,
      error: null,
      successMessage: null,
      isLoading: false
      // Note: We don't reset banks as they rarely change and can be reused
    });
  }
}));