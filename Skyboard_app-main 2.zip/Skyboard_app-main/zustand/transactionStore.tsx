import { api } from "@/data/api";
import { create } from "zustand";

// Type definitions
interface Bank {
  name: string;
  code: string;
  currency: string;
  type: string;
}

// New transaction interface
interface Transaction {
  _id: string;
  ref: string;
  userId: string;
  amount: number;
  fee: number;
  total: number;
  type: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  __v: number;
}

interface TransactionState {
  banks: Bank[];
  transactions: Transaction[]; // New state for transactions
  isLoading: boolean;
  error: string | null;
  getBanks: () => Promise<void>;
  getTransactions: () => Promise<void>; // New function
  clearError: () => void;
}

export const useTransactionStore = create<TransactionState>((set) => ({
  banks: [],
  transactions: [], // Initialize transactions array
  isLoading: false,
  error: null,

  getBanks: async () => {
    set({ isLoading: true, error: null });

    try {
      const response = await api.getBanks();
      
      // Validate response structure
      if (!response?.data?.data || !Array.isArray(response.data.data)) {
        throw new Error('Invalid response format from server');
      }

      set({ 
        banks: response.data.data,
        isLoading: false 
      });
    } catch (error: any) {
      console.error('Error fetching banks:', error);
      set({
        error: error.response?.data?.message || error.message || 'Failed to fetch banks',
        isLoading: false
      });
    }
  },

  // New function to get transactions
  getTransactions: async () => {
    set({ isLoading: true, error: null });

    try {
      const response = await api.getTransactions();
      
      // Validate response structure
      if (!response?.data || !Array.isArray(response.data)) {
        throw new Error('Invalid response format from server');
      }

      set({ 
        transactions: response.data,
        isLoading: false 
      });
    } catch (error: any) {
      console.error('Error fetching transactions:', error);
      set({
        error: error.response?.data?.message || error.message || error.response.message || 'Failed to fetch transactions',
        isLoading: false
      });
    }
  },

  clearError: () => set({ error: null }),
}));