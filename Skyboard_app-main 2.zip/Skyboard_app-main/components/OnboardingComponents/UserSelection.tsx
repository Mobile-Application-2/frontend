import { FontAwesome, Ionicons } from "@expo/vector-icons"; // Import Expo Vector Icons
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

interface AccountOption {
  id: string;
  title: string;
  iconName: keyof typeof FontAwesome.glyphMap; // Specify the icon name type
}

const accountOptions: AccountOption[] = [
  {
    id: "regular",
    title: "Regular",
    iconName: "user", // Replace with FontAwesome icon name
  },
  {
    id: "celebrity",
    title: "Celebrity", // Replace with FontAwesome icon name
    iconName: "star",
  },
];

const AnimatedTouchableOpacity =
  Animated.createAnimatedComponent(TouchableOpacity);

const UserSelection: React.FC = () => {
  const router = useRouter();
  const [isReady, setIsReady] = useState(false);
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const backgroundColorAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const initAnimation = async () => {
      try {
        await new Promise((resolve) => setTimeout(resolve, 100));
        setIsReady(true);
      } catch (error) {
        console.error("Animation initialization error:", error);
        setIsReady(true);
      }
    };

    initAnimation();
  }, []);

  const handleAccountTypeSelect = (id: string) => {
    setSelectedType(id);

    try {
      Animated.timing(backgroundColorAnim, {
        toValue: id === "celebrity" ? 1 : 0,
        duration: 300,
        useNativeDriver: false,
      }).start();
    } catch (error) {
      console.error("Animation error:", error);
      setSelectedType(id);
    }
  };

  const handleContinue = () => {
    if (!selectedType) {
      alert("Please select an account type to continue.");
      return;
    }

    try {
      if (selectedType === "regular") {
        router.push("/(onboarding)/sign-up");
      } else {
        router.push("/(onboarding)/c-sign-up");
      }
    } catch (error) {
      console.error("Navigation error:", error);
      alert("Navigation failed. Please try again.");
    }
  };

  const interpolatedBackgroundColor = backgroundColorAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["#e6217f", "#56920D"],
  });

  if (!isReady) {
    return (
      <View style={styles.container}>
        <StatusBar barStyle="light-content" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />

      <View style={styles.progressBarContainer}>
        <Animated.View
          style={[
            styles.progressBar,
            { backgroundColor: interpolatedBackgroundColor },
          ]}
        />
      </View>

      <View style={styles.headerContainer}>
        <TouchableOpacity onPress={() => router.replace('/(onboarding)')}>
          <Ionicons name="chevron-back" color={"white"} size={24} />
        </TouchableOpacity>
        <Text style={styles.title}>
          <Text
            style={[
              styles.titlePink,
              {
                color: selectedType === "celebrity" ? "#56920D" : "#e6217f",
                textAlign: "center",
              },
            ]}
          >
            What type of{" "}
          </Text>
          account do{"\n"}you like to create?
        </Text>
        {/* <Text style={styles.subtitle}>You can skip it if you are not sure</Text> */}
      </View>

      <View style={styles.optionsContainer}>
        {accountOptions.map((option) => {
          const isSelected = selectedType === option.id;

          return (
            <TouchableOpacity
              key={option.id}
              style={[
                styles.optionButton,
                isSelected && [
                  styles.optionButtonSelected,
                  {
                    backgroundColor:
                      selectedType === "celebrity" ? "#56920D" : "#e6217f",
                  },
                ],
              ]}
              onPress={() => handleAccountTypeSelect(option.id)}
              activeOpacity={0.7}
            >
              <View
                style={[
                  styles.iconContainer,
                  isSelected && styles.iconContainerSelected,
                ]}
              >
                <FontAwesome
                  name={option.iconName}
                  color={isSelected ? "#fff" : "#e6217f"}
                  size={24}
                />
              </View>
              <Text
                style={[
                  styles.optionText,
                  isSelected && styles.optionTextSelected,
                ]}
              >
                {option.title}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[
            styles.getStartedButton,
            {
              backgroundColor:
                selectedType === "celebrity" ? "#56920D" : "#e6217f",
              opacity: selectedType ? 1 : 0.7,
            },
          ]}
          onPress={handleContinue}
          disabled={!selectedType}
        >
          <Text style={styles.getStartedText}>CONTINUE</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1a1624",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    color: "#fff",
    fontSize: 16,
  },
  progressBarContainer: {
    height: 4,
    backgroundColor: "rgba(255,255,255,0.1)",
    marginHorizontal: 20,
    borderRadius: 2,
    marginTop: 12,
  },
  progressBar: {
    height: "100%",
    width: "40%", // Adjust based on progress
    backgroundColor: "#e6217f",
    borderRadius: 2,
  },
  headerContainer: {
    flexDirection: "row",
    gap: 20,
    marginTop: 24,
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 24,
    color: "#fff",
    fontWeight: "600",
    lineHeight: 32,
    marginBottom: 8,
  },
  titlePink: {
    color: "#e6217f",
  },
  subtitle: {
    fontSize: 14,
    color: "rgba(255,255,255,0.6)",
    marginTop: 8,
  },
  optionsContainer: {
    marginTop: 40,
    paddingHorizontal: 20,
    gap: 16,
  },
  optionButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(230,33,127,0.1)",
    height: 64,
    borderRadius: 12,
    paddingHorizontal: 16,
  },
  optionButtonSelected: {
    backgroundColor: "#e6217f",
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(230,33,127,0.1)",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  iconContainerSelected: {
    backgroundColor: "rgba(255,255,255,0.2)",
  },
  optionText: {
    fontSize: 16,
    color: "#fff",
    fontWeight: "500",
  },
  optionTextSelected: {
    color: "#fff",
  },
  buttonContainer: {
    position: "absolute",
    bottom: 40,
    left: 20,
    right: 20,
  },
  getStartedButton: {
    backgroundColor: "#e6217f",
    height: 56,
    borderRadius: 8,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  getStartedText: {
    color: "white",
    fontSize: 16,
    fontWeight: "600",
  },
});

export default UserSelection;
