import { useProfileStore } from "@/zustand/profileStore";
import { useRouter } from "expo-router";
import React, { useEffect } from "react";
import { Dimensions, Image, Platform, StyleSheet, Text, TouchableOpacity, View } from "react-native";

const HomeHeader: React.FC = () => {
  const router = useRouter();
  const { user, isLoading, getUserProfile } = useProfileStore();

  useEffect(() => {
    getUserProfile();
  }, []);

  if (isLoading) {
    return (
      <View style={styles.container}>
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.userInfo}>
          <Image
            source={require("@/assets/images/Avatar.png")}
            style={styles.userAvatar}
          />
          <View style={styles.textContainer}>
            <Text style={styles.greeting} numberOfLines={1} ellipsizeMode="tail">
              Hello <Text style={styles.username}>{user?.username || "User"}</Text>
            </Text>
            <Text style={styles.welcomeText} numberOfLines={2} ellipsizeMode="tail">
              {user?.emailIsVerified
                ? "Welcome back to your winning streak!"
                : "Please verify your email to unlock features"}
            </Text>
          </View>
        </View>
        <View style={styles.headerIcons}>
          <TouchableOpacity style={styles.iconButton} onPress={() => router.push("/(pages)/notificationList")}>
            <Text>🔔</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push("/(pages)/reg-fund-history")}
            style={styles.iconButton}
          >
            <Text>💰</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#1A1624",
    padding: isSmallScreen ? 5 : 10,
    paddingTop: Platform.OS === 'android' ? 30 : 30
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: isSmallScreen ? 10 : 16,
  },
  userInfo: {
    flexDirection: "row",
    alignItems: "center",
    flex: 1,
    marginRight: 8,
  },
  textContainer: {
    flex: 1,
  },
  userAvatar: {
    width: isSmallScreen ? 32 : 40,
    height: isSmallScreen ? 32 : 40,
    borderRadius: isSmallScreen ? 16 : 20,
    marginRight: isSmallScreen ? 8 : 12,
    backgroundColor: "#FFB1D8",
  },
  greeting: {
    color: "#FFFFFF",
    fontSize: isSmallScreen ? 16 : 18,
  },
  username: {
    fontWeight: "bold",
  },
  welcomeText: {
    color: "#666666",
    fontSize: isSmallScreen ? 11 : 12,
  },
  headerIcons: {
    flexDirection: "row",
    gap: isSmallScreen ? 8 : 12,
  },
  iconButton: {
    width: isSmallScreen ? 32 : 40,
    height: isSmallScreen ? 32 : 40,
    borderRadius: isSmallScreen ? 16 : 20,
    backgroundColor: "#E75B99",
    justifyContent: "center",
    alignItems: "center",
  },
  loadingText: {
    color: "#FFFFFF",
    textAlign: "center",
    marginTop: 20,
  },
});

export default HomeHeader;