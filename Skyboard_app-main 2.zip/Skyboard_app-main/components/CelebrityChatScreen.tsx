import { FontAwesome5 } from "@expo/vector-icons";
import Ionicons from "@expo/vector-icons/Ionicons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import NetInfo from "@react-native-community/netinfo";
import { router, useLocalSearchParams, useNavigation } from "expo-router";
import React, { useEffect, useLayoutEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { io, Socket } from "socket.io-client";

// Socket.IO URL configuration
const BASE_URL = process.env.EXPO_PUBLIC_BASE_SOCKET_URL;

// Define message type interface
interface Message {
  id: string;
  text: string;
  sender: string;
  timestamp: string;
  pending?: boolean;
}

const ChatScreen = () => {
  const { gamerId, username, avatar } = useLocalSearchParams<{ 
    gamerId: string, 
    username: string,
    avatar: string 
  }>();
  const navigation = useNavigation();
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState<Message[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(true);
  const [isOffline, setIsOffline] = useState(false);
  const [reconnecting, setReconnecting] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const scrollViewRef = useRef<ScrollView>(null);
  const socketRef = useRef<Socket | null>(null);
  
  // Establish Socket.IO connection
  useEffect(() => {
    const connectSocket = async () => {
      if (isOffline) return;
      
      setIsConnecting(true);
      
      // Close existing connection if any
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
      
      try {
        // Get auth token from storage
        const token = await AsyncStorage.getItem('authToken');
        if (!token) {
          console.error("Auth token not found");
          setIsConnecting(false);
          return;
        }
        
        setAuthToken(token);
        
        // Create new Socket.IO connection with auth token in handshake options
        const socket = io(BASE_URL, {
          transports: ["websockets"],
          query: { userId: gamerId },
          extraHeaders: {
            Authorization: `Bearer ${token}`
          },
          autoConnect: true,
          reconnection: true,
          reconnectionAttempts: 5,
          reconnectionDelay: 3000
        });
        
        socketRef.current = socket;
        
        // Socket.IO event handlers
        socket.on("connect", () => {
          console.log("Socket connected");
          setIsConnected(true);
          setIsConnecting(false);
          setReconnecting(false);
          
          // Load cached messages
          loadCachedMessages();
          
          // Join the chat room
          socket.emit("join_room", { userId: gamerId, token: `Bearer ${token}` });
          
          // Send any pending messages
          sendPendingMessages();
        });
        
        socket.on("receive_message", (receivedMessage) => {
          console.log("Received message:", receivedMessage);
          
          // Add the received message to the messages list
          setMessages((prevMessages) => {
            const updatedMessages = [...prevMessages, {
              id: receivedMessage.id || Date.now().toString(),
              text: receivedMessage.text,
              sender: receivedMessage.sender || "them",
              timestamp: receivedMessage.timestamp || new Date().toLocaleTimeString()
            }];
            // Cache updated messages
            cacheMessages(updatedMessages);
            return updatedMessages;
          });
        });
        
        socket.on("connect_error", (error) => {
          console.error("Socket connection error:", error);
          setIsConnected(false);
          setIsConnecting(false);
        });
        
        socket.on("disconnect", (reason) => {
          console.log("Socket disconnected:", reason);
          setIsConnected(false);
          
          // Socket.IO will automatically try to reconnect
          if (reason === "io server disconnect") {
            socket.connect();
          }
          
          // Set reconnecting state for UI
          if (!isOffline) {
            setReconnecting(true);
          }
        });
        
        socket.on("reconnect", (attemptNumber) => {
          console.log(`Socket reconnected after ${attemptNumber} attempts`);
          setReconnecting(false);
        });
        
        socket.on("reconnect_failed", () => {
          console.log("Socket reconnection failed");
          setReconnecting(false);
          Alert.alert(
            "Connection Failed",
            "Unable to reconnect to the chat server. Please try again later."
          );
        });
        
      } catch (error) {
        console.error("Socket setup error:", error);
        setIsConnecting(false);
        setIsConnected(false);
      }
    };
    
    // Function to send pending messages once connection is established
    const sendPendingMessages = async () => {
      try {
        const pendingMessagesJson = await AsyncStorage.getItem(`pending_messages_${gamerId}`);
        if (pendingMessagesJson && socketRef.current?.connected) {
          const pendingMessages = JSON.parse(pendingMessagesJson);
          
          // Filter only messages marked as pending
          const actualPendingMessages = pendingMessages.filter((msg: Message) => msg.pending);
          
          // Send each pending message
          for (const pendingMsg of actualPendingMessages) {
            socketRef.current.emit("send_message", {
              recipientId: gamerId,
              text: pendingMsg.text,
              timestamp: new Date().toISOString(),
              token: `Bearer ${authToken}`
            });
          }
          
          // Clear pending messages
          await AsyncStorage.removeItem(`pending_messages_${gamerId}`);
          
          // Update UI by removing pending status
          setMessages(prevMessages => 
            prevMessages.map(msg => ({ ...msg, pending: false }))
          );
        }
      } catch (error) {
        console.error("Error sending pending messages:", error);
      }
    };
    
    // Function to cache messages
    const cacheMessages = async (messagesToCache: Message[]) => {
      try {
        if (gamerId) {
          await AsyncStorage.setItem(`chat_messages_${gamerId}`, JSON.stringify(messagesToCache));
        }
      } catch (error) {
        console.error("Error caching messages:", error);
      }
    };
    
    // Function to load cached messages
    const loadCachedMessages = async () => {
      try {
        if (gamerId) {
          const cachedMessages = await AsyncStorage.getItem(`chat_messages_${gamerId}`);
          if (cachedMessages) {
            setMessages(JSON.parse(cachedMessages));
          }
        }
      } catch (error) {
        console.error("Error loading cached messages:", error);
      }
    };
    
    // Check network connectivity
    const checkNetworkStatus = async () => {
      const netInfo = await NetInfo.fetch();
      setIsOffline(!netInfo.isConnected);
      
      if (netInfo.isConnected) {
        connectSocket();
      } else {
        // Load cached messages if offline
        loadCachedMessages();
      }
    };
    
    checkNetworkStatus();
    
    // Setup network status listener
    const unsubscribe = NetInfo.addEventListener((state) => {
      const currentlyOffline = !state.isConnected;
      setIsOffline(currentlyOffline);
      
      if (!currentlyOffline && !isConnected) {
        connectSocket();
      }
    });
    
    // Cleanup function
    return () => {
      unsubscribe();
      
      if (socketRef.current) {
        socketRef.current.disconnect();
      }
    };
  }, [gamerId, isOffline]);
  
  // Auto-scroll to the bottom when new messages arrive
  useEffect(() => {
    if (scrollViewRef.current && messages.length > 0) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [messages]);
  
  // Handle send button press
  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: message,
        sender: "me",
        timestamp: new Date().toLocaleTimeString(),
        pending: !isConnected
      };
      
      // Add message to UI
      setMessages((prevMessages) => {
        const updatedMessages = [...prevMessages, newMessage];
        // Cache updated messages
        try {
          AsyncStorage.setItem(`chat_messages_${gamerId}`, JSON.stringify(updatedMessages));
        } catch (error) {
          console.error("Error caching messages:", error);
        }
        return updatedMessages;
      });
      
      // Send message through Socket.IO if connected
      if (socketRef.current?.connected) {
        socketRef.current.emit("send_message", {
          recipientId: gamerId,
          text: message,
          timestamp: new Date().toISOString(),
          token: authToken ? `Bearer ${authToken}` : null
        });
      } else if (isOffline || !isConnected) {
        // Store message for later sending
        const offlineMessage: Message = {
          id: Date.now().toString(),
          text: message,
          sender: "me",
          timestamp: new Date().toLocaleTimeString(),
          pending: true,
        };
        
        // Store in async storage for pending messages
        AsyncStorage.getItem(`pending_messages_${gamerId}`)
          .then(existingMessages => {
            const pendingMessages = existingMessages 
              ? [...JSON.parse(existingMessages), offlineMessage] 
              : [offlineMessage];
            
            return AsyncStorage.setItem(
              `pending_messages_${gamerId}`,
              JSON.stringify(pendingMessages)
            );
          })
          .catch(error => {
            console.error("Error storing pending message:", error);
          });
      }
      
      // Clear input field
      setMessage("");
    }
  };
  
  // Function to handle back navigation
  const handleBackPress = () => {
    router.back();
  };
  
  useLayoutEffect(() => {
    navigation.setOptions({
      // set a custom header
      header: () => (
        <View style={[styles.header, {paddingTop: Platform.OS === 'ios' ? 50 : 0}]}>
          <View style={styles.headerLeft}>
            <TouchableOpacity
              onPress={handleBackPress}
              style={styles.iconContainer}
            >
              <Ionicons name="arrow-back" size={24} color="#fff" />
            </TouchableOpacity>
            <View style={styles.headerUserInfo}>
              <Image
                source={
                  avatar 
                    ? { uri: avatar } 
                    : require("@/assets/images/friend.png")
                }
                style={styles.headerImage}
              />
              <Text style={styles.headerUserName}>{username || "User"}</Text>
            </View>
          </View>
          <TouchableOpacity style={styles.iconContainer}>
            <FontAwesome5 name="phone-alt" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      ),
    });
  }, [navigation, username, avatar]);
  
  return (
    <View style={styles.container}>     
      {/* Connection Status */}
      {isOffline && (
        <View style={styles.statusBar}>
          <Text style={styles.statusText}>
            You are offline. Messages will be sent when you're back online.
          </Text>
        </View>
      )}
      
      {!isOffline && isConnecting && (
        <View style={styles.statusBar}>
          <ActivityIndicator size="small" color="#fff" style={styles.loader} />
          <Text style={styles.statusText}>Connecting...</Text>
        </View>
      )}
      
      {!isOffline && !isConnecting && !isConnected && (
        <View style={styles.statusBar}>
          <Text style={styles.statusText}>
            Connection lost. Attempting to reconnect...
          </Text>
        </View>
      )}
      
      {/* Chat Messages */}
      <ScrollView 
        style={styles.chatArea} 
        ref={scrollViewRef}
        contentContainerStyle={messages.length === 0 ? styles.emptyChatContainer : undefined}
      >
        {messages.length === 0 ? (
          <Text style={styles.emptyChatText}>
            No messages yet. Start the conversation!
          </Text>
        ) : (
          messages.map((messageItem) => (
            <View
              key={messageItem.id}
              style={
                messageItem.sender === "me"
                  ? styles.messageContainerRight
                  : styles.messageContainer
              }
            >
              {messageItem.sender !== "me" && (
                <Image
                  source={
                    avatar 
                      ? { uri: avatar } 
                      : require("@/assets/images/friend.png")
                  }
                  style={styles.messageProfileImage}
                />
              )}
              <View
                style={[
                  messageItem.sender === "me"
                    ? styles.messageBubbleRight
                    : styles.messageBubble,
                  messageItem.pending ? styles.pendingMessage : null,
                ]}
              >
                <Text
                  style={
                    messageItem.sender === "me"
                      ? styles.messageTextRight
                      : styles.messageText
                  }
                >
                  {messageItem.text}
                </Text>
                <View style={styles.timestampContainer}>
                  {messageItem.pending && (
                    <Ionicons name="time-outline" size={12} color="#fff" style={styles.pendingIcon} />
                  )}
                  <Text
                    style={
                      messageItem.sender === "me"
                        ? styles.messageTimestampRight
                        : styles.messageTimestamp
                    }
                  >
                    {messageItem.timestamp}
                  </Text>
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>
      
      {/* Message Input */}
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.inputField}
          value={message}
          onChangeText={setMessage}
          placeholder="Type message..."
          placeholderTextColor="#ccc"
        />
        <TouchableOpacity 
          style={[
            styles.sendButton,
            message.trim() === '' ? styles.disabledSendButton : null
          ]} 
          onPress={handleSendMessage}
        >
          <Ionicons name="send-sharp" size={24} color="#fff" />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ChatScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#130828",
  },
  header: {
    flexDirection: "row",
    backgroundColor: "#130828",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 20,
    borderBottomWidth: 1,
    opacity: 50,
  },
  headerLeft: {
    flexDirection: "row",
    gap: 5,
  },
  iconContainer: {
    padding: 8,
  },
  headerUserInfo: {
    flexDirection: "row",
    alignItems: "center",
  },
  headerImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  headerUserName: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "bold",
  },
  statusBar: {
    backgroundColor: "#3c8d17",
    padding: 8,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  statusText: {
    color: "#fff",
    fontSize: 12,
  },
  loader: {
    marginRight: 8,
  },
  chatArea: {
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 10,
  },
  emptyChatContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyChatText: {
    color: "#a0c290",
    fontSize: 16,
    textAlign: "center",
  },
  messageContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
  },
  messageProfileImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  messageBubble: {
    backgroundColor: "#a0c290",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    maxWidth: "70%",
  },
  messageText: {
    color: "#fff",
    fontSize: 16,
  },
  timestampContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    marginTop: 5,
  },
  pendingIcon: {
    marginRight: 4,
  },
  messageTimestamp: {
    color: "#3c8d17",
    fontSize: 12,
  },
  messageContainerRight: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-end",
    marginBottom: 10,
  },
  messageBubbleRight: {
    backgroundColor: "#3c8d17",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 20,
    maxWidth: "70%",
  },
  pendingMessage: {
    backgroundColor: "#666",
  },
  messageTextRight: {
    color: "#fff",
    fontSize: 16,
  },
  messageTimestampRight: {
    color: "#a0c290",
    fontSize: 12,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: "#283522",
  },
  inputField: {
    flex: 1,
    backgroundColor: "#283522",
    paddingVertical: 20,
    paddingHorizontal: 15,
    borderRadius: 10,
    color: "#fff",
    fontSize: 16,
  },
  sendButton: {
    position: "absolute",
    right: 30,
    marginLeft: 10,
    padding: 8,
    color: "#a0c290",
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
  disabledSendButton: {
    opacity: 0.5,
  },
});