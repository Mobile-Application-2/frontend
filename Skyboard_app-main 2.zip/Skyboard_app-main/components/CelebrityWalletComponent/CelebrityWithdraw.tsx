import CelebritySuccessModals from "@/app/(modal)/c-sucess-modal";
import formatToNaira from "@/utils/currencyFormatter";
import { usePaymentStore } from "@/zustand/paymentStore";
import { useProfileStore } from "@/zustand/profileStore";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { Dropdown } from "react-native-element-dropdown";

interface WithdrawalFormData {
  description: string;
  amount: number;
  password: string;
  accountName: string;
  accountNumber: string;
  bankCode: string;
}

const WithdrawalScreen: React.FC = () => {
  // Get functions and state from our payment store
  const {
    getBanks,
    getBankDetails,
    makeWithdrawal,
    banks,
    bankAccountDetails,
    isLoading,
    error,
    successMessage,
    withdrawalRef,
  } = usePaymentStore();

    const {
      user,
      getUserProfile,
    } = useProfileStore();

  // Local state for form
  const [formData, setFormData] = useState<WithdrawalFormData>({
    description: "Withdrawal from account",
    amount: 0,
    password: "",
    accountName: "",
    accountNumber: "",
    bankCode: "",
  });

  const [isVisible, setIsVisible] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState("");

  // Fetch banks when component mounts
  useEffect(() => {
    const fetchBanks = async () => {
      try {
        await getBanks();
        await getUserProfile()
        // Banks will be updated in the store
      } catch (error) {
        console.error("Failed to fetch banks:", error);
      }
    };

    fetchBanks();
  }, []);

  // Update form data
  const handleChange = (field: keyof WithdrawalFormData, value: string) => {
    // Reset account name when account number or bank code changes
    if (field === "accountNumber" || field === "bankCode") {
      setFormData((prev) => ({
        ...prev,
        [field]: value,
        accountName: field === "bankCode" ? prev.accountName : "",
      }));
    } else {
      setFormData((prev) => ({
        ...prev,
        [field]: field === "amount" ? parseFloat(value) || 0 : value,
      }));
    }
  };

  // Verify account details
  const verifyAccount = async () => {
    if (!formData.bankCode) {
      setVerificationError("Please select a bank first");
      return;
    }

    if (!formData.accountNumber || formData.accountNumber.length < 10) {
      setVerificationError("Please enter a valid account number");
      return;
    }

    setIsVerifying(true);
    setVerificationError("");

    try {
      const details = await getBankDetails(
        formData.bankCode,
        formData.accountNumber
      );
      if (details) {
        setFormData((prev) => ({
          ...prev,
          accountName: details.account_name,
        }));
      }
    } catch (err) {
      setVerificationError(
        "Failed to verify account. Please check the details."
      );
    } finally {
      setIsVerifying(false);
    }
  };

  // Handle withdrawal submission
  const handleWithdrawal = async () => {
    // Validations
    if (formData.amount < 2000) {
      Alert.alert("Error", "Minimum withdrawal amount is ₦2,000");
      return;
    }

    if (!formData.accountName) {
      Alert.alert("Error", "Please verify your account details first");
      return;
    }

    if (!formData.password) {
      Alert.alert("Error", "Password is required");
      return;
    }

    // Proceed with withdrawal
    const result = await makeWithdrawal(formData);

    if (result) {
      setIsVisible(true);
      // Reset form after successful withdrawal
      setFormData({
        description: "Withdrawal from account",
        amount: 0,
        password: "",
        accountName: "",
        accountNumber: "",
        bankCode: "",
      });
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      <ScrollView>
        {/* Balance Card */}
        <View style={styles.balanceCard}>
          <Text style={styles.balanceLabel}>Available Balance</Text>
          <Text style={styles.balanceAmount}>{formatToNaira(user?.walletBalance || 0.00)}</Text>
        </View>

        {/* Form */}
        <View style={styles.form}>
          {/* Amount Input */}
          <TextInput
            style={styles.input}
            placeholder="Withdrawal amount (min 2000)"
            placeholderTextColor="#666"
            keyboardType="numeric"
            value={formData.amount > 0 ? formData.amount.toString() : ""}
            onChangeText={(text) => handleChange("amount", text)}
          />

          {/* Bank Selection */}
          <View style={styles.dropdownContainer}>
            {isLoading ? (
              <Text style={styles.loadingText}>Loading banks...</Text>
            ) : (
              <Dropdown
                data={banks.map((bank) => ({ label: bank.name, value: bank.code }))}
                labelField="label"
                valueField="value"
                placeholder="Select Bank"
                value={formData.bankCode}
                onChange={(item: any) => handleChange("bankCode", item.value)}
                style={styles.dropdown}
              />
            )}
          </View>

          {/* Account Number with Verification */}
          <View style={styles.accountVerificationContainer}>
            <TextInput
              style={[styles.input, styles.accountInput]}
              placeholder="Account Number"
              placeholderTextColor="#666"
              keyboardType="numeric"
              value={formData.accountNumber}
              onChangeText={(text) => handleChange("accountNumber", text)}
            />
            <TouchableOpacity
              style={[
                styles.verifyButton,
                (isVerifying || isLoading) && styles.disabledButton,
              ]}
              onPress={verifyAccount}
              disabled={isVerifying || isLoading}
            >
              {isVerifying ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <Text style={styles.verifyButtonText}>Verify</Text>
              )}
            </TouchableOpacity>
          </View>

          {/* Error message for verification */}
          {verificationError ? (
            <Text style={styles.errorText}>{verificationError}</Text>
          ) : null}

          {/* Account Name (auto-filled) */}
          <TextInput
            style={[
              styles.input,
              formData.accountName ? styles.verifiedInput : {},
            ]}
            placeholder="Account Name (auto-filled after verification)"
            placeholderTextColor="#666"
            value={formData.accountName}
            editable={false}
          />

          {/* Password Input */}
          <TextInput
            style={styles.input}
            placeholder="Enter Password"
            placeholderTextColor="#666"
            secureTextEntry
            value={formData.password}
            onChangeText={(text) => handleChange("password", text)}
          />

          {/* Error message from store */}
          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          {/* Withdrawal Button */}
          <TouchableOpacity
            style={[styles.withdrawButton, isLoading && styles.disabledButton]}
            onPress={handleWithdrawal}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <Text style={styles.withdrawButtonText}>WITHDRAW</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Success Modal */}
      <CelebritySuccessModals
        visible={isVisible}
        onClose={() => setIsVisible(false)}
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A1A2E",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  headerText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
    marginLeft: 32,
  },
  balanceCard: {
    backgroundColor: "#2E7D32",
    margin: 16,
    padding: 16,
    borderRadius: 8,
    alignItems: "center",
  },
  balanceLabel: {
    color: "#fff",
    fontSize: 14,
    opacity: 0.9,
  },
  balanceAmount: {
    color: "#fff",
    fontSize: 24,
    fontWeight: "bold",
    marginTop: 4,
  },
  form: {
    padding: 16,
  },
  input: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    fontSize: 16,
  },
  pickerContainer: {
    backgroundColor: "#fff",
    borderRadius: 12,
    marginBottom: 16,
    overflow: "hidden",
  },
  picker: {
    height: 56,
  },
  dropdownContainer: { marginBottom: 16 },
  dropdown: { backgroundColor: "#fff", borderRadius: 8, height: 56, paddingHorizontal: 16 },
  accountVerificationContainer: {
    flexDirection: "row",
    marginBottom: 8,
  },
  accountInput: {
    flex: 1,
    marginRight: 8,
    marginBottom: 0,
  },
  verifyButton: {
    backgroundColor: "#4A90E2",
    borderRadius: 8,
    padding: 16,
    justifyContent: "center",
    alignItems: "center",
    minWidth: 80,
  },
  verifyButtonText: {
    color: "#fff",
    fontWeight: "600",
  },
  verifiedInput: {
    borderWidth: 1,
    borderColor: "#4CAF50",
  },
  withdrawButton: {
    backgroundColor: "#2E7D32",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    marginTop: 16,
    height: 56,
    justifyContent: "center",
  },
  loadingText: {
    padding: 16,
    color: "#666",
    textAlign: "center",
  },
  withdrawButtonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "600",
  },
  disabledButton: {
    opacity: 0.7,
  },
  errorText: {
    color: "#FF6B6B",
    marginBottom: 16,
    fontSize: 14,
  },
});

export default WithdrawalScreen;
