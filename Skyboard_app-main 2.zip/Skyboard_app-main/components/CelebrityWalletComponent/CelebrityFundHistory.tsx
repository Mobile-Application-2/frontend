import { useTransactionStore } from '@/zustand/transactionStore';
import React, { useEffect } from 'react';
import {
  ActivityIndicator,
  FlatList,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';

// Define Transaction interface based on API response
interface Transaction {
  _id: string;
  ref: string;
  userId: string;
  amount: number;
  fee: number;
  total: number;
  type: string;
  status: string;
  createdAt: string;
  updatedAt: string;
  __v: number;
}

// Helper function to format date
const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).replace(/\//g, '-');
};

const TransactionItem: React.FC<{ item: Transaction }> = ({ item }) => {
  // Determine if the transaction is an addition (deposit) or withdrawal
  const isDeposit = item.type.toLowerCase() === 'deposit';
  
  return (
    <View style={styles.transactionItem}>
      <View style={styles.leftContent}>
        <View style={styles.iconContainer}>
          <View style={[
            styles.arrow,
            isDeposit ? styles.arrowUp : styles.arrowDown
          ]} />
        </View>
        <View>
          <Text style={styles.transactionType}>
            {isDeposit ? 'Funds added' : 'Cash Withdrawal'}
          </Text>
          <Text style={styles.reference}>
            Ref - {item.ref}
          </Text>
          <Text style={[styles.status, 
            item.status === 'success' ? styles.greenText : 
            item.status === 'failed' ? styles.redText : 
            styles.orangeText]}>
            {item.status}
          </Text>
        </View>
      </View>
      <View style={styles.rightContent}>
        <Text style={[
          styles.amount,
          isDeposit ? styles.greenText : styles.redText
        ]}>
          ₦{item.amount.toLocaleString()}
        </Text>
        <Text style={styles.date}>{formatDate(item.createdAt)}</Text>
      </View>
    </View>
  );
};

const CelebrityFundHistoryScreen: React.FC = () => {
  const { transactions, isLoading, error, getTransactions } = useTransactionStore();

  // Fetch transactions when component mounts
  useEffect(() => {
    getTransactions();
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>
          Fund <Text style={styles.greenText}>History</Text>
        </Text>
      </View>

      {/* Loading state */}
      {isLoading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4CAF50" />
        </View>
      )}

      {/* Error state */}
      {error && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>{error}</Text>
        </View>
      )}

      {/* Transaction List */}
      {!isLoading && !error && (
        <FlatList
          data={transactions}
          renderItem={({ item }) => <TransactionItem item={item} />}
          keyExtractor={item => item._id}
          contentContainerStyle={styles.listContainer}
          ListEmptyComponent={
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyText}>No transactions found</Text>
            </View>
          }
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A2E',
  },
  header: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#fff',
    marginLeft: 32,
  },
  listContainer: {
    padding: 16,
  },
  transactionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  leftContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 40,
    height: 40,
    backgroundColor: '#2D2D3F',
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  arrow: {
    width: 0,
    height: 0,
    backgroundColor: 'transparent',
    borderStyle: 'solid',
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderBottomWidth: 12,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
  },
  arrowUp: {
    borderBottomColor: '#9C27B0',
    transform: [{ rotate: '0deg' }],
  },
  arrowDown: {
    borderBottomColor: '#9C27B0',
    transform: [{ rotate: '180deg' }],
  },
  transactionType: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 4,
  },
  reference: {
    color: '#666',
    fontSize: 12,
    marginBottom: 4,
  },
  status: {
    fontSize: 12,
    fontWeight: '500',
  },
  rightContent: {
    alignItems: 'flex-end',
  },
  amount: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  greenText: {
    color: '#4CAF50',
  },
  redText: {
    color: '#f44336',
  },
  orangeText: {
    color: '#FF9800',
  },
  date: {
    color: '#666',
    fontSize: 12,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    color: '#f44336',
    textAlign: 'center',
    fontSize: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 100,
  },
  emptyText: {
    color: '#666',
    fontSize: 16,
  },
});

export default CelebrityFundHistoryScreen;