// Import libraries
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React from "react";
import { Platform, StyleSheet, Text, TouchableOpacity, View } from "react-native";

// Create a component
const CelebrityPageHeader = ({ title }: { title: string }) => {
  const router = useRouter();
  return (
    <View style={styles.container}>
      <View style={styles.header}>
      <TouchableOpacity
  style={styles.backButton}
  onPress={() => router.back()}
>
  <Ionicons name="chevron-back" size={24} color="white" />
</TouchableOpacity>
        <Text style={styles.headerTitle}>{title}</Text>
      </View>
    </View>
  );
};

// Define your styles
const styles = StyleSheet.create({
  container: {
    backgroundColor: "#130828",
    paddingTop: Platform.OS === 'ios' ? 50 : 0,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
  },
  backButton: {
    position: "absolute", // Position it at the far-left
    left: 16,
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
  },
  backIcon: {
    color: "#FFFFFF",
    fontSize: 24,
  },
  headerTitle: {
    color: "#3f9217",
    fontSize: 20,
    fontWeight: "600",
    textAlign: "center", // Center the text
  },
});

export default CelebrityPageHeader;
