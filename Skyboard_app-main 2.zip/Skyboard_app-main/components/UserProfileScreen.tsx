import { SearchedGamer, useGameStore } from "@/zustand/gameStore";
import { useProfileStore } from "@/zustand/profileStore";
import AsyncStorage from "@react-native-async-storage/async-storage";
import NetInfo from "@react-native-community/netinfo";
import { router, useLocalSearchParams } from "expo-router";
import React, { useEffect, useState } from "react";
import { ActivityIndicator, Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";

const UserProfileScreen = () => {
  const { searchResults, searchGamers, searchLoading, searchError } = useGameStore();
  const { gamerName } = useLocalSearchParams<{ gamerName: string }>();
  const [cachedGamer, setCachedGamer] = useState<SearchedGamer | null>(null);
  const [isOffline, setIsOffline] = useState(false);
  const { getUserProfile } = useProfileStore();

  // Function to cache gamer data
  const cacheGamerData = async (data: SearchedGamer) => {
    if (data) {
      try {
        await AsyncStorage.setItem(`gamer_${data.username}`, JSON.stringify(data));
        console.log("Gamer data cached successfully");
      } catch (e) {
        console.error("Error caching gamer data:", e);
      }
    }
  };

  // Function to retrieve cached gamer data
  const getCachedGamerData = async (gamerName: string) => {
    try {
      const cachedData = await AsyncStorage.getItem(`gamer_${gamerName}`);
      if (cachedData) {
        return JSON.parse(cachedData);
      }
      return null;
    } catch (e) {
      console.error("Error retrieving cached gamer data:", e);
      return null;
    }
  };

  // Check network status
  useEffect(() => {
    const checkConnectivity = async () => {
      const state = await NetInfo.fetch();
      setIsOffline(!state.isConnected);
    };

    checkConnectivity();
    
    // Set up a listener for network changes
    const unsubscribe = NetInfo.addEventListener((state) => {
      setIsOffline(!state.isConnected);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Fetch gamer data (from API or cache)
  useEffect(() => {
    const fetchGamerData = async () => {
      if (gamerName) {
        // Try to get cached data first
        const cachedData = await getCachedGamerData(gamerName);
        if (cachedData) {
          setCachedGamer(cachedData);
        }
        
        // If online, try to fetch fresh data
        if (!isOffline) {
          try {
            await searchGamers(gamerName);
            await getUserProfile();
            console.log("Search results:", searchResults);
          } catch (e) {
            console.error("Error fetching gamer data:", e);
          }
        }
      }
    };

    fetchGamerData();
  }, [gamerName, isOffline, getUserProfile]);

  // Cache current gamer data whenever it changes
  useEffect(() => {
    // Find the gamer with the matching username in search results
    const foundGamer = searchResults.find(gamer => gamer.username === gamerName);
    
    if (foundGamer) {
      console.log("Found gamer to cache:", foundGamer);
      cacheGamerData(foundGamer);
    }
  }, [searchResults, gamerName]);

  // Determine which data to show
  // Find the matching gamer in search results or use cached data
  const foundGamer = searchResults.find(gamer => gamer.username === gamerName);
  const displayGamer = foundGamer || cachedGamer;

  console.log("Display gamer:", displayGamer);

  const handlePlayUser = () => {
    if (displayGamer) {
      // Cache the selected opponent data before navigation
      AsyncStorage.setItem('selectedOpponentData', JSON.stringify({
        opponentId: displayGamer._id,
        opponentUsername: displayGamer.username,
        opponentAvatar: displayGamer.avatar
      })).then(() => {
        // Navigate to top games screen with opponent ID
        router.push({
          pathname: `/(tabs)/top-games`, 
          params: {
            opponentId: displayGamer._id
          }
        });
      }).catch(err => {
        console.error("Error saving opponent data:", err);
      });
    }
  };
  
  // Navigate to chat with this gamer
  const handleChatPress = () => {
    if (isOffline) return; // Prevent navigation if offline
    
    // Navigate to chat screen with gamer info
    router.push({
      pathname: '/chat',
      params: {
        gamerId: displayGamer?._id,
        username: displayGamer?.username,
        avatar: displayGamer?.avatar
      }
    });
  };

  if (searchLoading && !displayGamer) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <ActivityIndicator size="large" color="#be3593" />
      </View>
    );
  }

  if (searchError && !displayGamer) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <Text style={styles.errorText}>{searchError}</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => searchGamers(gamerName || "")}
        >
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!displayGamer) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <Text style={styles.errorText}>Gamer not found</Text>
        <TouchableOpacity 
          style={styles.retryButton}
          onPress={() => router.back()}
        >
          <Text style={styles.retryButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {isOffline && (
        <View style={styles.offlineBar}>
          <Text style={styles.offlineText}>You are offline. Some data may not be current.</Text>
        </View>
      )}
      
      {/* User Card */}
      <View style={styles.userCard}>
        <Image
          source={{ uri: displayGamer.avatar }}
          defaultSource={require("@/assets/images/friend.png")}
          style={styles.profileImage}
        />
        <View style={styles.userInfo}>
          <Text style={styles.userName}>{displayGamer.username}</Text>
          {/* Display total wins if available */}
          {displayGamer.totalWins !== undefined && (
            <Text style={styles.userEmail}>Total Wins: {displayGamer.totalWins}</Text>
          )}
        </View>
      </View>
      <View style={styles.bottomBorder} />

      {/* Bio Section */}
      <View style={styles.bioSection}>
        <Text style={styles.bioTitle}>Bio</Text>
        <Text style={styles.bioText}>
          {displayGamer.bio || "No bio available"}
        </Text>
      </View>

      {/* Favorite Game & Wins Section */}
      <View style={styles.statsContainer}>
        <View style={[styles.statItem, styles.leftAlign]}>
          <Text style={styles.statLabel}>Favorite Game</Text>
          <Text style={styles.statValue}>
            {displayGamer.favoriteGame ? displayGamer.favoriteGame.name : 'Not set'}
          </Text>
        </View>
        <View style={styles.verticalDivider} />
        <View style={[styles.statItem, styles.rightAlign]}>
          <Text style={styles.statLabel}>Number of Wins</Text>
          <Text style={styles.statValue}>{displayGamer.totalWins || 0} Wins</Text>
        </View>
      </View>

      {/* Chat and Play Buttons */}
      <View style={styles.buttonsContainer}>
        <TouchableOpacity
          onPress={handleChatPress}
          style={[styles.buttonn, isOffline && styles.disabledButton]}
          disabled={isOffline}
        >
          <Text style={[styles.buttonnText, isOffline && styles.disabledButtonText]}>Chat User</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.button, isOffline && styles.disabledButton]}
          onPress={handlePlayUser}
          disabled={isOffline}
        >
          <Text style={styles.buttonText}>Play User</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default UserProfileScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#130828",
    paddingVertical: 16,
    paddingHorizontal: 30,
  },
  centerContent: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  errorText: {
    color: 'white',
    fontSize: 16,
    marginBottom: 20,
  },
  offlineBar: {
    backgroundColor: "#ff9800",
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
  offlineText: {
    color: "white",
    textAlign: "center",
    fontSize: 12,
  },
  retryButton: {
    backgroundColor: "#be3593",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
  },
  retryButtonText: {
    color: "white",
    fontSize: 14,
  },
  userCard: {
    flexDirection: "row",
    paddingBottom: 10,
    marginBottom: 16,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 40,
    marginRight: 16,
    backgroundColor: "#333", // Placeholder color while loading
  },
  userInfo: {
    justifyContent: "center",
  },
  userName: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 5,
  },
  userEmail: {
    fontSize: 14,
    color: "#fff",
    marginBottom: 5,
  },
  userCountry: {
    fontSize: 14,
    color: "#fff",
    marginBottom: 5,
  },
  bottomBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#444",
    marginBottom: 16,
  },
  bioSection: {
    marginBottom: 36,
    marginTop: 10,
  },
  bioTitle: {
    fontSize: 15,
    fontWeight: "800",
    marginBottom: 5,
    color: "#fff",
  },
  bioText: {
    fontSize: 12,
    color: "#fff",
    lineHeight: 20,
  },
  statsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 50,
  },
  statItem: {
    flex: 1,
    justifyContent: "center",
  },
  statLabel: {
    fontSize: 12,
    color: "#fff",
  },
  statValue: {
    fontSize: 12,
    marginTop: 4,
    color: "#be3593",
  },
  verticalDivider: {
    width: 1,
    backgroundColor: "#ddd",
    height: "100%",
    marginHorizontal: 16,
  },
  leftAlign: {
    alignItems: "flex-start",
  },
  rightAlign: {
    alignItems: "center",
  },
  buttonsContainer: {
    flexDirection: "column",
    alignItems: "center",
  },
  buttonn: {
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderColor: "#be3593",
    marginVertical: 15,
    width: "100%",
    alignItems: "center",
  },
  buttonnText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  button: {
    backgroundColor: "#be3593",
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 4,
    marginVertical: 15,
    width: "100%",
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  disabledButton: {
    backgroundColor: "#666",
    borderColor: "#666",
  },
  disabledButtonText: {
    color: "#ccc",
  }
});