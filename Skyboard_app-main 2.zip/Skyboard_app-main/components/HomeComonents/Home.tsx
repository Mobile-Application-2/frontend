import GameResultModal from "@/app/(modal)/game-result-modal";
import { globalGameData } from "@/games/my-whot/my-whot";
import formatToNaira from "@/utils/currencyFormatter";
import { useGameStore } from "@/zustand/gameStore";
import { useProfileStore } from "@/zustand/profileStore";
import { useFocusEffect, useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Dimensions,
  Image,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

// Get device dimensions
const { width, height } = Dimensions.get("window");

// External globals declared in MyWhotGame component
declare global {
  var globalGameResult: { winner: string; loser: string } | null;
  var globalStakeAmount: number;
  var globalShowModal: boolean;
  var globalPlayerId: string;
}

const Home: React.FC = () => {
  const router = useRouter();
  const {
    user,
    isLoading: profileLoading,
    error: profileError,
    getUserProfile,
  } = useProfileStore();
  const {
    topgames,
    topGamers,
    isLoading: gamesLoading,
    error: gamesError,
    getTopGames,
    getTopGamers,
  } = useGameStore();

  // State to track orientation changes
  const [screenWidth, setScreenWidth] = useState(width);

  // State for the game result modal
  const [showModal, setShowModal] = useState(false);

  // First useEffect for fetching data and setting up dimension listener
  useEffect(() => {
    getTopGames(); // Fetch top games on component mount
    getTopGamers(); // Fetch top gamers on component mount
    getUserProfile();

    // Setup dimension change listener
    const dimensionsHandler = ({ window }: any) => {
      setScreenWidth(window.width);
    };

    const subscription = Dimensions.addEventListener(
      "change",
      dimensionsHandler
    );

    // Cleanup
    return () => subscription.remove();
  }, []);

console.log("Current modal state:", { 
  showModal, 
  globalResult: globalGameData.result,
  globalShowModal: globalGameData.showModal 
});

  // Second, separate useEffect for checking game results
useFocusEffect(
  React.useCallback(() => {
    // Check if we have game results to show and they're recent (within last 30 seconds)
    const currentTime = Date.now();
    const resultAge = currentTime - (globalGameData.timestamp || 0);
    
    if (globalGameData.showModal && globalGameData.result && resultAge < 30000) {
      console.log("Showing game result modal:", globalGameData.result);
      setShowModal(true);
    }
  }, [])
);

  const handleModalClose = () => {
    setShowModal(false);
    // Reset the global modal state
    globalGameData.showModal = false;
    globalGameData.result = null;
  };

  const handlePlayAgain = () => {
    router.replace({
      pathname: `/(games)/${globalGameData.gameName}`,
      params: {
        playerId: globalGameData.playerId,
        opponentId: globalGameData.opponentId,
        gameName: globalGameData.gameName,
        stakeAmount: globalGameData.stakeAmount,
        lobbyCode: globalGameData.lobbyCode, // Pass the saved lobby code
        lobbyId: globalGameData.lobbyId      // Pass the saved lobby ID
      },
    });
    
    // Keep other data but reset modal state
    globalGameData.showModal = false;
    globalGameData.result = null;
  };

  const isLoading = profileLoading || gamesLoading;
  const error = profileError || gamesError;

  // Function to get background color based on index
  const getBackgroundColor = (index: number) => {
    const colors = ["#FFB1D8", "#FFB8A1", "#A8FF9F", "#DEB0FF", "#FFD6A1"];
    return colors[index % colors.length];
  };

  // Calculate item width based on screen size
  const calculateGameCardWidth = () => {
    const isLandscape = screenWidth > height;
    const numColumns = isLandscape ? 3 : 2;
    const padding = width * 0.04; // 4% of screen width
    const gap = width * 0.02; // 2% of screen width
    return (screenWidth - padding * 2 - gap * (numColumns - 1)) / numColumns;
  };

  const gameCardWidth = calculateGameCardWidth();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1A1624" />
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#E75B99" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Error: {error}</Text>
        </View>
      ) : (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scrollContent}
        >
          {/* Balance Card */}
          <View style={styles.balanceCard}>
            <View style={styles.balanceInfo}>
              <Text style={styles.balanceLabel}>Wallet Balance</Text>
              <Text style={styles.balanceAmount}>
                {formatToNaira
                  ? formatToNaira(user?.walletBalance || 0.0)
                  : "0.00"}
              </Text>
            </View>
            <View style={styles.balanceActions}>
              <TouchableOpacity
                onPress={() => router.push("/(pages)/reg-deposit")}
                style={[styles.actionButton, styles.fundButton]}
              >
                <Text style={styles.actionButtonText}>+ Fund your balance</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => router.push("/(pages)/reg-wallet")}
                style={[styles.actionButton, styles.withdrawButton]}
              >
                <Text style={styles.actionButtonText}>
                  - Withdraw your wins
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Available Games */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>AVAILABLE GAMES</Text>
              <TouchableOpacity
                onPress={() => router.push("/(tabs)/top-games")}
              >
                <Text style={styles.seeAllButton}>See all →</Text>
              </TouchableOpacity>
            </View>

            {topgames.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>
                  No games available at the moment.
                </Text>
              </View>
            ) : (
              <View style={styles.gamesGrid}>
                {topgames.map((game) => (
                  <TouchableOpacity
                    key={game._id}
                    style={[styles.gameCard, { width: gameCardWidth }]}
                    onPress={() => {
                      router.push({
                        pathname: "/(page)/game-entry",
                        params: {
                          gameId: game._id,
                          title: game.name,
                          description: game.description,
                          image: game.image,
                        },
                      });
                    }}
                  >
                    <Image
                      source={game.image as any}
                      style={styles.gameImage}
                      resizeMode="cover"
                    />
                    <View style={styles.gameInfo}>
                      <Text
                        style={styles.gameTitle}
                        numberOfLines={1}
                        ellipsizeMode="tail"
                      >
                        {game.name}
                      </Text>
                      <TouchableOpacity style={styles.playButton}>
                        <Text>▶️</Text>
                      </TouchableOpacity>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          {/* Top Gamers */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>TOP GAMERS</Text>
              <TouchableOpacity onPress={() => router.push("/allUsers")}>
                <Text style={styles.seeAllButton}>See all →</Text>
              </TouchableOpacity>
            </View>

            {topGamers.length === 0 ? (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>
                  No top gamers available at the moment.
                </Text>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.gamersScroll}
                contentContainerStyle={styles.gamersScrollContent}
              >
                {topGamers.map((gamer, index) => (
                  <View
                    key={gamer._id}
                    style={[
                      styles.gamerItem,
                      { width: Math.min(width * 0.2, 80) },
                    ]}
                  >
                    <View
                      style={[
                        styles.gamerAvatar,
                        {
                          backgroundColor: getBackgroundColor(index),
                          width: Math.min(width * 0.15, 60),
                          height: Math.min(width * 0.15, 60),
                          borderRadius: Math.min(width * 0.075, 30),
                        },
                      ]}
                    >
                      {gamer.userInfo.avatar ? (
                        <Image
                          source={{ uri: gamer.userInfo.avatar }}
                          style={[
                            styles.gamerImage,
                            {
                              width: Math.min(width * 0.12, 50),
                              height: Math.min(width * 0.12, 50),
                              borderRadius: Math.min(width * 0.06, 25),
                            },
                          ]}
                        />
                      ) : (
                        <View
                          style={[
                            styles.gamerImagePlaceholder,
                            {
                              backgroundColor: getBackgroundColor(index + 2),
                              width: Math.min(width * 0.12, 50),
                              height: Math.min(width * 0.12, 50),
                              borderRadius: Math.min(width * 0.06, 25),
                            },
                          ]}
                        >
                          <Text style={styles.gamerInitial}>
                            {gamer.userInfo.username.charAt(0).toUpperCase()}
                          </Text>
                        </View>
                      )}
                    </View>
                    <Text
                      style={styles.gamerName}
                      numberOfLines={1}
                      ellipsizeMode="tail"
                    >
                      {gamer.userInfo.username}
                    </Text>
                    <Text style={styles.winsText}>{gamer.totalWins} wins</Text>
                  </View>
                ))}
              </ScrollView>
            )}
          </View>
        </ScrollView>
      )}
      {showModal && (
        <GameResultModal
          onClose={handleModalClose}
          onPlayAgain={handlePlayAgain}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A1624",
  },
  scrollContent: {
    paddingBottom: height * 0.05,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1A1624",
  },
  loadingText: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.045, 18),
    fontWeight: "bold",
    marginTop: height * 0.02,
  },
  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1A1624",
    padding: width * 0.05,
  },
  errorText: {
    color: "#FF5C5C",
    fontSize: Math.min(width * 0.04, 16),
    fontWeight: "bold",
    textAlign: "center",
  },
  balanceCard: {
    margin: width * 0.04,
    padding: width * 0.05,
    borderRadius: 16,
    backgroundColor: "#4A3D89",
  },
  balanceInfo: {
    marginBottom: height * 0.02,
  },
  balanceLabel: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.035, 14),
  },
  balanceAmount: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.07, 28),
    fontWeight: "bold",
  },
  balanceActions: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: width * 0.03,
  },
  actionButton: {
    flex: 1,
    padding: height * 0.015,
    borderRadius: 8,
    alignItems: "center",
  },
  fundButton: {
    backgroundColor: "#FFFFFF",
  },
  withdrawButton: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  },
  actionButtonText: {
    fontWeight: "500",
    color: "#000000",
    fontSize: Math.min(width * 0.03, 14),
  },
  section: {
    padding: width * 0.04,
    marginVertical: height * 0.01,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: height * 0.02,
    width: "100%",
  },
  sectionTitle: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.04, 16),
    fontWeight: "bold",
    flex: 1,
  },
  seeAllButton: {
    color: "#E75B99",
    fontSize: Math.min(width * 0.035, 14),
  },
  gamesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    gap: height * 0.015,
  },
  gameCard: {
    borderRadius: 16,
    padding: width * 0.02,
    aspectRatio: 1.5,
    marginBottom: height * 0.01,
  },
  gameImage: {
    width: "100%",
    height: "70%",
    borderRadius: 8,
  },
  gameInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: height * 0.01,
  },
  gameTitle: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.035, 14),
    fontWeight: "500",
    flex: 1,
    marginRight: width * 0.02,
  },
  playButton: {
    width: Math.min(width * 0.06, 24),
    height: Math.min(width * 0.06, 24),
    borderRadius: Math.min(width * 0.03, 12),
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
  },
  gamersScroll: {
    flexDirection: "row",
  },
  gamersScrollContent: {
    paddingVertical: height * 0.01,
    paddingHorizontal: width * 0.01,
  },
  gamerItem: {
    alignItems: "center",
    marginRight: width * 0.04,
  },
  gamerAvatar: {
    justifyContent: "center",
    alignItems: "center",
    marginBottom: height * 0.01,
  },
  gamerImage: {
    overflow: "hidden",
  },
  gamerImagePlaceholder: {
    justifyContent: "center",
    alignItems: "center",
  },
  gamerInitial: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.04, 16),
    fontWeight: "bold",
  },
  gamerName: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.03, 12),
    marginBottom: height * 0.005,
    maxWidth: Math.min(width * 0.2, 80),
    textAlign: "center",
  },
  winsText: {
    color: "#E75B99",
    fontSize: Math.min(width * 0.025, 10),
    fontWeight: "500",
  },
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    padding: width * 0.05,
    backgroundColor: "#2A2440",
    borderRadius: 8,
    marginVertical: height * 0.01,
  },
  emptyStateText: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.04, 16),
    fontWeight: "bold",
    textAlign: "center",
  },

  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.7)",
    justifyContent: "center",
    alignItems: "center",
    padding: width * 0.05,
  },
  modalContent: {
    width: "90%",
    backgroundColor: "#2A2440",
    borderRadius: 16,
    padding: width * 0.05,
    alignItems: "center",
  },
  modalHeader: {
    width: "100%",
    alignItems: "center",
    marginBottom: height * 0.02,
  },
  modalTitle: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.06, 24),
    fontWeight: "bold",
    textAlign: "center",
  },
  modalBody: {
    width: "100%",
    alignItems: "center",
  },
  resultText: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.05, 20),
    marginBottom: height * 0.03,
    textAlign: "center",
  },
  modalButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginTop: height * 0.02,
  },
  modalButton: {
    flex: 1,
    padding: height * 0.02,
    borderRadius: 8,
    alignItems: "center",
    marginHorizontal: width * 0.02,
  },
  replayButton: {
    backgroundColor: "#E75B99",
  },
  replayButtonText: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.04, 16),
    fontWeight: "bold",
  },
  quitButton: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  },
  quitButtonText: {
    color: "#FFFFFF",
    fontSize: Math.min(width * 0.04, 16),
    fontWeight: "bold",
  },
});

export default Home;