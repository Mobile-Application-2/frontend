import { usePaymentStore } from "@/zustand/paymentStore";
import { useRouter } from "expo-router";
import * as WebBrowser from 'expo-web-browser';
import React, { useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

export default function DepositScreen() {
  const router = useRouter();
  const [stakeAmount, setStakeAmount] = useState(100);
  const { makeDeposit, isLoading, error, checkoutUrl, resetState } = usePaymentStore();

  const handleIncrement = () => setStakeAmount((prev) => prev + 100);
  const handleDecrement = () =>
    setStakeAmount((prev) => Math.max(prev - 100, 100)); // Minimum stake 100

  const handlePresetAmount = (amount: number) => {
    setStakeAmount(amount);
  };

  const handleDeposit = async () => {
    if (stakeAmount < 100) {
      Alert.alert("Invalid Amount", "Minimum deposit amount is N100");
      return;
    }
  
    // Multiply the deposit amount by 1000 before making the deposit
    const amountToDeposit = stakeAmount * 100;
    const url = await makeDeposit(amountToDeposit);
    
    // Use the returned URL directly instead of relying on state update
    if (url) {
      try {
        const result = await WebBrowser.openBrowserAsync(url);
        
        // Handle the result when user comes back from the browser
        if (result.type === 'cancel' || result.type === 'dismiss') {
          // User closed the browser without completing payment
          resetState();
        } else {
          // This doesn't guarantee payment success, just that they completed the flow
          router.push("/(tabs)");
        }
      } catch (err) {
        console.error("Error opening browser:", err);
        Alert.alert("Error", "Could not open payment page. Please try again.");
      }
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <View style={styles.content}>
        <Text style={styles.subheading}>Deposit</Text>
        <View style={styles.stakeContainer}>
          <TouchableOpacity 
            onPress={handleDecrement} 
            style={styles.iconButton}
            disabled={isLoading}
          >
            <Text style={styles.iconText}>-</Text>
          </TouchableOpacity>
          <View>
            <TextInput
              value={stakeAmount.toString()}
              style={styles.stakeInput}
              keyboardType="numeric"
              onChangeText={(text) => {
                // Ensure only valid numbers are entered
                const numValue = text.replace(/[^0-9]/g, '');
                setStakeAmount(Number(numValue) || 0);
              }}
              editable={!isLoading}
            />
          </View>
          <TouchableOpacity 
            onPress={handleIncrement} 
            style={styles.iconButton}
            disabled={isLoading}
          >
            <Text style={styles.iconText}>+</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.presetContainer}>
          <TouchableOpacity 
            style={styles.presetButton} 
            onPress={() => handlePresetAmount(5000)}
            disabled={isLoading}
          >
            <Text style={styles.presetText}>N5,000</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.presetButton} 
            onPress={() => handlePresetAmount(15000)}
            disabled={isLoading}
          >
            <Text style={styles.presetText}>N15,000</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.presetButton} 
            onPress={() => handlePresetAmount(25000)}
            disabled={isLoading}
          >
            <Text style={styles.presetText}>N25,000</Text>
          </TouchableOpacity>
        </View>
        
        {error && (
          <Text style={styles.errorText}>{error}</Text>
        )}
        
        <TouchableOpacity
          onPress={handleDeposit}
          style={[styles.nextButton, isLoading && styles.disabledButton]}
          disabled={isLoading}
        >
          {isLoading ? (
            <ActivityIndicator color="#1A0826" />
          ) : (
            <Text style={styles.nextButtonText}>Deposit</Text>
          )}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A0826",
    paddingHorizontal: 24,
    paddingTop: 100,
  },
  backButton: {
    fontSize: 18,
    color: "#FFF",
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFF",
  },
  headerText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#DDA7FF",
  },
  content: {
    marginTop: 30,
    alignItems: "center",
  },
  subheading: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 20,
  },
  stakeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 50,
    alignItems: "center",
    marginBottom: 40,
  },
  iconButton: {
    width: 50,
    height: 50,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#2D1035",
    borderRadius: 15,
  },
  iconText: {
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "bold",
  },
  stakeInput: {
    width: 100,
    height: 50,
    textAlign: "center",
    fontSize: 20,
    color: "#FFFFFF",
    borderBottomWidth: 2,
    borderBottomColor: "#FFFFFF",
    marginHorizontal: 10,
  },
  presetContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "100%",
    marginBottom: 20,
  },
  presetButton: {
    paddingVertical: 10,
    paddingHorizontal: 20,
    backgroundColor: "#E75B99",
    borderRadius: 10,
  },
  presetText: {
    color: "#1A0826",
    fontSize: 14,
    fontWeight: "bold",
  },
  infoText: {
    fontSize: 12,
    color: "#FFFFFF",
    marginBottom: 30,
  },
  nextButton: {
    backgroundColor: "#E75B99",
    width: "100%",
    paddingVertical: 15,
    alignItems: "center",
    borderRadius: 10,
  },
  nextButtonText: {
    color: "#1A0826",
    fontSize: 16,
    fontWeight: "bold",
  },
  disabledButton: {
    opacity: 0.7,
  },
  errorText: {
    color: "#FF5555",
    marginBottom: 15,
    textAlign: "center",
  },
});