import { useProfileStore } from "@/zustand/profileStore";
import { useTournamentStore } from "@/zustand/tournamentsStore";
import { useRouter } from "expo-router";
import { useSearchParams } from "expo-router/build/hooks";
import React, { useMemo, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Image,
  RefreshControl,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

interface UserItemProps {
  imageUri: any;
  name: string;
  number: string;
  game: string;
  tournamentId: string;
  tournamentName: string;
  gameId: string;
  joiningCode: string;
  user?: string;
  status: string | "Waiting" | "Enter" | "Ended" | "Join" | "Running";
  isParticipating?: boolean;
  isOwner: string;
  gameName: string;
  onInvite: () => void;
}

const UserItem: React.FC<UserItemProps> = ({
  imageUri,
  name,
  number,
  game,
  tournamentId,
  tournamentName,
  gameId,
  joiningCode,
  status,
  user,
  isOwner,
  gameName,
  isParticipating = false,
  onInvite,
}) => {
  const router = useRouter();
  const params = useSearchParams();

  // Access Parameters
  const image = params.get("image");

  let borderColor = "#b7d080";
  if (status === "Running" || status === "Enter") {
    borderColor = "orange";
  } else if (status === "Ended") {
    borderColor = "red";
  }

  const handlePress = () => {
    if (status === "Join") {
      router.push({
        pathname: "/(page)/join-tournament",
        params: { game, name, image: image },
      });
    } else if (status === "Ended") {
      router.push({ pathname: "/(pages)/reg-leader-board", params: { tournamentId } });
    } else if (status === "Running") {
      Alert.alert("Cannot join a running game.");
    } else if (status === "Waiting") {
      Alert.alert("The game has not started yet please wait for the game to begin");
    } else if (status === "Enter") {
      console.log("Navigating with gameName:", gameName); // This will now show the correct value
      router.push({ 
        pathname: "/(pages)/celebrityWatingRoom", 
        params: { 
          tournamentId,
          gameId,
          joiningCode,
          user,
          tournamentName,
          isOwner,
          gameName // This will now have the correct value from props
        } 
      });
    }
  };

  return (
    <View style={[styles.userItem, isParticipating && styles.participatingItem]}>
      {isParticipating && (
        <View style={styles.participatingBadge}>
          <Text style={styles.participatingText}>Participating</Text>
        </View>
      )}
      <Image source={imageUri} style={styles.userImage} />
      <View style={styles.userDetails}>
        <Text style={styles.userName}>{name}</Text>
        <Text style={styles.userGame}>{game}</Text>
        <Text style={styles.userNumber}>{number} Players</Text>
      </View>
      <TouchableOpacity
        style={[styles.statusButton, { borderColor }, styles.statusButtonSize]}
        onPress={handlePress}
      >
        <Text style={styles.statusButtonText}>{status}</Text>
      </TouchableOpacity>
    </View>
  );
};

const TournamentsScreen: React.FC = () => {
  const { 
    tournaments, 
    isLoading, 
    error, 
    getTournaments,
    participatingTournaments,
    isLoadingParticipating,
    participatingError,
    getParticipatingTournaments
  } = useTournamentStore();
  const { getUserProfile, user } = useProfileStore();
  
  // Get safe area insets to handle tab bar padding
  const insets = useSafeAreaInsets();
  
  // State for refresh control
  const [refreshing, setRefreshing] = useState(false);
  
  // Function to refresh all data
  const refreshData = async () => {
    setRefreshing(true);
    try {
      await Promise.all([
        getTournaments(1),
        getParticipatingTournaments(),
        getUserProfile()
      ]);
    } catch (error) {
      console.error("Error refreshing data:", error);
    } finally {
      setRefreshing(false);
    }
  };

  // Combine and sort tournaments to show participating ones first
  const sortedTournaments = useMemo(() => {
    // Create a Set of IDs from participating tournaments for quick lookup
    const participatingIds = new Set(participatingTournaments.map(t => t._id));
    
    // Filter out tournaments that are already in the participating list to avoid duplicates
    const nonParticipatingTournaments = tournaments.filter(
      t => !participatingIds.has(t._id)
    );
    
    // Return participating tournaments first, followed by other tournaments
    return [
      ...participatingTournaments.map(t => ({ ...t, isParticipating: true })),
      ...nonParticipatingTournaments.map(t => ({ ...t, isParticipating: false }))
    ];
  }, [tournaments, participatingTournaments]);

  const getTournamentStatus = (tournament: any): "Join" | "Running" | "Ended" | "Waiting" | "Enter" => {
    console.log(`Tournament ${tournament.name} - isParticipating: ${tournament.isParticipating}, hasEnded: ${tournament.hasEnded}`);
    
    // First check if the tournament has ended, regardless of participation
    if (tournament.hasEnded) {
      return "Ended";
    }
    
    // Then handle the other cases
    if (tournament.isParticipating) {
      if (tournament.hasStarted) {
        return "Enter";
      } else {
        return "Waiting";
      }
    } else {
      if (tournament.hasStarted) {
        return "Running";
      } else {
        return "Join";
      }
    }
  };

  // Handle pull-to-refresh
  const onRefresh = async () => {
    refreshData();
  };

  // Show loading state if both tournament lists are loading and not in refresh mode
  if ((isLoading || isLoadingParticipating) && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#b7d080" />
      </View>
    );
  }

  // Show error if either request failed
  if (error || participatingError) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>
          Error: {error || participatingError}
        </Text>
        <TouchableOpacity style={styles.retryButton} onPress={refreshData}>
          <Text style={styles.retryText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }
  console.log("Game Name:", tournaments.map((game) => game.gameName))
  console.log(tournaments)

  return (
    <SafeAreaView style={styles.safeArea}>
      <FlatList
        data={sortedTournaments}
        keyExtractor={(item) => item._id}
        renderItem={({ item }) => (
          <UserItem
            imageUri={require("@/assets/images/friend.png")} // Placeholder image
            name={item.name}
            number={item.participants.length.toString()} // Dynamically show participant count
            game={item.name}
            tournamentId={item._id}
            tournamentName={item.name}
            user={user?._id}
            isOwner={item.creatorId}
            gameId={item.gameId} // Pass gameId from API response
            joiningCode={item.joiningCode} // Pass joiningCode from API response
            status={getTournamentStatus(item)} // Map status dynamically
            isParticipating={item.isParticipating}
            gameName={item.gameName}
            onInvite={() => console.log(`Invite sent to ${item.name}`)}
          />
        )}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            colors={["#b7d080"]}
            tintColor="#b7d080"
          />
        }
        contentContainerStyle={[
          styles.container,
          sortedTournaments.length === 0 && styles.emptyStateContainer,
          { paddingBottom: insets.bottom + 70 } // Add extra padding for tab bar + safe area
        ]}
        ListEmptyComponent={() => (
          <View style={styles.emptyState}>
            <Text style={styles.emptyStateText}>
              No tournaments available yet.
            </Text>
            <TouchableOpacity style={styles.retryButton} onPress={refreshData}>
              <Text style={styles.retryText}>Refresh</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </SafeAreaView>
  );
};

export default TournamentsScreen;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#130828",
  },
  container: {
    flexGrow: 1,
    backgroundColor: "#130828",
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#130828",
  },
  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#130828",
  },
  errorText: {
    color: "red",
    fontSize: 16,
    marginBottom: 15,
  },
  userItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 15,
    marginBottom: 15,
    borderBottomWidth: 0.5,
    borderColor: "gray",
    position: "relative",
  },
  participatingItem: {
    backgroundColor: "rgba(183, 208, 128, 0.15)",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#b7d080",
  },
  participatingBadge: {
    position: "absolute",
    top: 0,
    right: 0,
    backgroundColor: "#b7d080",
    borderTopRightRadius: 10,
    borderBottomLeftRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  participatingText: {
    color: "#130828",
    fontSize: 10,
    fontWeight: "bold",
  },
  userImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  userGame: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  userNumber: {
    fontSize: 12,
    color: "#b7d080",
  },
  statusButton: {
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  statusButtonSize: {
    paddingHorizontal: 20,
    width: 100,
  },
  statusButtonText: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "600",
    textAlign: "center",
  },
  emptyStateContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyState: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyStateText: {
    fontSize: 16,
    color: "#b7d080",
    textAlign: "center",
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: "#b7d080",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 8,
    marginTop: 10,
  },
  retryText: {
    color: "#130828",
    fontSize: 14,
    fontWeight: "600",
  },
});