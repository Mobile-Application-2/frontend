import { SearchedGamer, useGameStore } from "@/zustand/gameStore";
import { Ionicons } from "@expo/vector-icons";
import { router, useNavigation } from "expo-router";
import React, { useEffect, useLayoutEffect, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

interface GamerItemProps {
  gamer: SearchedGamer;
  onViewPress: (gamerId: string) => void;
}

const GamerItem: React.FC<GamerItemProps> = ({ gamer, onViewPress }) => {
  return (
    <View style={styles.userItem}>
      {/* Gamer Image */}
      <Image 
        source={{ uri: gamer.avatar }} 
        style={styles.userImage} 
        defaultSource={require("@/assets/images/friend.png")}
      />

      {/* Gamer Details */}
      <View style={styles.userDetails}>
        <Text style={styles.userName}>{gamer.username}</Text>
        <Text style={styles.userNumber}>{gamer.totalWins} wins</Text>
      </View>

      {/* View Button */}
      <TouchableOpacity
        style={styles.inviteButton}
        onPress={() => onViewPress(gamer.username)}
      >
        <Text style={styles.inviteButtonText}>View</Text>
      </TouchableOpacity>
    </View>
  );
};

const HeaderComponent: React.FC<{
  searchQuery: string;
  setSearchQuery: (text: string) => void;
  onBackPress: () => void;
  onSearch: () => void;
}> = ({ searchQuery, setSearchQuery, onBackPress, onSearch }) => {
  return (
    <View style={styles.headerContainer}>
      {/* Back Arrow */}
      <TouchableOpacity onPress={onBackPress} style={styles.backButton}>
        <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
      </TouchableOpacity>
      {/* Search Input */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search gamers"
          placeholderTextColor="#999"
          value={searchQuery}
          onChangeText={setSearchQuery}
          onSubmitEditing={onSearch}
          returnKeyType="search"
        />
        {/* Search Icon */}
        <TouchableOpacity onPress={onSearch}>
          <Ionicons
            name="search"
            size={20}
            color="#1F1F1E"
            style={styles.searchIcon}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const CelebrityGamersListScreen: React.FC = () => {
    const navigation = useNavigation()
  const [searchQuery, setSearchQuery] = useState("");
  const { 
    searchResults, 
    searchLoading, 
    searchError, 
    searchGamers, 
    clearSearchResults,
    getGamers,
    isLoading,
    error,
    gamers
  } = useGameStore();
  
  // Function to handle back navigation
  const handleBackPress = () => {
    clearSearchResults();
    router.back();
  };

  // Function to handle viewing a gamer's profile
  const handleViewGamer = (gamerName: string) => {
    router.push({pathname: `/usersProfile`, params: {gamerName}});
  };

  // Load gamers on component mount
  useEffect(() => {
    getGamers();
    return () => {
      clearSearchResults(); // Clean up search results when unmounting
    };
  }, [getGamers]);

  // Handle search
  const handleSearch = () => {
    if (searchQuery.trim()) {
      searchGamers(searchQuery);
    } else {
      clearSearchResults();
    }
  };

    useLayoutEffect(() => {
      navigation.setOptions({
        header: () => (
          <HeaderComponent
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onBackPress={handleBackPress}
          onSearch={handleSearch}
        />
        ),
      });
    }, [navigation, searchQuery, handleBackPress, handleSearch]);

  // Determine which data to show - search results or all gamers
  const displayData = searchQuery.trim() ? searchResults : gamers;
  const displayLoading = searchQuery.trim() ? searchLoading : isLoading;
  const displayError = searchQuery.trim() ? searchError : error;

  // Render each gamer item
  const renderGamerItem = ({ item }: { item: SearchedGamer }) => (
    <GamerItem
      gamer={item}
      onViewPress={() => handleViewGamer(item.username)}
    />
  );

  // Render empty list component
  const renderEmptyComponent = () => (
    <View style={styles.emptyContainer}>
      <Text style={styles.emptyText}>
        {searchQuery.trim() ? "No gamers found matching your search" : "No gamers available"}
      </Text>
    </View>
  );

  if (displayLoading && displayData.length === 0) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <ActivityIndicator size="large" color="#be3593" />
      </View>
    );
  }

  if (displayError && displayData.length === 0) {
    return (
      <View style={[styles.container, styles.centerContent]}>
        <Text style={styles.errorText}>Failed to load gamers. Please try again.</Text>
        <TouchableOpacity style={styles.retryButton} onPress={searchQuery.trim() ? handleSearch : getGamers}>
          <Text style={styles.retryButtonText}>Retry</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Title */}
      <Text style={styles.title}>
        {searchQuery.trim() ? 'Search Results' : 'All Gamers'}
      </Text>

      {/* Scrollable Gamers List */}
      <FlatList
        data={displayData}
        renderItem={renderGamerItem}
        keyExtractor={(item) => item._id}
        ListEmptyComponent={renderEmptyComponent}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={displayData.length === 0 ? styles.flatListEmptyContent : styles.flatListContent}
      />
    </View>
  );
};

export default CelebrityGamersListScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#130828",
    padding: 20,
  },
  centerContent: {
    justifyContent: "center",
    alignItems: "center",
  },
  headerContainer: {
    backgroundColor: "#130828",
    flexDirection: "row",
    alignItems: "center",
    paddingTop: Platform.OS === 'ios' ? 50 : 0,
    paddingBottom: 10
  },
  backButton: {
    marginRight: 10,
  },
  searchContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 999,
    paddingVertical: 10,
    paddingHorizontal: 20,
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    color: "#1F1F1E",
    fontSize: 14,
  },
  searchIcon: {
    marginLeft: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 20,
  },
  userItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 15,
    marginBottom: 15,
    borderBottomWidth: 0.5,
    borderColor: "gray",
  },
  userImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
    backgroundColor: "#251145", // Placeholder background color
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  userNumber: {
    fontSize: 12,
    color: "#b7d080",
  },
  inviteButton: {
    paddingVertical: 5,
    paddingHorizontal: 25,
    borderRadius: 10,
    borderColor: "#b7d080",
    borderWidth: 1,
  },
  inviteButtonText: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "600",
  },
  emptyContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  emptyText: {
    color: "#FFFFFF",
    fontSize: 16,
    textAlign: "center",
  },
  errorText: {
    color: "#ff6b6b",
    fontSize: 16,
    textAlign: "center",
    marginBottom: 15,
  },
  retryButton: {
    paddingVertical: 8,
    paddingHorizontal: 20,
    backgroundColor: "#be3593",
    borderRadius: 10,
  },
  retryButtonText: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "600",
  },
  flatListContent: {
    paddingBottom: 20,
  },
  flatListEmptyContent: {
    flex: 1,
    justifyContent: "center",
  }
});