import { useCelebrityTournamentStore } from "@/zustandCelebrity/tournamentsStore";
import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";

interface UserItemProps {
  imageUri: any;
  name: string;
  number: string;
  game: string;
  status: string | "Join" | "Running" | "Ended";
  tournamentId: string;
  onInvite: () => void;
}

const UserItem: React.FC<UserItemProps> = ({
  imageUri,
  name,
  number,
  game,
  status,
  tournamentId,
  onInvite,
}) => {
  const router = useRouter(); // Hook for navigation

  // Determine the border color based on status
  let borderColor = "#b7d080"; // Default green for Join
  if (status === "Running") {
    borderColor = "orange";
  } else if (status === "Ended") {
    borderColor = "red";
  }

  // Handle navigation based on status
  const handlePress = () => {
    if (status === "Not Started") {
      console.log("Cannot join a running game.");
      Alert.alert("Game Is yet to start");
    } else if (status === "Ended") {
      router.push({
        pathname: "/(page)/leader-board",
        params: { game, tournamentId },
      });
    } else if (status === "Running") {
      console.log("Cannot view a running game leader board.");
      Alert.alert("Cannot view a running game leader board.");
    }
  };

  return (
    <View style={styles.userItem}>
      {/* User Image */}
      <Image source={imageUri} style={styles.userImage} />

      {/* User Details */}
      <View style={styles.userDetails}>
        <Text style={styles.userName}>{name}</Text>
        <Text style={styles.userGame}>{game}</Text>
        <Text style={styles.userNumber}>{number} Players</Text>
      </View>

      {/* Status Button */}
      <View
        style={[styles.statusButton, { borderColor }, styles.statusButtonSize]}
      >
        <Pressable onPress={handlePress}>
          <Text style={styles.statusButtonText}>{status}</Text>
        </Pressable>
      </View>
    </View>
  );
};

const CelebrityTournamentsScreen: React.FC = () => {
  // Use the tournament store
  const { tournaments, isLoading, error, getCelebrityTournaments } =
    useCelebrityTournamentStore();
    
  // State for refresh control
  const [refreshing, setRefreshing] = useState(false);

  // Fetch tournaments when component mounts
  useEffect(() => {
    getCelebrityTournaments();
  }, []);

  // Handle refresh
  const onRefresh = async () => {
    setRefreshing(true);
    await getCelebrityTournaments();
    setRefreshing(false);
  };

  // Function to determine tournament status based on API data
  const getTournamentStatus = (
    tournament: any
  ): "Not Started" | "Running" | "Ended" => {
    const now = new Date();
    const deadline = new Date(tournament.registrationDeadline);

    if (!tournament.hasStarted) {
      return "Ended";
    }

    if (now > deadline) {
      return "Running";
    }
    return "Not Started";
  };

  // Show loading indicator
  if (isLoading && !refreshing) {
    return (
      <View style={[styles.container, styles.centered]}>
        <ActivityIndicator size="large" color="#b7d080" />
      </View>
    );
  }

  // Show error message
  if (error) {
    return (
      <View style={[styles.container, styles.centered]}>
        <Text style={styles.errorText}>Error: {error}</Text>
      </View>
    );
  }

  // Placeholder image for tournaments
  const alternateImages = [
    require("@/assets/images/friend.png"),
    require("@/assets/images/friend1.png"),
    require("@/assets/images/friend2.png"),
  ];

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={tournaments.length === 0 ? styles.centered : styles.scrollContent}
      refreshControl={
        <RefreshControl 
          refreshing={refreshing}
          onRefresh={onRefresh}
          colors={["#b7d080"]}
          tintColor="#b7d080"
        />
      }
    >
      {tournaments.length === 0 ? (
        <Text style={styles.noDataText}>No tournaments available</Text>
      ) : (
        tournaments.map((tournament, index) => (
          <UserItem
            key={tournament._id}
            imageUri={alternateImages[index % alternateImages.length]}
            name={tournament.name}
            number={tournament.participants.length.toString()}
            game={`Game ID: ${tournament.gameId}`}
            status={getTournamentStatus(tournament)}
            tournamentId={tournament._id}
            onInvite={() =>
              console.log(`Invite sent for tournament ${tournament.name}`)
            }
          />
        ))
      )}
    </ScrollView>
  );
};

export default CelebrityTournamentsScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#130828",
  },
  scrollContent: {
    padding: 20,
  },
  centered: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  userItem: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 15,
    marginBottom: 15,
    borderBottomWidth: 0.5,
    borderColor: "gray",
  },
  userImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  userDetails: {
    flex: 1,
  },
  userName: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  userGame: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  userNumber: {
    fontSize: 12,
    color: "#b7d080",
  },
  statusButton: {
    paddingVertical: 10,
    borderRadius: 10,
    borderWidth: 1,
  },
  statusButtonSize: {
    paddingHorizontal: 20,
    width: 100,
  },
  statusButtonText: {
    fontSize: 14,
    color: "#FFFFFF",
    fontWeight: "600",
    textAlign: "center",
  },
  errorText: {
    color: "red",
    fontSize: 16,
  },
  noDataText: {
    color: "#FFFFFF",
    fontSize: 16,
  },
});