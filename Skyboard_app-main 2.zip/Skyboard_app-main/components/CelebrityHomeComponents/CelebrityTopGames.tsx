import { useGameStore } from "@/zustand/gameStore";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useEffect } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  SafeAreaView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const AllGamesScreen = () => {
  const router = useRouter();

  // Zustand store
  const { games, isLoading, error, getGames } = useGameStore();

  // Fetch games on mount
  useEffect(() => {
    getGames();
  }, []);

  const handleGamePress = (game: any) => {
    router.push({
      pathname: "/(page)/game-entry",
      params: {
        id: game._id,
        title: game.name,
        description: game.description,
        image: game.image,
        rating: game.averageRating,
        maxPlayers: game.maxPlayers,
        totalPlayers: game.totalNumberOfPlayers
      }
    });
  };

  const renderItem = ({ item }: any) => (
    <TouchableOpacity
    onPress={() => handleGamePress(item)}
     style={styles.card}>
      {/* Left Section */}
      <View style={[styles.imageContainer, { backgroundColor: "#FFF" }]}>
        <Image source={{ uri: item.image }} style={styles.image} />
        <Text style={styles.gameTitle}>{item.name}</Text>
        <Text style={styles.gameDescription}>{item.description}</Text>
      </View>

      {/* Right Section */}
      <View style={styles.detailsContainer}>
        <Text style={[styles.gameTitle, { color: "white" }]}>{item.name}</Text>
        <Text style={[styles.gameDescription, { color: "white" }]}>
          {item.description}
        </Text>

        {/* Ratings & Users */}
        <View style={styles.ratingContainer}>
          <Text style={styles.stars}>
            {"⭐".repeat(Math.floor(item.averageRating))}
          </Text>
          <Text style={styles.rating}>{item.averageRating.toFixed(1)}</Text>
        </View>

        {/* Users */}
        <Text style={styles.users}>+{item.totalNumberOfPlayers} users</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Ionicons name="chevron-back" size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>All Games</Text>
        <TouchableOpacity onPress={() => alert("Share feature coming soon!")}>
          <Ionicons name="share-social" size={24} color="white" />
        </TouchableOpacity>
      </View>

      {/* Display Loading, Error, or Games */}
      {isLoading ? (
        <ActivityIndicator size="large" color="#FFF" />
      ) : error ? (
        <Text style={{ color: "red", textAlign: "center" }}>{error}</Text>
      ) : (
        <FlatList
          data={games}
          renderItem={renderItem}
          keyExtractor={(item) => item._id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContentContainer}
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0A001A",
  },
  listContentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 80, // Add extra padding at the bottom to prevent items from being hidden behind tab bar
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
    marginTop: 20,
    paddingHorizontal: 20,
  },
  backButton: {
    fontSize: 18,
    color: "#FFF",
    marginRight: 10,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#FFF",
  },
  card: {
    flexDirection: "row",
    borderRadius: 8,
    marginBottom: 15,
    padding: 10,
  },
  imageContainer: {
    width: 200,
    height: 120,
    borderRadius: 10,
    marginRight: 15,
    padding: 10,
  },
  image: {
    width: 120,
    height: 60,
    borderRadius: 8,
    marginBottom: 5,
  },
  detailsContainer: {
    flex: 1,
    justifyContent: "space-between",
  },
  gameTitle: {
    color: "#0A001A",
    fontSize: 16,
    fontWeight: "bold",
  },
  gameDescription: {
    color: "#0A001A",
    fontSize: 14,
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  stars: {
    color: "#FFD700",
    fontSize: 14,
    marginRight: 5,
  },
  rating: {
    color: "#FFFFFF",
    fontSize: 14,
  },
  users: {
    color: "#FFFFFF",
    fontSize: 14,
  },
});

export default AllGamesScreen;