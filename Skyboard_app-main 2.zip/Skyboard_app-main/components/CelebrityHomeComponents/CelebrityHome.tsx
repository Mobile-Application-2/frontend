import formatToNaira from "@/utils/currencyFormatter";
import { useGameStore } from "@/zustand/gameStore";
import { useProfileStore } from "@/zustand/profileStore";
import { useRouter } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  Image,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

interface Game {
  id: string;
  title: string;
  image: any;
  description: string;
  backgroundColor: string;
}

interface Gamer {
  id: string;
  name: string;
  avatar: any;
  backgroundColor: string;
}

const CelebrityHome: React.FC = () => {
  const router = useRouter();
  const [refreshing, setRefreshing] = useState(false);

  // Zustand store methods and state
  const {
    user,
    getUserProfile,
    isLoading: profileLoading,
    error: profileError,
  } = useProfileStore();
  const {
    topgames,
    topGamers,
    isLoading: gamesLoading,
    error: gamesError,
    getTopGames,
    getTopGamers,
  } = useGameStore();

  // Fetch user profile on component mount
  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    getTopGames();
    getTopGamers();
    getUserProfile();
  };

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadData();
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  const isLoading = profileLoading || gamesLoading;
  const error = profileError || gamesError;

  // Render empty states for different sections
  const renderEmptyGames = () => (
    <View style={styles.emptyState}>
      <Text style={styles.emptyStateText}>
        No games available at the moment
      </Text>
      <TouchableOpacity
        style={styles.retryButton}
        onPress={() => getTopGames()}
      >
        <Text style={styles.retryButtonText}>Try Again</Text>
      </TouchableOpacity>
    </View>
  );

  const renderEmptyGamers = () => (
    <View style={styles.emptyState}>
      <Text style={styles.emptyStateText}>No gamers found</Text>
      <TouchableOpacity
        style={styles.retryButton}
        onPress={() => getTopGamers()}
      >
        <Text style={styles.retryButtonText}>Try Again</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#3f9217" />
          <Text style={styles.loadingText}>Loading content...</Text>
        </View>
      ) : error ? (
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>Error: {error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={loadData}>
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={["#3f9217"]}
            />
          }
        >
          {/* Balance Card */}
          <View style={styles.balanceCard}>
            <View style={styles.balanceInfo}>
              <Text style={styles.balanceLabel}>Wallet Balance</Text>
              <Text style={styles.balanceAmount}>
                {user ? `${formatToNaira(user.walletBalance)}` : "₦0.00"}
              </Text>
            </View>
            <View style={styles.balanceActions}>
              <TouchableOpacity
                onPress={() => router.push("/(page)/c-deposit")}
                style={[styles.actionButton, styles.fundButton]}
              >
                <Text style={styles.actionButtonText}>+ Fund your balance</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => router.push("/(page)/c-withdraw")}
                style={[styles.actionButton, styles.withdrawButton]}
              >
                <Text style={styles.actionButtonText}>
                  - Withdraw your wins
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Available Games */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>AVAILABLE GAMES</Text>
              <TouchableOpacity onPress={() => router.push("/(tab)/top-games")}>
                <Text style={styles.seeAllButton}>See all →</Text>
              </TouchableOpacity>
            </View>

            {!topgames || topgames.length === 0 ? (
              renderEmptyGames()
            ) : (
              <View style={styles.gamesGrid}>
                {topgames.map((game) => (
                  <TouchableOpacity
                    key={game._id}
                    style={[styles.gameCard, { backgroundColor: "white" }]}
                    onPress={() => {
                      router.push("/(page)/host-games");
                    }}
                  >
                    {game.image ? (
                      <Image
                        source={{ uri: game.image }}
                        style={styles.gameImage}
                      />
                    ) : (
                      <View style={[styles.gameImage, styles.placeholderImage]}>
                        <Text style={styles.placeholderText}>
                          {game.name.charAt(0)}
                        </Text>
                      </View>
                    )}
                    <View style={styles.gameInfo}>
                      <Text style={styles.gameTitle}>{game.name}</Text>
                      <TouchableOpacity style={styles.playButton}>
                        <Text>▶️</Text>
                      </TouchableOpacity>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </View>

          {/* Top Gamers */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>TOP GAMERS</Text>
              <TouchableOpacity onPress={() => router.push("/(page)/c-allUsers")}>
                <Text style={styles.seeAllButton}>See all →</Text>
              </TouchableOpacity>
            </View>

            {!topGamers || topGamers.length === 0 ? (
              renderEmptyGamers()
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                style={styles.gamersScroll}
              >
                {topGamers.map((gamer) => (
                  <View key={gamer._id} style={styles.gamerItem}>
                    <View
                      style={[styles.gamerAvatar, { backgroundColor: "white" }]}
                    >
                      {gamer.userInfo.avatar ? (
                        <Image
                          source={{ uri: gamer.userInfo.avatar }}
                          style={styles.gamerImage}
                        />
                      ) : (
                        <Text style={styles.usernameInitial}>
                          {gamer.userInfo.username
                            ? gamer.userInfo.username.charAt(0).toUpperCase()
                            : "?"}
                        </Text>
                      )}
                    </View>
                    <Text style={styles.gamerName}>
                      {gamer.userInfo.username || "Unknown"}
                    </Text>
                  </View>
                ))}
              </ScrollView>
            )}
          </View>
        </ScrollView>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1A1624",
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
  },
  userInfo: {
    flexDirection: "row",
    alignItems: "center",
  },
  userAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
    backgroundColor: "#FFB1D8",
  },
  greeting: {
    color: "#FFFFFF",
    fontSize: 18,
  },
  username: {
    fontWeight: "bold",
  },
  welcomeText: {
    color: "#666666",
    fontSize: 12,
  },
  headerIcons: {
    flexDirection: "row",
    gap: 12,
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#E75B99",
    justifyContent: "center",
    alignItems: "center",
  },
  balanceCard: {
    margin: 16,
    padding: 20,
    borderRadius: 16,
    backgroundColor: "#4A3D89",
  },
  balanceInfo: {
    marginBottom: 16,
  },
  balanceLabel: {
    color: "#FFFFFF",
    fontSize: 14,
  },
  balanceAmount: {
    color: "#FFFFFF",
    fontSize: 28,
    fontWeight: "bold",
  },
  balanceActions: {
    flexDirection: "row",
    gap: 12,
  },
  actionButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
  },
  fundButton: {
    backgroundColor: "#FFFFFF",
  },
  withdrawButton: {
    backgroundColor: "rgba(255, 255, 255, 0.2)",
  },
  actionButtonText: {
    fontWeight: "500",
    color: "#000000",
  },
  section: {
    padding: 16,
    marginVertical: 10,
  },
  sectionHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  sectionTitle: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
  },
  seeAllButton: {
    color: "#3f9217",
    fontSize: 14,
  },
  gamesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 16,
  },
  gameCard: {
    width: "47%",
    borderRadius: 16,
    padding: 12,
    aspectRatio: 1.5,
  },
  gameImage: {
    width: "100%",
    height: "70%",
    borderRadius: 8,
  },
  placeholderImage: {
    backgroundColor: "#2A2440",
    justifyContent: "center",
    alignItems: "center",
  },
  placeholderText: {
    color: "#FFFFFF",
    fontSize: 24,
    fontWeight: "bold",
  },
  gameInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 8,
  },
  gameTitle: {
    color: "#000000",
    fontSize: 14,
    fontWeight: "500",
  },
  playButton: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "#FFFFFF",
    justifyContent: "center",
    alignItems: "center",
  },
  gamersScroll: {
    flexDirection: "row",
    paddingHorizontal: 10,
  },
  gamerItem: {
    alignItems: "center",
    marginRight: 20,
  },
  gamerAvatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginBottom: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  gamerImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  gamerName: {
    color: "#FFFFFF",
    fontSize: 12,
  },
  bottomNav: {
    flexDirection: "row",
    justifyContent: "space-around",
    padding: 16,
    backgroundColor: "#E75B99",
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  navItem: {
    padding: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1A1624",
  },
  loadingText: {
    color: "#FFFFFF",
    fontSize: 16,
    marginTop: 12,
  },
  errorContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1A1624",
    padding: 20,
  },
  errorText: {
    color: "#FF6B6B",
    fontSize: 16,
    marginBottom: 16,
    textAlign: "center",
  },
  emptyState: {
    alignItems: "center",
    justifyContent: "center",
    padding: 20,
    backgroundColor: "#2A2440",
    borderRadius: 8,
    marginVertical: 10,
  },
  emptyStateText: {
    color: "#FFFFFF",
    fontSize: 16,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: "#3f9217",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginTop: 10,
  },
  retryButtonText: {
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  usernameInitial: {
    color: "#4A3D89",
    fontSize: 18,
    fontWeight: "bold",
  },
});

export default CelebrityHome;
